

/* eslint-disable react-hooks/set-state-in-effect */
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import html2pdf from 'html2pdf.js';
import type { Supplier, PerCapitaConfig, WarehouseMovement, AcquisitionItem, Delivery } from '../types';
import AdminAcquisitionItems from './AdminAcquisitionItems';
import AdminPerCapitaSuppliers from './AdminPerCapitaSuppliers';
import AdminAtaGenerator from './AdminAtaGenerator';
import AdminContractGenerator from './AdminContractGenerator';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { PoliciaPenalLogo } from './PoliciaPenalLogo';
import type { PerCapitaSupplier } from '../types';
import { roundToTwoDecimalPlaces, ensureArray } from '../lib/utils';
import { calculateAllowedWeeksFromSchedule } from '../lib/supplierUtils';

interface AdminPerCapitaProps {
  suppliers: Supplier[];
  warehouseLog: WarehouseMovement[];
  perCapitaConfig: PerCapitaConfig;
  onUpdatePerCapitaConfig: (config: Partial<PerCapitaConfig>) => Promise<any>;
  onUpdateContractForItem: (itemName: string, assignments: { supplierCpf: string, totalKg: number, valuePerKg: number, unit?: string, category?: string, comprasCode?: string, becCode?: string, commitmentNumber?: string, commitmentValue?: number }[]) => Promise<{ success: boolean, message: string }>;
  onUpdateAcquisitionItem: (item: AcquisitionItem) => Promise<{ success: boolean, message: string }>;
  onDeleteAcquisitionItem: (id: string) => Promise<{ success: boolean, message: string }>;
  acquisitionItems: AcquisitionItem[];
  onUpdateSupplierObservations?: (cpf: string, observations: string) => Promise<{ success: boolean; message?: string }>;
  onSyncPPAISToAgenda?: (config?: PerCapitaConfig) => Promise<void>;
  onSaveInvoice?: (supplierCpf: string, deliveryIds: string[], invoiceNumber: string, invoiceUrl: string, updatedDeliveries: Delivery[], invoiceDate?: string) => Promise<any>;
  onDeleteDelivery?: (supplierCpf: string, deliveryId: string) => Promise<{ success: boolean }>;
}

const formatCurrency = (value: number) => {
    if (isNaN(value)) return 'R$ 0,00';
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

const normalizeItemName = (name: string): string => {
    return (name || '')
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "") // Remove acentos
        .replace(/[;,. -/]/g, " ")    // Troca separadores por espaço
        .replace(/\s+/g, " ")           // Remove espaços duplos
        .trim()
        .toUpperCase();
};

const matchCpfCnpj = (val1: any, val2: any): boolean => {
    const c1 = String(val1 || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
    const c2 = String(val2 || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
    return c1 !== '' && c2 !== '' && (c1 === c2 || c1.startsWith(c2) || c2.startsWith(c1));
};

const months = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

const getSafeScheduleWeeks = (monthlySchedule: any, monthName: string): number[] => {
    if (!monthlySchedule) return [];
    const foundKey = Object.keys(monthlySchedule).find(k => k.toLowerCase() === monthName.toLowerCase());
    return foundKey ? (monthlySchedule[foundKey] || []) : [];
};

const getSeiValue = (map: Record<string, string>, tab: string) => (map && tab) ? map[tab] || '' : '';

const AdminPerCapita: React.FC<AdminPerCapitaProps> = ({ 
    suppliers, 
    perCapitaConfig, 
    onUpdatePerCapitaConfig, 
    onUpdateContractForItem, 
    onUpdateAcquisitionItem, 
    onDeleteAcquisitionItem, 
    acquisitionItems, 
    onUpdateSupplierObservations,
    onSyncPPAISToAgenda,
    onSaveInvoice,
    onDeleteDelivery
}) => {
    const [selectedProducer, setSelectedProducer] = useState<PerCapitaSupplier | null>(null);
    const [activeSubTab, setActiveSubTab] = useState<'CALCULO' | 'KIT PPL' | 'PPAIS' | 'ESTOCÁVEIS' | 'PERECÍVEIS' | 'PERECÍVEIS 3Q' | 'ESTOCÁVEIS 3Q' | 'AUTOMAÇÃO' | 'PRODUTOS DE LIMPEZA' | 'EPI' | 'ADIANTAMENTOS' | 'CONTROLE' | 'AUDIT'>('CALCULO');
    const [ppaisSubTab, setPpaisSubTab] = useState<'ITEMS' | 'PRODUCERS' | 'CONTRACT' | 'ATA' | 'SCHEDULE'>('ITEMS');
    const [pereciveisSubTab, setPereciveisSubTab] = useState<'ITEMS' | 'SUPPLIERS' | 'CONTRACT' | 'SCHEDULE'>('ITEMS');
    const [estocaveisSubTab, setEstocaveisSubTab] = useState<'ITEMS' | 'SUPPLIERS' | 'CONTRACT' | 'SCHEDULE'>('ITEMS');
    const [staffCount, setStaffCount] = useState<number>(() => perCapitaConfig?.staffCount !== undefined ? Number(perCapitaConfig.staffCount) : parseInt(localStorage.getItem('perCapita_staffCount') || '0', 10));
    const [inmateCount, setInmateCount] = useState<number>(() => perCapitaConfig?.inmateCount !== undefined ? Number(perCapitaConfig.inmateCount) : parseInt(localStorage.getItem('perCapita_inmateCount') || '0', 10));
    const [customPerCapita, setCustomPerCapita] = useState<Record<string, string>>(() => perCapitaConfig?.customValues || {});
    const [seiProcessNumbers, setSeiProcessNumbers] = useState<Record<string, string>>(() => perCapitaConfig?.seiProcessNumbers || {});
    const [seiProcessDefinitions, setSeiProcessDefinitions] = useState<Record<string, string>>(() => perCapitaConfig?.seiProcessDefinitions || {});
    const [monthlyQuota, setMonthlyQuota] = useState<Record<string, number>>(() => perCapitaConfig?.monthlyQuota || {});
    const [monthlyResource, setMonthlyResource] = useState<Record<string, number>>(() => perCapitaConfig?.monthlyResource || {});
    const [ptresResources, setPtresResources] = useState<Record<string, { pieces: number; services: number }>>(() => perCapitaConfig?.ptresResources || {});
    const [selectedYear, setSelectedYear] = useState<number>(() => {
        try {
            const saved = localStorage.getItem('perCapita_selectedYear');
            const num = saved ? parseInt(saved, 10) : 2026;
            return (num === 2026 || num === 2027) ? num : 2026;
        } catch {
            return 2026;
        }
    });
    const [selectedQuadrimestre, setSelectedQuadrimestre] = useState<'1Q' | '2Q' | '3Q'>(() => {
        try {
            const saved = localStorage.getItem('perCapita_selectedQuadrimestre');
            if (saved === '1Q' || saved === '2Q' || saved === '3Q') return saved;
        } catch {
            // ignore
        }
        return '2Q'; // Padrão: 2º Quadrimestre (Maio a Agosto - Dados Anteriores Cadastrados)
    });
    const [ppaisProducers, setPpaisProducers] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.ppaisProducers));
    const [pereciveisSuppliers1Q, setPereciveisSuppliers1Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.pereciveisSuppliers1Q));
    const [pereciveisSuppliers2Q, setPereciveisSuppliers2Q] = useState<PerCapitaSupplier[]>(() => {
        const from2Q = ensureArray(perCapitaConfig?.pereciveisSuppliers2Q);
        if (from2Q.length > 0) return from2Q;
        return ensureArray(perCapitaConfig?.pereciveisSuppliers);
    });
    const [pereciveisSuppliers3Q, setPereciveisSuppliers3Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.pereciveisSuppliers3Q));
    const [pereciveisSuppliers2027_1Q, setPereciveisSuppliers2027_1Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.pereciveisSuppliers2027_1Q));
    const [pereciveisSuppliers2027_2Q, setPereciveisSuppliers2027_2Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.pereciveisSuppliers2027_2Q));
    const [pereciveisSuppliers2027_3Q, setPereciveisSuppliers2027_3Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.pereciveisSuppliers2027_3Q));
    const [estocaveisSuppliers1Q, setEstocaveisSuppliers1Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.estocaveisSuppliers1Q));
    const [estocaveisSuppliers2Q, setEstocaveisSuppliers2Q] = useState<PerCapitaSupplier[]>(() => {
        const from2Q = ensureArray(perCapitaConfig?.estocaveisSuppliers2Q);
        if (from2Q.length > 0) return from2Q;
        return ensureArray(perCapitaConfig?.estocaveisSuppliers);
    });
    const [estocaveisSuppliers3Q, setEstocaveisSuppliers3Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.estocaveisSuppliers3Q));
    const [estocaveisSuppliers2027_1Q, setEstocaveisSuppliers2027_1Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.estocaveisSuppliers2027_1Q));
    const [estocaveisSuppliers2027_2Q, setEstocaveisSuppliers2027_2Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.estocaveisSuppliers2027_2Q));
    const [estocaveisSuppliers2027_3Q, setEstocaveisSuppliers2027_3Q] = useState<PerCapitaSupplier[]>(() => ensureArray(perCapitaConfig?.estocaveisSuppliers2027_3Q));
    const [monthlyAdvances, setMonthlyAdvances] = useState<Record<string, number>>(() => perCapitaConfig?.monthlyAdvances || {});
    const [showComparison, setShowComparison] = useState(false);
    const [isDirty, setIsDirty] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [saveSuccess, setSaveSuccess] = useState(false);
    const [comparisonFilter, setComparisonFilter] = useState<'TODOS' | 'SEM_ENTREGA' | 'ATENCAO' | 'AVANCADO' | 'CONCLUIDO' | 'COM_EMPENHO'>('TODOS');
    const [scheduleView, setScheduleView] = useState<'CALENDAR' | 'SUPPLIER'>('CALENDAR');

    const currentPereciveisSuppliers = useMemo(() => {
        if (selectedYear === 2027) {
            if (selectedQuadrimestre === '1Q') return pereciveisSuppliers2027_1Q;
            if (selectedQuadrimestre === '2Q') return pereciveisSuppliers2027_2Q;
            return pereciveisSuppliers2027_3Q;
        }
        if (selectedQuadrimestre === '1Q') return pereciveisSuppliers1Q;
        if (selectedQuadrimestre === '2Q') return pereciveisSuppliers2Q;
        return pereciveisSuppliers3Q;
    }, [selectedYear, selectedQuadrimestre, pereciveisSuppliers1Q, pereciveisSuppliers2Q, pereciveisSuppliers3Q, pereciveisSuppliers2027_1Q, pereciveisSuppliers2027_2Q, pereciveisSuppliers2027_3Q]);

    const currentEstocaveisSuppliers = useMemo(() => {
        if (selectedYear === 2027) {
            if (selectedQuadrimestre === '1Q') return estocaveisSuppliers2027_1Q;
            if (selectedQuadrimestre === '2Q') return estocaveisSuppliers2027_2Q;
            return estocaveisSuppliers2027_3Q;
        }
        if (selectedQuadrimestre === '1Q') return estocaveisSuppliers1Q;
        if (selectedQuadrimestre === '2Q') return estocaveisSuppliers2Q;
        return estocaveisSuppliers3Q;
    }, [selectedYear, selectedQuadrimestre, estocaveisSuppliers1Q, estocaveisSuppliers2Q, estocaveisSuppliers3Q, estocaveisSuppliers2027_1Q, estocaveisSuppliers2027_2Q, estocaveisSuppliers2027_3Q]);

    const allPereciveisSuppliers = useMemo(() => [
        ...pereciveisSuppliers1Q,
        ...pereciveisSuppliers2Q,
        ...pereciveisSuppliers3Q,
        ...pereciveisSuppliers2027_1Q,
        ...pereciveisSuppliers2027_2Q,
        ...pereciveisSuppliers2027_3Q
    ], [pereciveisSuppliers1Q, pereciveisSuppliers2Q, pereciveisSuppliers3Q, pereciveisSuppliers2027_1Q, pereciveisSuppliers2027_2Q, pereciveisSuppliers2027_3Q]);

    const allEstocaveisSuppliers = useMemo(() => [
        ...estocaveisSuppliers1Q,
        ...estocaveisSuppliers2Q,
        ...estocaveisSuppliers3Q,
        ...estocaveisSuppliers2027_1Q,
        ...estocaveisSuppliers2027_2Q,
        ...estocaveisSuppliers2027_3Q
    ], [estocaveisSuppliers1Q, estocaveisSuppliers2Q, estocaveisSuppliers3Q, estocaveisSuppliers2027_1Q, estocaveisSuppliers2027_2Q, estocaveisSuppliers2027_3Q]);

    const _pereciveisSuppliers = currentPereciveisSuppliers;
    const _estocaveisSuppliers = currentEstocaveisSuppliers;

    useEffect(() => {
        if (!perCapitaConfig) return;

        const newStaffCount = perCapitaConfig.staffCount !== undefined ? (perCapitaConfig.staffCount || 0) : staffCount;
        const newInmateCount = perCapitaConfig.inmateCount !== undefined ? (perCapitaConfig.inmateCount || 0) : inmateCount;

        if (newStaffCount !== staffCount) setStaffCount(newStaffCount);
        if (newInmateCount !== inmateCount) setInmateCount(newInmateCount);
        
        setCustomPerCapita(perCapitaConfig.customValues || {});
        
        if (!isDirty) {
            setSeiProcessNumbers(perCapitaConfig.seiProcessNumbers || {});
            setSeiProcessDefinitions(perCapitaConfig.seiProcessDefinitions || {});
            setMonthlyAdvances(perCapitaConfig.monthlyAdvances || {});
            setMonthlyQuota(perCapitaConfig.monthlyQuota || {});
            setMonthlyResource(perCapitaConfig.monthlyResource || {});
            setPtresResources(perCapitaConfig.ptresResources || {});
            setPpaisProducers(ensureArray(perCapitaConfig.ppaisProducers));
            setPereciveisSuppliers1Q(ensureArray(perCapitaConfig.pereciveisSuppliers1Q));
            
            const p2Q = ensureArray(perCapitaConfig.pereciveisSuppliers2Q);
            setPereciveisSuppliers2Q(p2Q.length > 0 ? p2Q : ensureArray(perCapitaConfig.pereciveisSuppliers));

            setPereciveisSuppliers3Q(ensureArray(perCapitaConfig.pereciveisSuppliers3Q));
            setPereciveisSuppliers2027_1Q(ensureArray(perCapitaConfig.pereciveisSuppliers2027_1Q));
            setPereciveisSuppliers2027_2Q(ensureArray(perCapitaConfig.pereciveisSuppliers2027_2Q));
            setPereciveisSuppliers2027_3Q(ensureArray(perCapitaConfig.pereciveisSuppliers2027_3Q));
            setEstocaveisSuppliers1Q(ensureArray(perCapitaConfig.estocaveisSuppliers1Q));

            const e2Q = ensureArray(perCapitaConfig.estocaveisSuppliers2Q);
            setEstocaveisSuppliers2Q(e2Q.length > 0 ? e2Q : ensureArray(perCapitaConfig.estocaveisSuppliers));

            setEstocaveisSuppliers3Q(ensureArray(perCapitaConfig.estocaveisSuppliers3Q));
            setEstocaveisSuppliers2027_1Q(ensureArray(perCapitaConfig.estocaveisSuppliers2027_1Q));
            setEstocaveisSuppliers2027_2Q(ensureArray(perCapitaConfig.estocaveisSuppliers2027_2Q));
            setEstocaveisSuppliers2027_3Q(ensureArray(perCapitaConfig.estocaveisSuppliers2027_3Q));
        } else {
            if (perCapitaConfig.ppaisProducers) setPpaisProducers(ensureArray(perCapitaConfig.ppaisProducers));
            if (perCapitaConfig.pereciveisSuppliers1Q) setPereciveisSuppliers1Q(ensureArray(perCapitaConfig.pereciveisSuppliers1Q));
            if (perCapitaConfig.pereciveisSuppliers2Q || perCapitaConfig.pereciveisSuppliers) {
                const p2Q = ensureArray(perCapitaConfig.pereciveisSuppliers2Q);
                setPereciveisSuppliers2Q(p2Q.length > 0 ? p2Q : ensureArray(perCapitaConfig.pereciveisSuppliers));
            }
            if (perCapitaConfig.pereciveisSuppliers3Q) setPereciveisSuppliers3Q(ensureArray(perCapitaConfig.pereciveisSuppliers3Q));
            if (perCapitaConfig.pereciveisSuppliers2027_1Q) setPereciveisSuppliers2027_1Q(ensureArray(perCapitaConfig.pereciveisSuppliers2027_1Q));
            if (perCapitaConfig.pereciveisSuppliers2027_2Q) setPereciveisSuppliers2027_2Q(ensureArray(perCapitaConfig.pereciveisSuppliers2027_2Q));
            if (perCapitaConfig.pereciveisSuppliers2027_3Q) setPereciveisSuppliers2027_3Q(ensureArray(perCapitaConfig.pereciveisSuppliers2027_3Q));
            if (perCapitaConfig.estocaveisSuppliers1Q) setEstocaveisSuppliers1Q(ensureArray(perCapitaConfig.estocaveisSuppliers1Q));
            if (perCapitaConfig.estocaveisSuppliers2Q || perCapitaConfig.estocaveisSuppliers) {
                const e2Q = ensureArray(perCapitaConfig.estocaveisSuppliers2Q);
                setEstocaveisSuppliers2Q(e2Q.length > 0 ? e2Q : ensureArray(perCapitaConfig.estocaveisSuppliers));
            }
            if (perCapitaConfig.estocaveisSuppliers3Q) setEstocaveisSuppliers3Q(ensureArray(perCapitaConfig.estocaveisSuppliers3Q));
            if (perCapitaConfig.estocaveisSuppliers2027_1Q) setEstocaveisSuppliers2027_1Q(ensureArray(perCapitaConfig.estocaveisSuppliers2027_1Q));
            if (perCapitaConfig.estocaveisSuppliers2027_2Q) setEstocaveisSuppliers2027_2Q(ensureArray(perCapitaConfig.estocaveisSuppliers2027_2Q));
            if (perCapitaConfig.estocaveisSuppliers2027_3Q) setEstocaveisSuppliers2027_3Q(ensureArray(perCapitaConfig.estocaveisSuppliers2027_3Q));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [perCapitaConfig]);

    useEffect(() => {
        try {
            localStorage.setItem('perCapita_staffCount', staffCount.toString());
            localStorage.setItem('perCapita_inmateCount', inmateCount.toString());
            localStorage.setItem('perCapita_selectedYear', selectedYear.toString());
            localStorage.setItem('perCapita_selectedQuadrimestre', selectedQuadrimestre);
        } catch (e) {
            console.warn("Could not preserve staff/inmate/period count locally:", e);
        }
    }, [staffCount, inmateCount, selectedYear, selectedQuadrimestre]);

    // Sincronizar selectedProducer com as alterações da lista de fornecedores
    useEffect(() => {
        if (selectedProducer) {
            const source = activeSubTab === 'PPAIS' ? ppaisProducers : 
                           (activeSubTab.startsWith('PERECÍVEIS') ? currentPereciveisSuppliers : 
                           (activeSubTab.startsWith('ESTOCÁVEIS') ? currentEstocaveisSuppliers : []));
            const updated = source.find(p => p.id === selectedProducer.id);
            if (updated) {
                if (JSON.stringify(updated) !== JSON.stringify(selectedProducer)) {
                    setSelectedProducer(updated);
                }
            } else {
                setSelectedProducer(null);
            }
        }
    }, [ppaisProducers, currentPereciveisSuppliers, currentEstocaveisSuppliers, activeSubTab, selectedProducer]);

    const handleSave = async () => {
        setIsSaving(true);
        setSaveSuccess(false);

        const safePereciveis2Q = (pereciveisSuppliers2Q && pereciveisSuppliers2Q.length > 0)
            ? pereciveisSuppliers2Q
            : ensureArray(perCapitaConfig?.pereciveisSuppliers);

        const safeEstocaveis2Q = (estocaveisSuppliers2Q && estocaveisSuppliers2Q.length > 0)
            ? estocaveisSuppliers2Q
            : ensureArray(perCapitaConfig?.estocaveisSuppliers);

        const newConfig: PerCapitaConfig = {
            staffCount,
            inmateCount,
            customValues: customPerCapita,
            seiProcessNumbers,
            seiProcessDefinitions,
            monthlyQuota,
            monthlyResource,
            ptresResources,
            ppaisProducers,
            pereciveisSuppliers1Q,
            pereciveisSuppliers2Q: safePereciveis2Q,
            pereciveisSuppliers3Q,
            pereciveisSuppliers2027_1Q,
            pereciveisSuppliers2027_2Q,
            pereciveisSuppliers2027_3Q,
            estocaveisSuppliers1Q,
            estocaveisSuppliers2Q: safeEstocaveis2Q,
            estocaveisSuppliers3Q,
            estocaveisSuppliers2027_1Q,
            estocaveisSuppliers2027_2Q,
            estocaveisSuppliers2027_3Q,
            pereciveisSuppliers: safePereciveis2Q,
            estocaveisSuppliers: safeEstocaveis2Q,
            monthlyAdvances,
        };
        console.log("Saving new configuration:", newConfig);
        try {
            const result = await onUpdatePerCapitaConfig(newConfig);
            if (result && result.success) {
                setIsDirty(false); // Only reset if successful
                setSaveSuccess(true);
                localStorage.removeItem('perCapita_staffCount');
                localStorage.removeItem('perCapita_inmateCount');
            } else {
                toast.error("Erro ao salvar alterações no banco de dados.");
            }
            setTimeout(() => setSaveSuccess(false), 3000);
        } catch (error) {
            console.error("Failed to save per capita config:", error);
            toast.error("Erro ao salvar configurações!");
        } finally {
            setIsSaving(false);
        }
    };

    const handleStaffCountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setStaffCount(parseInt(e.target.value, 10) || 0);
        setIsDirty(true);
    };

    const handleInmateCountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setInmateCount(parseInt(e.target.value, 10) || 0);
        setIsDirty(true);
    };

    const handleSeiNumberChange = (category: string, value: string) => {
        setSeiProcessNumbers(prev => ({ ...prev, [category]: value }));
        setIsDirty(true);
    };

    const handleSeiDefinitionChange = (category: string, value: string) => {
        setSeiProcessDefinitions(prev => ({ ...prev, [category]: value }));
        setIsDirty(true);
    };

    const handleMonthlyValueChange = (type: 'quota' | 'resource', month: string, value: string) => {
        const numValue = parseFloat(value) || 0;
        if (type === 'quota') {
            setMonthlyQuota(prev => ({ ...prev, [month]: numValue }));
        } else {
            setMonthlyResource(prev => ({ ...prev, [month]: numValue }));
        }
        setIsDirty(true);
    };

    const handleMonthlyAdvanceChange = (month: string, value: string) => {
        const numValue = parseFloat(value) || 0;
        setMonthlyAdvances(prev => ({ ...prev, [month]: numValue }));
        setIsDirty(true);
    };

    const handleUpdateProducers = useCallback(async (newProducers: PerCapitaSupplier[]) => {
        setPpaisProducers(newProducers);
        const newConfig: PerCapitaConfig = {
            ...perCapitaConfig,
            ppaisProducers: newProducers,
        };
        try {
            const result = await onUpdatePerCapitaConfig({ ppaisProducers: newProducers });
            if (result && result.success) {
                setIsDirty(false);
                toast.success('Produtores PPAIS salvos com sucesso!');
                if (onSyncPPAISToAgenda) {
                    await onSyncPPAISToAgenda(newConfig);
                }
            } else {
                console.error("Erro ao salvar produtores:", result);
                toast.error("Erro ao salvar produtores: " + (result?.message || 'Erro desconhecido'));
            }
        } catch (error) {
            console.error("Failed to save producers:", error);
            toast.error("Erro ao salvar produtores.");
        }
    }, [onUpdatePerCapitaConfig, onSyncPPAISToAgenda, perCapitaConfig]);

    const handleUpdatePereciveisSuppliers = useCallback(async (newSuppliers: PerCapitaSupplier[]) => {
        let field: keyof PerCapitaConfig;
        if (selectedYear === 2027) {
            field = selectedQuadrimestre === '1Q' ? 'pereciveisSuppliers2027_1Q' :
                    selectedQuadrimestre === '2Q' ? 'pereciveisSuppliers2027_2Q' :
                    'pereciveisSuppliers2027_3Q';
            if (selectedQuadrimestre === '1Q') setPereciveisSuppliers2027_1Q(newSuppliers);
            else if (selectedQuadrimestre === '2Q') setPereciveisSuppliers2027_2Q(newSuppliers);
            else setPereciveisSuppliers2027_3Q(newSuppliers);
        } else {
            field = selectedQuadrimestre === '1Q' ? 'pereciveisSuppliers1Q' :
                    selectedQuadrimestre === '2Q' ? 'pereciveisSuppliers2Q' :
                    'pereciveisSuppliers3Q';
            if (selectedQuadrimestre === '1Q') setPereciveisSuppliers1Q(newSuppliers);
            else if (selectedQuadrimestre === '2Q') setPereciveisSuppliers2Q(newSuppliers);
            else setPereciveisSuppliers3Q(newSuppliers);
        }

        const updatePayload: Partial<PerCapitaConfig> = { [field]: newSuppliers };
        if (selectedYear === 2026 && selectedQuadrimestre === '2Q') {
            updatePayload.pereciveisSuppliers = newSuppliers;
        }

        const newConfig: PerCapitaConfig = {
            ...perCapitaConfig,
            ...updatePayload,
        };
        try {
            const result = await onUpdatePerCapitaConfig(updatePayload);
            if (result && result.success) {
                setIsDirty(false);
                toast.success(`Fornecedores de Perecíveis (${selectedYear} - ${selectedQuadrimestre}) salvos com sucesso!`);
                if (onSyncPPAISToAgenda) {
                    await onSyncPPAISToAgenda(newConfig);
                }
            } else {
                toast.error("Erro ao salvar fornecedores: " + (result?.message || 'Erro desconhecido'));
            }
        } catch {
            toast.error("Erro ao salvar fornecedores.");
        }
    }, [selectedYear, selectedQuadrimestre, onUpdatePerCapitaConfig, onSyncPPAISToAgenda, perCapitaConfig]);

    const handleUpdateEstocaveisSuppliers = useCallback(async (newSuppliers: PerCapitaSupplier[]) => {
        let field: keyof PerCapitaConfig;
        if (selectedYear === 2027) {
            field = selectedQuadrimestre === '1Q' ? 'estocaveisSuppliers2027_1Q' :
                    selectedQuadrimestre === '2Q' ? 'estocaveisSuppliers2027_2Q' :
                    'estocaveisSuppliers2027_3Q';
            if (selectedQuadrimestre === '1Q') setEstocaveisSuppliers2027_1Q(newSuppliers);
            else if (selectedQuadrimestre === '2Q') setEstocaveisSuppliers2027_2Q(newSuppliers);
            else setEstocaveisSuppliers2027_3Q(newSuppliers);
        } else {
            field = selectedQuadrimestre === '1Q' ? 'estocaveisSuppliers1Q' :
                    selectedQuadrimestre === '2Q' ? 'estocaveisSuppliers2Q' :
                    'estocaveisSuppliers3Q';
            if (selectedQuadrimestre === '1Q') setEstocaveisSuppliers1Q(newSuppliers);
            else if (selectedQuadrimestre === '2Q') setEstocaveisSuppliers2Q(newSuppliers);
            else setEstocaveisSuppliers3Q(newSuppliers);
        }

        const updatePayload: Partial<PerCapitaConfig> = { [field]: newSuppliers };
        if (selectedYear === 2026 && selectedQuadrimestre === '2Q') {
            updatePayload.estocaveisSuppliers = newSuppliers;
        }

        const newConfig: PerCapitaConfig = {
            ...perCapitaConfig,
            ...updatePayload,
        };
        try {
            const result = await onUpdatePerCapitaConfig(updatePayload);
            if (result && result.success) {
                setIsDirty(false);
                toast.success(`Fornecedores de Estocáveis (${selectedYear} - ${selectedQuadrimestre}) salvos com sucesso!`);
                if (onSyncPPAISToAgenda) {
                    await onSyncPPAISToAgenda(newConfig);
                }
            } else {
                toast.error("Erro ao salvar fornecedores: " + (result?.message || 'Erro desconhecido'));
            }
        } catch {
            toast.error("Erro ao salvar fornecedores.");
        }
    }, [selectedYear, selectedQuadrimestre, onUpdatePerCapitaConfig, onSyncPPAISToAgenda, perCapitaConfig]);

    const ppaisAsSuppliers = useMemo(() => {
        return ppaisProducers.filter(Boolean).map(p => ({
            ...p,
            cpf: p.cpfCnpj || p.cpf,
            deliveries: ensureArray(p.deliveries),
            allowedWeeks: calculateAllowedWeeksFromSchedule(p.monthlySchedule, 2026),
            initialValue: ensureArray(p.contractItems).reduce((acc: any, curr: any) => acc + (curr.totalKg * (curr.valuePerKg || 0)), 0)
        } as Supplier));
    }, [ppaisProducers]);

    const pereciveisAsSuppliers = useMemo(() => {
        return currentPereciveisSuppliers.filter(Boolean).map(p => ({
            ...p,
            cpf: p.cpfCnpj || p.cpf,
            deliveries: ensureArray(p.deliveries),
            allowedWeeks: calculateAllowedWeeksFromSchedule(p.monthlySchedule, selectedYear),
            initialValue: ensureArray(p.contractItems).reduce((acc: any, curr: any) => acc + (curr.totalKg * (curr.valuePerKg || 0)), 0)
        } as Supplier));
    }, [currentPereciveisSuppliers, selectedYear]);

    const estocaveisAsSuppliers = useMemo(() => {
        return currentEstocaveisSuppliers.filter(Boolean).map(p => ({
            ...p,
            cpf: p.cpfCnpj || p.cpf,
            deliveries: ensureArray(p.deliveries),
            allowedWeeks: calculateAllowedWeeksFromSchedule(p.monthlySchedule, selectedYear),
            initialValue: ensureArray(p.contractItems).reduce((acc: any, curr: any) => acc + (curr.totalKg * (curr.valuePerKg || 0)), 0)
        } as Supplier));
    }, [currentEstocaveisSuppliers, selectedYear]);

    const otherPereciveisQuadrimestres = useMemo(() => {
        const all = [
            { label: '1º Quadrimestre (Jan - Abr / 2026)', q: '1Q', y: 2026, list: pereciveisSuppliers1Q },
            { label: '2º Quadrimestre (Mai - Ago / 2026)', q: '2Q', y: 2026, list: pereciveisSuppliers2Q },
            { label: '3º Quadrimestre (Set - Dez / 2026)', q: '3Q', y: 2026, list: pereciveisSuppliers3Q },
            { label: '1º Quadrimestre (Jan - Abr / 2027)', q: '1Q', y: 2027, list: pereciveisSuppliers2027_1Q },
            { label: '2º Quadrimestre (Mai - Ago / 2027)', q: '2Q', y: 2027, list: pereciveisSuppliers2027_2Q },
            { label: '3º Quadrimestre (Set - Dez / 2027)', q: '3Q', y: 2027, list: pereciveisSuppliers2027_3Q },
        ];
        return all
            .filter(item => !(item.q === selectedQuadrimestre && item.y === selectedYear))
            .map(item => ({ label: item.label, suppliers: item.list }));
    }, [selectedQuadrimestre, selectedYear, pereciveisSuppliers1Q, pereciveisSuppliers2Q, pereciveisSuppliers3Q, pereciveisSuppliers2027_1Q, pereciveisSuppliers2027_2Q, pereciveisSuppliers2027_3Q]);

    const otherEstocaveisQuadrimestres = useMemo(() => {
        const all = [
            { label: '1º Quadrimestre (Jan - Abr / 2026)', q: '1Q', y: 2026, list: estocaveisSuppliers1Q },
            { label: '2º Quadrimestre (Mai - Ago / 2026)', q: '2Q', y: 2026, list: estocaveisSuppliers2Q },
            { label: '3º Quadrimestre (Set - Dez / 2026)', q: '3Q', y: 2026, list: estocaveisSuppliers3Q },
            { label: '1º Quadrimestre (Jan - Abr / 2027)', q: '1Q', y: 2027, list: estocaveisSuppliers2027_1Q },
            { label: '2º Quadrimestre (Mai - Ago / 2027)', q: '2Q', y: 2027, list: estocaveisSuppliers2027_2Q },
            { label: '3º Quadrimestre (Set - Dez / 2027)', q: '3Q', y: 2027, list: estocaveisSuppliers2027_3Q },
        ];
        return all
            .filter(item => !(item.q === selectedQuadrimestre && item.y === selectedYear))
            .map(item => ({ label: item.label, suppliers: item.list }));
    }, [selectedQuadrimestre, selectedYear, estocaveisSuppliers1Q, estocaveisSuppliers2Q, estocaveisSuppliers3Q, estocaveisSuppliers2027_1Q, estocaveisSuppliers2027_2Q, estocaveisSuppliers2027_3Q]);

    const handleUpdateContractForCurrentQuadrimestre = useCallback(async (
        itemName: string,
        assignments: { supplierCpf: string; totalKg: number; valuePerKg: number; unit?: string; category?: string; comprasCode?: string; becCode?: string; commitmentNumber?: string; commitmentValue?: number; supplierName?: string }[]
    ) => {
        if (activeSubTab === 'PPAIS') {
            return await onUpdateContractForItem(itemName, assignments);
        }

        const isPereciveis = activeSubTab.startsWith('PERECÍVEIS');
        const isEstocaveis = activeSubTab.startsWith('ESTOCÁVEIS');

        if (!isPereciveis && !isEstocaveis) {
            return await onUpdateContractForItem(itemName, assignments);
        }

        const currentList = isPereciveis ? currentPereciveisSuppliers : currentEstocaveisSuppliers;
        const cleanNorm = (s: string) => String(s || '').trim().toUpperCase().replace(/\s+/g, ' ');
        const normItemName = cleanNorm(itemName);

        const updatedSuppliers = currentList.map(sup => {
            const supCpf = String(sup.cpfCnpj || sup.cpf || '').replace(/[^\d]/g, '');
            const matchingAssignment = assignments.find(a => String(a.supplierCpf || '').replace(/[^\d]/g, '') === supCpf);

            const currentContractItems = ensureArray(sup.contractItems);
            const filteredItems = currentContractItems.filter(ci => cleanNorm(ci.name) !== normItemName);

            if (matchingAssignment && matchingAssignment.totalKg > 0) {
                const newItem = {
                    name: itemName,
                    totalKg: matchingAssignment.totalKg,
                    valuePerKg: matchingAssignment.valuePerKg,
                    unit: matchingAssignment.unit || 'KG',
                    monthlyWeight: matchingAssignment.totalKg / 4,
                    monthlyValue: (matchingAssignment.totalKg * (matchingAssignment.valuePerKg || 0)) / 4,
                    commitmentNumber: matchingAssignment.commitmentNumber || '',
                    commitmentValue: matchingAssignment.commitmentValue || 0,
                    comprasCode: matchingAssignment.comprasCode || '',
                    becCode: matchingAssignment.becCode || ''
                };
                return {
                    ...sup,
                    contractItems: [...filteredItems, newItem]
                };
            } else {
                return {
                    ...sup,
                    contractItems: filteredItems
                };
            }
        });

        if (isPereciveis) {
            await handleUpdatePereciveisSuppliers(updatedSuppliers);
        } else {
            await handleUpdateEstocaveisSuppliers(updatedSuppliers);
        }

        const targetAcq = acquisitionItems.find(i => 
            (cleanNorm(i.name) === normItemName || cleanNorm(i.contractItemName || '') === normItemName) &&
            i.category === (isPereciveis ? 'PERECÍVEIS' : 'ESTOCÁVEIS') &&
            (i.quadrimestre || '2Q') === selectedQuadrimestre &&
            (i.year || 2026) === selectedYear
        );

        if (targetAcq && assignments.length > 0) {
            const totalKg = assignments.reduce((acc, curr) => acc + (curr.totalKg || 0), 0);
            const validPrice = assignments.find(a => (a.valuePerKg || 0) > 0)?.valuePerKg;
            if (totalKg > 0 || (validPrice !== undefined && validPrice > 0)) {
                await onUpdateAcquisitionItem({
                    ...targetAcq,
                    acquiredQuantity: totalKg > 0 ? totalKg : targetAcq.acquiredQuantity,
                    unitValue: (validPrice !== undefined && validPrice > 0) ? validPrice : targetAcq.unitValue
                });
            }
        }

        return { success: true, message: 'Distribuição e valores salvos com sucesso no quadrimestre!' };
    }, [
        activeSubTab,
        onUpdateContractForItem,
        currentPereciveisSuppliers,
        currentEstocaveisSuppliers,
        handleUpdatePereciveisSuppliers,
        handleUpdateEstocaveisSuppliers,
        acquisitionItems,
        selectedQuadrimestre,
        selectedYear,
        onUpdateAcquisitionItem
    ]);

    const contractItemNamesByCategory = useMemo(() => {
        const result: Record<string, string[]> = {
            'PPAIS': [],
            'PERECÍVEIS': [],
            'ESTOCÁVEIS': [],
            'OTHERS': []
        };

        const ppaisNames = new Set<string>();
        ppaisProducers.forEach(s => {
            ensureArray(s.contractItems).forEach((ci: any) => ppaisNames.add(ci.name));
        });
        result['PPAIS'] = Array.from(ppaisNames).sort();

        const pereciveisNames = new Set<string>();
        [...pereciveisSuppliers1Q, ...pereciveisSuppliers2Q, ...pereciveisSuppliers3Q].forEach(s => {
            ensureArray(s.contractItems).forEach((ci: any) => pereciveisNames.add(ci.name));
        });
        result['PERECÍVEIS'] = Array.from(pereciveisNames).sort();

        const estocaveisNames = new Set<string>();
        [...estocaveisSuppliers1Q, ...estocaveisSuppliers2Q, ...estocaveisSuppliers3Q].forEach(s => {
            ensureArray(s.contractItems).forEach((ci: any) => estocaveisNames.add(ci.name));
        });
        result['ESTOCÁVEIS'] = Array.from(estocaveisNames).sort();

        const otherNames = new Set<string>();
        suppliers.forEach(s => {
            ensureArray(s.contractItems).forEach((ci: any) => otherNames.add(ci.name));
        });
        result['OTHERS'] = Array.from(otherNames).sort();

        return result;
    }, [suppliers, ppaisProducers, pereciveisSuppliers1Q, pereciveisSuppliers2Q, pereciveisSuppliers3Q, estocaveisSuppliers1Q, estocaveisSuppliers2Q, estocaveisSuppliers3Q]);

    const itemData = useMemo(() => {
      const data = new Map<string, { totalQuantity: number; totalValue: number; monthlyWeight: number; monthlyValue: number; unit: string; category: string }>();
      
      const allSources = [...suppliers, ...ppaisAsSuppliers, ...pereciveisAsSuppliers, ...estocaveisAsSuppliers];
      
      allSources.forEach(p => {
        Object.values(p.contractItems || {}).forEach((item: any) => {
          const current = data.get(item.name) || { 
            totalQuantity: 0, 
            totalValue: 0,
            monthlyWeight: 0,
            monthlyValue: 0,
            unit: item.unit || 'kg-1',
            category: item.category || 'OUTROS'
          };
          
          current.totalQuantity += item.totalKg;
          current.monthlyWeight += (item.monthlyWeight || 0);

          const itemTotalValue = (item.totalKg || 0) * (item.valuePerKg || 0);
          current.totalValue += itemTotalValue;
          current.monthlyValue += (item.monthlyValue || 0);

          data.set(item.name, current);
        });
      });
      return Array.from(data.entries())
        .map(([name, values]) => ({ name, ...values }))
        .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    }, [suppliers, ppaisAsSuppliers, pereciveisAsSuppliers, estocaveisAsSuppliers]);

    const perCapitaDenominator = useMemo(() => {
        return inmateCount + staffCount;
    }, [inmateCount, staffCount]);

    const totalPerCapitaKg = useMemo(() => {
        if (perCapitaDenominator === 0) return 0;
        
        // Cálculo ponderado da média mensal de peso
        let totalMonthlyWeight = 0;
        const categoriesToCalculate = ['PPAIS', 'ESTOCÁVEIS', 'PERECÍVEIS', 'KIT PPL', 'PRODUTOS DE LIMPEZA', 'AUTOMAÇÃO', 'EPI'];
        
        categoriesToCalculate.forEach(cat => {
            // Tentar obter dados do planejamento (acquisitionItems) e do contrato (itemData)
            const acqItems = acquisitionItems.filter(ai => ai.category === cat);
            
            const catWeight = acqItems.reduce((sum, ai) => {
                const contracted = itemData.find(id => normalizeItemName(id.name) === normalizeItemName(ai.name));
                
                // Prioritize monthlyWeight from contract
                if (contracted && contracted.monthlyWeight > 0) {
                    const [unitType] = (ai.unit || 'kg-1').split('-');
                    if (['litro', 'embalagem', 'caixa', 'dz'].some(u => unitType.includes(u))) return sum;
                    return sum + contracted.monthlyWeight;
                }

                const weight = (contracted && contracted.totalQuantity > 0) ? contracted.totalQuantity : (ai.acquiredQuantity || 0);
                
                const [unitType] = (ai.unit || 'kg-1').split('-');
                if (['litro', 'embalagem', 'caixa', 'dz'].some(u => unitType.includes(u))) return sum;
                
                const divisor = 8;
                
                return sum + roundToTwoDecimalPlaces(weight / divisor);
            }, 0);

            // Adicionar itens que estão no contrato mas não no planejamento
            const onlyContractWeight = itemData
                .filter(id => id.category === cat && !acqItems.some(ai => normalizeItemName(ai.name) === normalizeItemName(id.name)))
                .reduce((sum, id) => {
                    const [unitType] = (id.unit || 'kg-1').split('-');
                    if (['litro', 'embalagem', 'caixa', 'dz'].some(u => unitType.includes(u))) return sum;
                    
                    if (id.monthlyWeight > 0) return sum + id.monthlyWeight;

                    const divisor = 8;
                    
                    return sum + roundToTwoDecimalPlaces((id.totalQuantity || 0) / divisor);
                }, 0);

            totalMonthlyWeight += catWeight + onlyContractWeight;
        });

        // Média mensal dividida por 30 para obter a média diária
        return (totalMonthlyWeight / perCapitaDenominator) / 30;
    }, [itemData, perCapitaDenominator, acquisitionItems]);
    
    const totalPerCapitaValue = useMemo(() => {
        if (perCapitaDenominator === 0) return 0;
        
        // Cálculo ponderado da média mensal de valor
        let totalMonthlyValue = 0;
        const categoriesToCalculate = ['PPAIS', 'ESTOCÁVEIS', 'PERECÍVEIS', 'KIT PPL', 'PRODUTOS DE LIMPEZA', 'AUTOMAÇÃO', 'EPI'];

        categoriesToCalculate.forEach(cat => {
            // Tentar obter dados do planejamento (acquisitionItems) e do contrato (itemData)
            const acqItems = acquisitionItems.filter(ai => ai.category === cat);
            const totalFromAcq = acqItems.reduce((sum, ai) => {
                const contracted = itemData.find(id => normalizeItemName(id.name) === normalizeItemName(ai.name));
                
                // Prioritize monthlyValue from contract
                if (contracted && contracted.monthlyValue > 0) return sum + contracted.monthlyValue;

                const value = (contracted && contracted.totalValue > 0) ? contracted.totalValue : ((ai.unitValue || 0) * (ai.acquiredQuantity || 0));
                
                const divisor = 8;

                return sum + roundToTwoDecimalPlaces(value / divisor);
            }, 0);

            // Adicionar itens que estão no contrato mas não no planejamento
            const totalOnlyInContract = itemData
                .filter(id => id.category === cat && !acqItems.some(ai => normalizeItemName(ai.name) === normalizeItemName(id.name)))
                .reduce((sum, id) => {
                    if (id.monthlyValue > 0) return sum + id.monthlyValue;
                    
                    const divisor = 8;
                    
                    return sum + roundToTwoDecimalPlaces((id.totalValue || 0) / divisor);
                }, 0);

            totalMonthlyValue += totalFromAcq + totalOnlyInContract;
        });

        // Média mensal dividida por 30 para obter o custo diário
        return (totalMonthlyValue / perCapitaDenominator) / 30;
    }, [itemData, perCapitaDenominator, acquisitionItems]);

    const activeCategories = useMemo(() => {
        return ['PPAIS', 'KIT PPL', 'PERECÍVEIS', 'ESTOCÁVEIS', 'AUTOMAÇÃO', 'PRODUTOS DE LIMPEZA', 'EPI'].filter(cat => {
            return (seiProcessDefinitions[cat] && seiProcessDefinitions[cat].trim() !== '') || 
                   (seiProcessNumbers[cat] && seiProcessNumbers[cat].trim() !== '');
        });
    }, [seiProcessDefinitions, seiProcessNumbers]);

    const monthlyExecution = useMemo(() => {
        const execution: Record<string, Record<string, number>> = {};
        months.forEach(m => {
            execution[m] = {
                'PPAIS': 0,
                'KIT PPL': 0,
                'ESTOCÁVEIS': 0,
                'PERECÍVEIS': 0,
                'AUTOMAÇÃO': 0,
                'PRODUTOS DE LIMPEZA': 0,
                'EPI': 0
            };
        });

        const getMonthFromDate = (dateStr?: string) => {
            if (!dateStr) return null;
            const d = new Date(dateStr + 'T12:00:00');
            return months[d.getMonth()];
        };

        // 1. Regular Suppliers
        suppliers.forEach(s => {
            (Object.values(s.deliveries || {}) as Delivery[]).forEach(d => {
                const m = getMonthFromDate(d.date);
                if (!m) return;
                
                const normalizedDelItem = normalizeItemName(d.item || '');
                const acqItem = acquisitionItems.find(ai => normalizeItemName(ai.name) === normalizedDelItem);
                
                if (acqItem) {
                    if (execution[m][acqItem.category] !== undefined) {
                        execution[m][acqItem.category] += d.value || 0;
                    }
                } else {
                    const contractItem = s.contractItems?.find(ci => normalizeItemName(ci.name) === normalizedDelItem);
                    if (contractItem && contractItem.category && contractItem.category !== 'OUTROS') {
                        if (execution[m][contractItem.category] !== undefined) {
                            execution[m][contractItem.category] += d.value || 0;
                        }
                    }
                }
            });
        });

        // 2. PPAIS Producers
        ppaisProducers.forEach(p => {
            (Object.values(p.deliveries || {}) as Delivery[]).forEach(d => {
                const m = getMonthFromDate(d.date);
                if (m && execution[m]) {
                    execution[m]['PPAIS'] = (execution[m]['PPAIS'] || 0) + (Number(d.value) || 0);
                }
            });
        });

        // 3. Pereciveis Suppliers
        allPereciveisSuppliers.forEach(p => {
            (Object.values(p.deliveries || {}) as Delivery[]).forEach(d => {
                const m = getMonthFromDate(d.date);
                if (m && execution[m]) {
                    execution[m]['PERECÍVEIS'] = (execution[m]['PERECÍVEIS'] || 0) + (Number(d.value) || 0);
                }
            });
        });

        // 4. Estocaveis Suppliers
        allEstocaveisSuppliers.forEach(p => {
            (Object.values(p.deliveries || {}) as Delivery[]).forEach(d => {
                const m = getMonthFromDate(d.date);
                if (m && execution[m]) {
                    execution[m]['ESTOCÁVEIS'] = (execution[m]['ESTOCÁVEIS'] || 0) + (Number(d.value) || 0);
                }
            });
        });

        return execution;
    }, [suppliers, ppaisProducers, allPereciveisSuppliers, allEstocaveisSuppliers, acquisitionItems]);

    const categoryMonthlyAverages = useMemo(() => {
        const averages: Record<string, number> = {};
        activeCategories.forEach(cat => {
            // Tentar obter dados do planejamento (acquisitionItems) e do contrato (itemData)
            const acqItems = acquisitionItems.filter(ai => ai.category === cat);
            const totalFromAcq = acqItems.reduce((sum, ai) => {
                const contracted = itemData.find(id => normalizeItemName(id.name) === normalizeItemName(ai.name));
                if (contracted && contracted.totalValue > 0) return sum + contracted.totalValue;
                return sum + ((ai.unitValue || 0) * (ai.acquiredQuantity || 0));
            }, 0);

            // Adicionar itens que estão no contrato mas não no planejamento
            const totalOnlyInContract = itemData
                .filter(id => id.category === cat && !acqItems.some(ai => normalizeItemName(ai.name) === normalizeItemName(id.name)))
                .reduce((sum, id) => sum + (id.totalValue || 0), 0);

            const total = totalFromAcq + totalOnlyInContract;
            
            const divisor = 8; // requested by user (all categories 8 months)
            averages[cat] = total / divisor;
        });
        return averages;
    }, [activeCategories, itemData, acquisitionItems]);

    const getIsActiveMonth = (month: string, category: string) => {
        if (category === 'PERECÍVEIS') {
            return ['Maio', 'Junho', 'Julho', 'Agosto'].includes(month);
        }
        if (category === 'PERECÍVEIS 3Q') {
            return ['Setembro', 'Outubro', 'Novembro', 'Dezembro'].includes(month);
        }
        if (category === 'ESTOCÁVEIS') {
            return ['Maio', 'Junho', 'Julho', 'Agosto'].includes(month);
        }
        if (category === 'ESTOCÁVEIS 3Q') {
            return ['Setembro', 'Outubro', 'Novembro', 'Dezembro'].includes(month);
        }
        if (category === 'PPAIS') {
            return ['Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'].includes(month);
        }
        // Para outras categorias, manter o comportamento de quadrimesters se aplicável
        // ou retornar true se for anual. 
        // Baseado no código original, retornava true para tudo.
        return true;
    };

    const financialSummary = useMemo(() => {
        const totalGeralGasto = activeCategories.reduce((sum, cat) => {
            let catTotal = 0;
            months.forEach(month => {
                const execVal = monthlyExecution[month]?.[cat] || 0;
                const isActiveMonth = getIsActiveMonth(month, cat);
                const futureVal = isActiveMonth ? (categoryMonthlyAverages[cat] || 0) : 0;
                if (isActiveMonth) {
                    catTotal += execVal > 0 ? execVal : futureVal;
                }
            });
            return sum + catTotal;
        }, 0) + (Object.values(monthlyAdvances) as number[]).reduce((a: number, b: number) => a + (b || 0), 0);

        const totalGeralCotas = (Object.values(monthlyQuota) as number[]).reduce((a: number, b: number) => a + (b || 0), 0);
        
        const diff = totalGeralGasto - totalGeralCotas;
        
        return {
            totalGeralGasto,
            totalGeralCotas,
            diff
        };
    }, [activeCategories, monthlyExecution, categoryMonthlyAverages, monthlyAdvances, monthlyQuota]);

    const deliveryStats = useMemo(() => {
        const stats: Record<string, { name: string, total: number, value: number }> = {};
        const allSources = [...(suppliers || []), ...ppaisAsSuppliers, ...pereciveisAsSuppliers, ...estocaveisAsSuppliers];
        
        allSources.forEach(s => {
            const deliveries = (Object.values(s.deliveries || {}) as any[]);
            deliveries.forEach(d => {
                if (d.kg > 0) {
                    const itemName = d.item || 'Outros';
                    if (!stats[itemName]) {
                        stats[itemName] = { name: itemName, total: 0, value: 0 };
                    }
                    stats[itemName].total += d.kg;
                    stats[itemName].value += (d.value || 0);
                }
            });
        });
        
        return Object.values(stats).sort((a, b) => b.total - a.total).slice(0, 10); // Top 10 items
    }, [suppliers, ppaisAsSuppliers, pereciveisAsSuppliers, estocaveisAsSuppliers]);

    const auditInconsistencies = useMemo(() => {
        const issues: { type: string, description: string, supplierName?: string, itemName?: string, category?: string, fix: () => Promise<void> }[] = [];
        
        const acqItemNames = new Set(acquisitionItems.map(ai => normalizeItemName(ai.name)));
        
        // 1. Check for items in supplier contracts that don't exist in acquisition items
        suppliers.forEach(s => {
            (Object.values(s.contractItems || {}) as any[]).forEach(ci => {
                const normalizedCi = normalizeItemName(ci.name);
                if (!acqItemNames.has(normalizedCi)) {
                    issues.push({
                        type: 'Item Fantasma',
                        description: `O item "${ci.name}" está no contrato de ${s.name} mas não existe no Planejamento Per Capita.`,
                        supplierName: s.name,
                        itemName: ci.name,
                        fix: async () => {
                            await onUpdateContractForItem(ci.name, []); 
                            toast.success(`Item "${ci.name}" removido de ${s.name}`);
                        }
                    });
                }
            });
        });

        // 2. Check for producers/pereciveis in perCapitaConfig with ghost items
        ppaisProducers.forEach(p => {
            (Object.values(p.contractItems || {}) as any[]).forEach(ci => {
                const normalizedCi = normalizeItemName(ci.name);
                if (!acqItemNames.has(normalizedCi)) {
                    issues.push({
                        type: 'Item Fantasma (PPAIS)',
                        description: `O item "${ci.name}" está no contrato PPAIS de ${p.name} mas não existe no Planejamento Per Capita.`,
                        supplierName: p.name,
                        itemName: ci.name,
                        fix: async () => {
                            const updatedProducers = ppaisProducers.map(prod => {
                                if (prod.cpfCnpj === p.cpfCnpj) {
                                    return { ...prod, contractItems: (prod.contractItems || []).filter(item => normalizeItemName(item.name) !== normalizedCi) };
                                }
                                return prod;
                            });
                            await handleUpdateProducers(updatedProducers);
                            toast.success(`Item "${ci.name}" removido de ${p.name}`);
                        }
                    });
                }
            });
        });

        currentPereciveisSuppliers.forEach(p => {
            (Object.values(p.contractItems || {}) as any[]).forEach(ci => {
                const normalizedCi = normalizeItemName(ci.name);
                if (!acqItemNames.has(normalizedCi)) {
                    issues.push({
                        type: 'Item Fantasma (Perecíveis)',
                        description: `O item "${ci.name}" está no contrato de Perecíveis de ${p.name} mas não existe no Planejamento Per Capita.`,
                        supplierName: p.name,
                        itemName: ci.name,
                        fix: async () => {
                            const updatedSuppliers = currentPereciveisSuppliers.map(prod => {
                                if (prod.cpfCnpj === p.cpfCnpj) {
                                    return { ...prod, contractItems: (prod.contractItems || []).filter(item => normalizeItemName(item.name) !== normalizedCi) };
                                }
                                return prod;
                            });
                            await handleUpdatePereciveisSuppliers(updatedSuppliers);
                            toast.success(`Item "${ci.name}" removido de ${p.name}`);
                        }
                    });
                }
            });
        });

        // 3. Check for items in deliveries that are missing from the contract
        const allSources = [...(suppliers || []), ...ppaisAsSuppliers, ...pereciveisAsSuppliers, ...estocaveisAsSuppliers];
        allSources.forEach(s => {
            const contractItemNames = new Set((Object.values(s.contractItems || {}) as any[]).map(ci => normalizeItemName(ci.name)));
            const deliveries = (Object.values(s.deliveries || {}) as any[]);
            
            deliveries.forEach(d => {
                if (d.item && d.item !== 'AGENDAMENTO PENDENTE') {
                    const normalizedItem = normalizeItemName(d.item);
                    if (!contractItemNames.has(normalizedItem)) {
                        issues.push({
                            type: 'Item não Contratado',
                            description: `O item "${d.item || d.itemName || ''}" consta em entregas/agendamentos de ${s.name} mas não está em seu contrato.`,
                            supplierName: s.name,
                            itemName: d.item,
                            fix: async () => {
                                toast.info(`O item "${d.item || d.itemName || ''}" precisa ser vinculado ao contrato de ${s.name} manualmente através do planejamento de itens.`);
                            }
                        });
                    }
                }
            });
        });

        return issues;
    }, [suppliers, ppaisProducers, currentPereciveisSuppliers, acquisitionItems, onUpdateContractForItem, ppaisAsSuppliers, pereciveisAsSuppliers, estocaveisAsSuppliers, handleUpdatePereciveisSuppliers, handleUpdateProducers]);

    const handleFixAllInconsistencies = async () => {
        setIsSaving(true);
        try {
            for (const issue of auditInconsistencies) {
                await issue.fix();
            }
            toast.success('Todas as inconsistências foram corrigidas!');
        } catch {
            toast.error('Erro ao corrigir inconsistências.');
        } finally {
            setIsSaving(false);
        }
    };

    const contractedItemsSummary = useMemo(() => {
        const summary = new Map<string, { contracted: number; received: number; remaining: number; unit: string; originalName: string; suppliers: Set<string>; empenhos: Set<string>; addendum: number }>();
        const allSources = [...(suppliers || []), ...ppaisAsSuppliers, ...pereciveisAsSuppliers, ...estocaveisAsSuppliers];

        allSources.forEach(supplier => {
            supplier.contractItems?.forEach(item => {
                const normalizedName = normalizeItemName(item.name);
                if (!summary.has(normalizedName)) {
                    const acqItem = acquisitionItems.find(ai => normalizeItemName(ai.name) === normalizedName);
                    summary.set(normalizedName, { 
                        contracted: 0, 
                        received: 0, 
                        remaining: 0, 
                        unit: item.unit || 'KG', 
                        originalName: item.name, 
                        suppliers: new Set(), 
                        empenhos: new Set(),
                        addendum: acqItem?.contractAddendum || 0
                    });
                }
                const data = summary.get(normalizedName)!;
                data.contracted += item.totalKg || 0;
                data.suppliers.add(supplier.name);
                summary.set(normalizedName, data);
            });

            (Object.values(supplier.deliveries || {}) as Delivery[]).forEach(delivery => {
                const normalizedName = normalizeItemName(delivery.item || '');
                if (normalizedName && summary.has(normalizedName)) {
                    const data = summary.get(normalizedName)!;
                    data.received += delivery.kg || 0;
                    if (delivery.receiptTermNumber) {
                        data.empenhos.add(delivery.receiptTermNumber);
                    }
                    summary.set(normalizedName, data);
                }
            });
        });

        const result = Array.from(summary.entries()).map(([, data]) => {
            const totalContracted = data.contracted + data.addendum;
            const percentage = totalContracted > 0 ? (data.received / totalContracted) * 100 : 0;
            let status = 'NORMAL';
            if (data.received === 0) status = 'SEM_ENTREGA';
            else if (percentage >= 100) status = 'CONCLUIDO';
            else if (percentage >= 70) status = 'AVANCADO';
            else if (percentage < 50) status = 'ATENCAO';

            return {
                name: data.originalName,
                contracted: totalContracted,
                received: data.received,
                remaining: Math.max(0, totalContracted - data.received),
                unit: data.unit,
                percentage,
                status,
                suppliers: Array.from(data.suppliers),
                empenhos: Array.from(data.empenhos),
                hasEmpenho: data.empenhos.size > 0
            };
        }).sort((a, b) => (a.name || '').localeCompare(b.name || ''));

        return result;
    }, [suppliers, ppaisAsSuppliers, pereciveisAsSuppliers, estocaveisAsSuppliers, acquisitionItems]);

    const filteredComparison = useMemo(() => {
        if (comparisonFilter === 'TODOS') return contractedItemsSummary;
        if (comparisonFilter === 'SEM_ENTREGA') return contractedItemsSummary.filter(i => i.status === 'SEM_ENTREGA');
        if (comparisonFilter === 'ATENCAO') return contractedItemsSummary.filter(i => i.status === 'ATENCAO');
        if (comparisonFilter === 'AVANCADO') return contractedItemsSummary.filter(i => i.status === 'AVANCADO');
        if (comparisonFilter === 'CONCLUIDO') return contractedItemsSummary.filter(i => i.status === 'CONCLUIDO');
        if (comparisonFilter === 'COM_EMPENHO') return contractedItemsSummary.filter(i => i.hasEmpenho);
        return contractedItemsSummary;
    }, [contractedItemsSummary, comparisonFilter]);

    const suppliersWithoutEmpenho = useMemo(() => {
        if (!suppliers) return [];
        return suppliers.filter(supplier => {
            const hasEmpenho = (Object.values(supplier.deliveries || {}) as Delivery[]).some(d => !!d.receiptTermNumber);
            return !hasEmpenho;
        }).map(supplier => {
            const totalWeight = Object.values(supplier.contractItems || {}).reduce((acc: any, item: any) => acc + (item.totalKg || 0), 0) || 0;
            const totalValue = Object.values(supplier.contractItems || {}).reduce((acc: any, item: any) => acc + ((item.totalKg || 0) * (item.valuePerKg || 0)), 0) || 0;
            const items = Object.values(supplier.contractItems || {}).map((item: any) => ({
                name: item.name,
                contracted: item.totalKg || 0,
                unit: item.unit || 'KG',
                value: (item.totalKg || 0) * (item.valuePerKg || 0)
            })) || [];

            return {
                name: supplier.name,
                document: supplier.cpf,
                totalWeight,
                totalValue,
                items,
                observations: supplier.observations || ''
            };
        }).filter(s => s.totalWeight > 0 || s.totalValue > 0)
          .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    }, [suppliers]);

    return (
        <div className="space-y-8 animate-fade-in">
            {/* Header de Contexto Profissional */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-indigo-600"></div>
                <div>
                    <div className="flex items-center gap-2 mb-2">
                        <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Módulo Financeiro Ativo</span>
                    </div>
                    <h2 className="text-3xl font-black text-zinc-900 tracking-tighter uppercase italic">Controle Per Capita</h2>
                    <p className="text-zinc-500 text-sm font-medium max-w-md mt-1">Gestão de quotas mensais, processos SEI e balanceamento de contratos institucionais.</p>
                </div>
                
                <div className="flex items-center gap-3">
                    <button 
                        onClick={handleSave}
                        disabled={!isDirty || isSaving}
                        className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${
                            isDirty 
                                ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-200 hover:bg-indigo-700 active:scale-95' 
                                : 'bg-zinc-100 text-zinc-400 cursor-not-allowed'
                        }`}
                    >
                        {isSaving ? (
                            <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                        ) : (
                            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                        )}
                        {saveSuccess ? 'Alterações Salvas' : 'Salvar Configurações'}
                    </button>
                </div>
            </div>

            {/* Sub-Navegação de Alta Densidade */}
            <div className="flex flex-wrap gap-2 bg-zinc-100 p-1.5 rounded-2xl border border-zinc-200">
                {[
                    { id: 'CALCULO', label: 'Cálculo & Quotas' },
                    { id: 'KIT PPL', label: 'Kit PPL' },
                    { id: 'PPAIS', label: 'PPAIS' },
                    { id: 'ESTOCÁVEIS', label: 'Estocáveis' },
                    { id: 'PERECÍVEIS', label: 'Perecíveis' },
                    { id: 'AUTOMAÇÃO', label: 'Automação' },
                    { id: 'PRODUTOS DE LIMPEZA', label: 'Limpeza' },
                    { id: 'EPI', label: 'EPIs' },
                    { id: 'ADIANTAMENTOS', label: 'Adiantamentos' },
                    { id: 'CONTROLE', label: 'Controle' },
                    { id: 'AUDIT', label: 'Auditoria' }
                ].map((tab) => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveSubTab(tab.id as any)}
                        className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                            activeSubTab === tab.id 
                                ? 'bg-white text-indigo-600 shadow-sm border border-zinc-200' 
                                : 'text-zinc-500 hover:text-zinc-800 hover:bg-zinc-200/50'
                        }`}
                    >
                        {tab.label}
                    </button>
                ))}
            </div>

            {activeSubTab === 'ADIANTAMENTOS' ? (
                <div className="animate-fade-in space-y-8">
                    <div className="text-center mb-8">
                        <h2 className="text-2xl font-black text-indigo-900 uppercase tracking-tighter italic">Adiantamentos Mensais</h2>
                        <p className="text-gray-400 font-medium">Lançamento de valores de adiantamento para cada mês do ano.</p>
                    </div>

                    <div className="overflow-x-auto bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
                            {months.map(month => (
                                <div key={`advance-${month}`} className="space-y-2">
                                    <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest ml-1">{month}</label>
                                    <div className="relative">
                                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-black text-indigo-300">R$</span>
                                        <input 
                                            type="number"
                                            value={monthlyAdvances[month] || ''}
                                            onChange={(e) => handleMonthlyAdvanceChange(month, e.target.value)}
                                            placeholder="0,00" 
                                            className="w-full p-3 pl-9 bg-gray-50 border-2 border-gray-100 rounded-xl font-mono text-sm focus:border-indigo-500 focus:bg-white outline-none transition-all"
                                        />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            ) : activeSubTab === 'CONTROLE' ? (
                <div className="animate-fade-in space-y-8">
                    <div className="text-center mb-8">
                        <h2 className="text-2xl font-black text-indigo-900 uppercase tracking-tighter">Controle de Execução de Recursos Mensais</h2>
                        <p className="text-gray-400 font-medium">Acompanhamento dos gastos por categoria em relação à cota mensal disponível.</p>
                    </div>

                    <div className="overflow-x-auto bg-white rounded-2xl shadow-xl border border-gray-100">
                        <table className="w-full text-sm">
                            <thead className="bg-indigo-950 text-white text-[10px] uppercase font-black tracking-widest">
                                <tr>
                                    <th className="p-4 text-left">Mês</th>
                                    <th className="p-4 text-right bg-indigo-900">Cota Mensal</th>
                                    {activeCategories.map(cat => (
                                        <th key={`exec-${cat}`} className="p-4 text-right">{cat}</th>
                                    ))}
                                    <th className="p-4 text-right bg-indigo-700">Adiantamentos</th>
                                    <th className="p-4 text-right bg-indigo-800">Saldo</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {months.map(month => {
                                    const quota = monthlyQuota[month] || 0;
                                    const exec = monthlyExecution[month];
                                    const advance = monthlyAdvances[month] || 0;
                                    
                                    const totalSpent = activeCategories.reduce((sum, cat) => {
                                        const value = exec[cat] || 0;
                                        const isActiveMonth = getIsActiveMonth(month, cat);
                                        const futureValue = isActiveMonth ? (categoryMonthlyAverages[cat] || 0) : 0;
                                        const displayValue = isActiveMonth ? (value > 0 ? value : futureValue) : 0;
                                        return sum + displayValue;
                                    }, 0) + advance;
                                    
                                    const balance = quota - totalSpent;

                                    return (
                                        <tr key={month} className="hover:bg-gray-50 transition-colors">
                                            <td className="p-4 font-black text-gray-700 uppercase">{month}</td>
                                            <td className="p-4 text-right font-mono font-bold text-indigo-600 bg-indigo-50/30">{formatCurrency(quota)}</td>
                                            {activeCategories.map(cat => {
                                                const value = exec[cat] || 0;
                                                const isActiveMonth = getIsActiveMonth(month, cat);
                                                const futureValue = isActiveMonth ? (categoryMonthlyAverages[cat] || 0) : 0;
                                                const displayValue = isActiveMonth ? (value > 0 ? value : futureValue) : 0;
                                                const isFuture = isActiveMonth && value === 0 && futureValue > 0;
                                                
                                                return (
                                                    <td key={`exec-${cat}`} className={`p-4 text-right font-mono ${isFuture ? 'text-blue-600 font-bold bg-blue-50/30' : 'text-indigo-600'}`}>
                                                        {formatCurrency(displayValue)}
                                                    </td>
                                                );
                                            })}
                                            <td className="p-4 text-right font-mono text-indigo-700 bg-indigo-50/20 font-bold">
                                                {formatCurrency(advance)}
                                            </td>
                                            <td className={`p-4 text-right font-mono font-black bg-indigo-50/50 ${balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                                {formatCurrency(balance)}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                            <tfoot className="bg-gray-100 font-black text-gray-800">
                                <tr>
                                    <td className="p-4 uppercase">Totais Anuais</td>
                                    <td className="p-4 text-right font-mono">
                                        {formatCurrency((Object.values(monthlyQuota) as number[]).reduce((a: number, b: number) => a + (b || 0), 0))}
                                    </td>
                                    {activeCategories.map(cat => {
                                        let catTotal = 0;
                                        months.forEach(month => {
                                            const execVal = monthlyExecution[month]?.[cat] || 0;
                                            const isActiveMonth = getIsActiveMonth(month, cat);
                                            const futureVal = isActiveMonth ? (categoryMonthlyAverages[cat] || 0) : 0;
                                            if (isActiveMonth) {
                                                catTotal += execVal > 0 ? execVal : futureVal;
                                            }
                                        });
                                        return (
                                            <th key={`exec-${cat}`} className="p-4 text-right font-mono">
                                                {formatCurrency(catTotal)}
                                            </th>
                                        );
                                    })}
                                    <th className="p-4 text-right font-mono bg-indigo-700 text-white">
                                        {formatCurrency((Object.values(monthlyAdvances) as number[]).reduce((a: number, b: number) => a + (b || 0), 0))}
                                    </th>
                                    <th className="p-4 text-right font-mono bg-indigo-900 text-white">
                                        {formatCurrency(
                                            (Object.values(monthlyQuota) as number[]).reduce((a: number, b: number) => a + (b || 0), 0) - 
                                            (activeCategories.reduce((sum, cat) => {
                                                let catTotal = 0;
                                                months.forEach(month => {
                                                    const execVal = monthlyExecution[month]?.[cat] || 0;
                                                    const isActiveMonth = getIsActiveMonth(month, cat);
                                                    const futureVal = isActiveMonth ? (categoryMonthlyAverages[cat] || 0) : 0;
                                                    if (isActiveMonth) {
                                                        catTotal += execVal > 0 ? execVal : futureVal;
                                                    }
                                                });
                                                return sum + catTotal;
                                            }, 0) + (Object.values(monthlyAdvances) as number[]).reduce((a: number, b: number) => a + (b || 0), 0))
                                        )}
                                    </th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white p-6 rounded-2xl shadow-lg border-l-8 border-indigo-600">
                            <h3 className="text-lg font-black text-gray-800 uppercase mb-4">Resumo de Categorias</h3>
                            <div className="space-y-3">
                                {activeCategories.map(cat => {
                                    const total = (Object.values(monthlyExecution) as Record<string, number>[]).reduce((acc: number, curr: Record<string, number>) => acc + (curr[cat] || 0), 0);
                                    if (total === 0) return null;
                                    return (
                                        <div key={cat} className="flex justify-between items-center border-b pb-2">
                                            <span className="text-xs font-bold text-gray-500 uppercase">{cat}</span>
                                            <span className="font-mono font-bold text-gray-800">{formatCurrency(total)}</span>
                                        </div>
                                    );
                                })}
                                <div className="flex justify-between items-center pt-4 border-t-2 border-indigo-100">
                                    <span className="text-sm font-black text-indigo-900 uppercase">Total Geral Gasto</span>
                                    <span className="font-mono font-black text-xl text-indigo-700">
                                        {formatCurrency(financialSummary.totalGeralGasto)}
                                    </span>
                                </div>
                                <div className="flex justify-between items-center pt-2">
                                    <span className="text-sm font-black text-indigo-900 uppercase">Total Geral de Cotas</span>
                                    <span className="font-mono font-black text-xl text-indigo-700">
                                        {formatCurrency(financialSummary.totalGeralCotas)}
                                    </span>
                                </div>
                                <div className="flex justify-between items-center pt-2 border-t border-dashed border-indigo-200">
                                    <span className={`text-sm font-black uppercase ${financialSummary.diff > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                                        {financialSummary.diff > 0 ? 'Cotas Faltantes' : 'Cotas a serem utilizadas'}
                                    </span>
                                    <span className={`font-mono font-black text-xl ${financialSummary.diff > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                                        {formatCurrency(Math.abs(financialSummary.diff))}
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div className="bg-white p-6 rounded-2xl shadow-lg border-l-8 border-emerald-600">
                            <h3 className="text-lg font-black text-gray-800 uppercase mb-4">Informação de Apoio</h3>
                            <p className="text-sm text-gray-600 leading-relaxed">
                                Este painel consolida todos os lançamentos de Notas Fiscais (Entradas) realizados no sistema, categorizando-os automaticamente para debitar da cota mensal planejada no Cálculo Geral.
                            </p>
                            <div className="mt-4 p-4 bg-emerald-50 rounded-xl border border-emerald-100">
                                <p className="text-xs font-bold text-emerald-700 uppercase">Dica de Gestão</p>
                                <p className="text-[10px] text-emerald-600 mt-1">
                                    Mantenha os lançamentos de NF atualizados para que o saldo mensal reflita a realidade financeira de cada processo. Apenas categorias com Processo SEI ou Definição preenchidos são contabilizadas.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (activeSubTab as string) === 'AUDIT' ? (
                <div className="animate-fade-in space-y-8">
                    <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white p-8 rounded-[2.5rem] shadow-xl border-l-8 border-red-600">
                        <div>
                            <h2 className="text-2xl font-black text-zinc-900 uppercase tracking-tighter italic">Auditoria de Integridade</h2>
                            <p className="text-zinc-500 font-medium">Verificação de itens agendados que não constam no planejamento Per Capita.</p>
                        </div>
                        {auditInconsistencies.length > 0 && (
                            <button 
                                onClick={handleFixAllInconsistencies}
                                disabled={isSaving}
                                className="bg-red-600 hover:bg-red-700 text-white font-black py-4 px-8 rounded-2xl shadow-lg transition-all active:scale-95 uppercase text-xs tracking-widest flex items-center gap-2"
                            >
                                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                                Corrigir Tudo ({auditInconsistencies.length})
                            </button>
                        )}
                    </div>

                    <div className="bg-white rounded-[2rem] shadow-xl border border-zinc-200 overflow-hidden">
                        <table className="w-full text-sm">
                            <thead className="bg-zinc-900 text-white text-[10px] uppercase font-black tracking-widest">
                                <tr>
                                    <th className="p-4 text-left">Tipo de Erro</th>
                                    <th className="p-4 text-left">Descrição da Inconsistência</th>
                                    <th className="p-4 text-right">Ação</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-zinc-100">
                                {auditInconsistencies.map((issue, idx) => (
                                    <tr key={idx} className="hover:bg-red-50/30 transition-colors">
                                        <td className="p-4">
                                            <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border border-red-200">
                                                {issue.type}
                                            </span>
                                        </td>
                                        <td className="p-4 font-medium text-zinc-700">
                                            {issue.description}
                                        </td>
                                        <td className="p-4 text-right">
                                            <button 
                                                onClick={issue.fix}
                                                className="text-indigo-600 hover:text-indigo-800 font-black uppercase text-[10px] tracking-widest"
                                            >
                                                Corrigir
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                                {auditInconsistencies.length === 0 && (
                                    <tr>
                                        <td colSpan={3} className="p-20 text-center">
                                            <div className="flex flex-col items-center gap-4">
                                                <div className="bg-emerald-100 p-4 rounded-full">
                                                    <svg className="h-12 w-12 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                                </div>
                                                <p className="text-zinc-400 font-black uppercase text-xs tracking-widest">Nenhuma inconsistência detectada. Sistema íntegro!</p>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>

                    {/* Gráfico de Entregas */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <div className="bg-white p-8 rounded-[2rem] shadow-xl border border-zinc-100">
                            <h3 className="text-lg font-black text-zinc-800 uppercase tracking-tighter mb-6 flex items-center gap-2">
                                <svg className="h-5 w-5 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
                                Top 10 Itens Entregues (KG)
                            </h3>
                            <div className="h-[300px] w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={deliveryStats} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                                        <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f0f0f0" />
                                        <XAxis type="number" hide />
                                        <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 10, fontWeight: 'bold', fill: '#666' }} axisLine={false} tickLine={false} />
                                        <Tooltip 
                                            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontSize: '12px', fontWeight: 'bold' }}
                                            formatter={(value: number) => [`${value.toLocaleString('pt-BR')} Kg`, 'Total']}
                                        />
                                        <Bar dataKey="total" radius={[0, 4, 4, 0]} barSize={20}>
                                            {deliveryStats.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#4f46e5' : '#10b981'} />
                                            ))}
                                        </Bar>
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        <div className="bg-white p-8 rounded-[2rem] shadow-xl border border-zinc-100">
                            <h3 className="text-lg font-black text-zinc-800 uppercase tracking-tighter mb-6 flex items-center gap-2">
                                <svg className="h-5 w-5 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                Valor Acumulado por Item
                            </h3>
                            <div className="h-[300px] w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={deliveryStats.sort((a,b) => b.value - a.value)} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                                        <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f0f0f0" />
                                        <XAxis type="number" hide />
                                        <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 10, fontWeight: 'bold', fill: '#666' }} axisLine={false} tickLine={false} />
                                        <Tooltip 
                                            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontSize: '12px', fontWeight: 'bold' }}
                                            formatter={(value: number) => [formatCurrency(value), 'Valor']}
                                        />
                                        <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={20}>
                                            {deliveryStats.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#059669' : '#0891b2'} />
                                            ))}
                                        </Bar>
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    </div>

                    {/* Lista de Fornecedores e Itens */}
                    <div className="bg-white rounded-[2rem] shadow-xl border border-zinc-200 overflow-hidden">
                        <div className="p-8 border-b border-zinc-100 bg-zinc-50/50">
                            <h3 className="text-xl font-black text-zinc-900 uppercase tracking-tighter italic">Relação Fornecedor x Itens Contratados</h3>
                            <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest mt-1">Visualização rápida de todos os itens registrados por contrato</p>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead className="bg-zinc-900 text-white text-[10px] uppercase font-black tracking-widest">
                                    <tr>
                                        <th className="p-4 text-left">Fornecedor</th>
                                        <th className="p-4 text-left">Categoria</th>
                                        <th className="p-4 text-left">Itens em Contrato</th>
                                        <th className="p-4 text-right">Valor Total</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-zinc-100">
                                    {[...(suppliers || []), ...ppaisAsSuppliers, ...pereciveisAsSuppliers]
                                        .sort((a, b) => (a.name || '').localeCompare(b.name || ''))
                                        .map((s, idx) => {
                                            const items = Object.values(s.contractItems || {}) as any[];
                                            const category = ppaisProducers.some(p => matchCpfCnpj(p.cpfCnpj || p.cpf, s.cpf)) ? 'PPAIS' : 
                                                             allPereciveisSuppliers.some(p => matchCpfCnpj(p.cpfCnpj || p.cpf, s.cpf)) ? 'PERECÍVEIS' : 'ESTOCÁVEIS';
                                            
                                            
                                            return (
                                                <tr key={idx} className="hover:bg-zinc-50 transition-colors">
                                                    <td className="p-4">
                                                        <div className="flex flex-col">
                                                            <span className="font-black text-zinc-900 uppercase text-xs">{s.name}</span>
                                                            <span className="text-[9px] font-mono text-zinc-400">{s.cpf}</span>
                                                        </div>
                                                    </td>
                                                    <td className="p-4">
                                                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${
                                                            category === 'PPAIS' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                                                            category === 'PERECÍVEIS' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                                                            'bg-zinc-100 text-zinc-700 border-zinc-200'
                                                        }`}>
                                                            {category}
                                                        </span>
                                                    </td>
                                                    <td className="p-4">
                                                        <div className="flex flex-wrap gap-1">
                                                            {items.length > 0 ? items.map((it, i) => (
                                                                <span key={i} className="bg-white border border-zinc-200 text-zinc-600 text-[9px] font-bold px-2 py-0.5 rounded uppercase">
                                                                    {it.name}
                                                                </span>
                                                            )) : (
                                                                <span className="text-red-500 text-[9px] font-black uppercase italic">Nenhum item vinculado</span>
                                                            )}
                                                        </div>
                                                    </td>
                                                    <td className="p-4 text-right font-mono font-bold text-zinc-600">
                                                        {formatCurrency(s.initialValue || 0)}
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="space-y-8 animate-fade-in">
                    {activeSubTab === 'CALCULO' ? (
                        <>
                            <div className="space-y-8 animate-fade-in">
                                {/* KPIs Principais de Alta Densidade */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div className="bg-zinc-900 text-white p-8 rounded-3xl shadow-xl border border-white/5 relative overflow-hidden group">
                            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
                                <svg className="h-16 w-16" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                            </div>
                            <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-4">População Total</p>
                            <h3 className="text-5xl font-black tracking-tighter italic font-mono">{perCapitaDenominator}</h3>
                            <div className="mt-4 flex gap-4">
                                <div className="flex flex-col">
                                    <span className="text-[9px] text-zinc-500 uppercase font-black">Servidores</span>
                                    <span className="text-sm font-bold">{staffCount}</span>
                                </div>
                                <div className="flex flex-col">
                                    <span className="text-[9px] text-zinc-500 uppercase font-black">Custodiados</span>
                                    <span className="text-sm font-bold">{inmateCount}</span>
                                </div>
                            </div>
                        </div>

                        <div className="bg-white p-8 rounded-3xl shadow-sm border border-zinc-200 relative overflow-hidden group">
                            <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-4">Per Capita (KG)</p>
                            <h3 className="text-5xl font-black tracking-tighter italic font-mono text-zinc-900">
                                {totalPerCapitaKg.toLocaleString('pt-BR', { minimumFractionDigits: 3, maximumFractionDigits: 3 })}
                                <span className="text-lg ml-1 text-zinc-400 not-italic">kg</span>
                            </h3>
                            <span className="text-[7px] text-zinc-400 italic">(valor arredondado p/ fim de dízima)</span>
                            <p className="text-[10px] font-bold text-zinc-400 mt-4 uppercase tracking-widest">Média Diária Projetada</p>
                        </div>

                        <div className="bg-white p-8 rounded-3xl shadow-sm border border-zinc-200 relative overflow-hidden group">
                            <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-4">Per Capita (R$)</p>
                            <h3 className="text-5xl font-black tracking-tighter italic font-mono text-emerald-600">
                                {formatCurrency(totalPerCapitaValue)}
                            </h3>
                            <span className="text-[7px] text-zinc-400 italic">(valor arredondado p/ fim de dízima)</span>
                            <p className="text-[10px] font-bold text-zinc-400 mt-4 uppercase tracking-widest">Custo Diário / Pessoa</p>
                        </div>

                        <div className="bg-indigo-600 text-white p-8 rounded-3xl shadow-xl border border-indigo-400/20 relative overflow-hidden">
                            <p className="text-[10px] font-black text-indigo-200 uppercase tracking-widest mb-4">Saldo de Quota</p>
                            <h3 className="text-5xl font-black tracking-tighter italic font-mono">
                                {formatCurrency((Object.values(monthlyQuota) as number[]).reduce((a: number, b: number) => a + (b || 0), 0) - (Object.values(monthlyExecution) as Record<string, number>[]).reduce((acc: number, curr: Record<string, number>) => acc + (Object.values(curr || {}) as number[]).reduce((a: number, b: number) => a + (b || 0), 0), 0))}
                            </h3>
                            <p className="text-[10px] font-bold text-indigo-200 mt-4 uppercase tracking-widest">Disponível para Empenho</p>
                        </div>
                    </div>

                    {/* Configuração de População e Processos */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-1 space-y-8">
                            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
                                <h4 className="text-xs font-black text-zinc-900 uppercase tracking-widest mb-6 flex items-center gap-2">
                                    <svg className="h-4 w-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                                    Efetivo Populacional
                                </h4>
                                <div className="space-y-6">
                                    <div className="group">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-2 group-focus-within:text-indigo-600 transition-colors">Servidores</label>
                                        <input 
                                            type="number" 
                                            value={staffCount} 
                                            onChange={handleStaffCountChange}
                                            className="w-full bg-zinc-50 border-2 border-zinc-100 rounded-2xl px-5 py-4 font-mono text-xl font-black focus:border-indigo-500 focus:bg-white outline-none transition-all"
                                        />
                                    </div>
                                    <div className="group">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-2 group-focus-within:text-indigo-600 transition-colors">Custodiados</label>
                                        <input 
                                            type="number" 
                                            value={inmateCount} 
                                            onChange={handleInmateCountChange}
                                            className="w-full bg-zinc-50 border-2 border-zinc-100 rounded-2xl px-5 py-4 font-mono text-xl font-black focus:border-indigo-500 focus:bg-white outline-none transition-all"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
                                <h4 className="text-xs font-black text-zinc-900 uppercase tracking-widest mb-6 flex items-center gap-2">
                                    <svg className="h-4 w-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                    Resumo Financeiro Anual
                                </h4>
                                <div className="space-y-4">
                                    <div className="flex justify-between items-center">
                                        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Total Geral Gasto</span>
                                        <span className="font-mono font-bold text-zinc-900">{formatCurrency(financialSummary.totalGeralGasto)}</span>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Total Geral de Cotas</span>
                                        <span className="font-mono font-bold text-zinc-900">{formatCurrency(financialSummary.totalGeralCotas)}</span>
                                    </div>
                                    <div className="pt-4 border-t border-zinc-100 flex justify-between items-center">
                                        <span className={`text-[10px] font-black uppercase tracking-widest ${financialSummary.diff > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                                            {financialSummary.diff > 0 ? 'Cotas Faltantes' : 'Cotas a serem utilizadas'}
                                        </span>
                                        <span className={`font-mono font-black text-lg ${financialSummary.diff > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                                            {formatCurrency(Math.abs(financialSummary.diff))}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
                            <h4 className="text-xs font-black text-zinc-900 uppercase tracking-widest mb-6 flex items-center gap-2">
                                <svg className="h-4 w-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                Processos SEI por Categoria
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                                {['PPAIS', 'KIT PPL', 'ESTOCÁVEIS', 'PERECÍVEIS', 'AUTOMAÇÃO', 'PRODUTOS DE LIMPEZA', 'EPI'].map(cat => (
                                    <div key={cat} className="flex flex-col gap-2 p-4 rounded-2xl bg-zinc-50 border border-zinc-100 hover:border-indigo-200 transition-colors">
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="text-[10px] font-black text-zinc-900 uppercase tracking-widest">{cat}</span>
                                            <span className="text-[9px] font-bold text-zinc-400 italic">SEI / Definição</span>
                                        </div>
                                        <div className="flex gap-2">
                                            <input 
                                                type="text" 
                                                placeholder="Nº Processo"
                                                value={seiProcessNumbers[cat] || ''} 
                                                onChange={(e) => handleSeiNumberChange(cat, e.target.value)}
                                                className="w-1/2 bg-white border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono focus:border-indigo-500 outline-none"
                                            />
                                            <input 
                                                type="text" 
                                                placeholder="Definição"
                                                value={seiProcessDefinitions[cat] || ''} 
                                                onChange={(e) => handleSeiDefinitionChange(cat, e.target.value)}
                                                className="w-1/2 bg-white border border-zinc-200 rounded-xl px-3 py-2 text-xs font-medium focus:border-indigo-500 outline-none"
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Tabela de Quotas Mensais */}
                    <div className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
                        <div className="p-8 border-b border-zinc-100 flex justify-between items-center">
                            <h4 className="text-xs font-black text-zinc-900 uppercase tracking-widest flex items-center gap-2">
                                <svg className="h-4 w-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                Planejamento de Quotas Mensais
                            </h4>
                            <div className="flex gap-4">
                                <div className="flex items-center gap-2">
                                    <div className="h-3 w-3 rounded-full bg-emerald-500"></div>
                                    <span className="text-[9px] font-black text-zinc-400 uppercase">Quota</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="h-3 w-3 rounded-full bg-indigo-500"></div>
                                    <span className="text-[9px] font-black text-zinc-400 uppercase">Recurso</span>
                                </div>
                            </div>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                                <thead>
                                    <tr className="bg-zinc-50">
                                        <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">Mês de Referência</th>
                                        <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">Quota Mensal (R$)</th>
                                        <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">Recurso Disponível (R$)</th>
                                        <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">Execução Real</th>
                                        <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">Saldo</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-zinc-100">
                                    {months.map(m => {
                                        const execution = (Object.values(monthlyExecution[m] || {}) as number[]).reduce((a: number, b: number) => a + (b || 0), 0);
                                        const quota = monthlyQuota[m] || 0;
                                        const balance = quota - execution;
                                        return (
                                            <tr key={m} className="hover:bg-zinc-50/50 transition-colors group">
                                                <td className="px-8 py-5">
                                                    <span className="text-sm font-black text-zinc-900 uppercase italic tracking-tighter">{m}</span>
                                                </td>
                                                <td className="px-8 py-5">
                                                    <input 
                                                        type="number" 
                                                        value={monthlyQuota[m] || ''} 
                                                        onChange={(e) => handleMonthlyValueChange('quota', m, e.target.value)}
                                                        className="w-full max-w-[150px] bg-transparent border-b-2 border-transparent focus:border-emerald-500 outline-none font-mono font-bold text-sm text-emerald-600 transition-all"
                                                        placeholder="0,00"
                                                    />
                                                </td>
                                                <td className="px-8 py-5">
                                                    <input 
                                                        type="number" 
                                                        value={monthlyResource[m] || ''} 
                                                        onChange={(e) => handleMonthlyValueChange('resource', m, e.target.value)}
                                                        className="w-full max-w-[150px] bg-transparent border-b-2 border-transparent focus:border-indigo-500 outline-none font-mono font-bold text-sm text-indigo-600 transition-all"
                                                        placeholder="0,00"
                                                    />
                                                </td>
                                                <td className="px-8 py-5">
                                                    <span className="font-mono font-bold text-sm text-zinc-900">{formatCurrency(execution)}</span>
                                                </td>
                                                <td className="px-8 py-5">
                                                    <span className={`font-mono font-bold text-sm ${balance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                                                        {formatCurrency(balance)}
                                                    </span>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div className="text-center py-10 border-t border-zinc-100">
                        <button 
                            onClick={() => setShowComparison(!showComparison)}
                            className="px-10 py-4 bg-zinc-900 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl shadow-xl hover:bg-zinc-800 active:scale-95 transition-all"
                        >
                            {showComparison ? 'Ocultar Comparativo de Contrato' : 'Exibir Comparativo de Contrato'}
                        </button>
                    </div>
                </div>
                {showComparison && (
                    <div className="mt-8 animate-fade-in">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-2xl font-black text-gray-800 text-center uppercase tracking-tighter flex-1">
                            Comparativo Resumido dos Itens Adquiridos no Contrato
                        </h3>
                    </div>
                    <div className="border rounded-lg flex flex-col">
                        <div className="flex flex-wrap gap-2 p-4 bg-gray-50 border-b">
                            <button onClick={() => setComparisonFilter('TODOS')} className={`px-4 py-2 rounded-full text-xs font-bold transition-colors ${comparisonFilter === 'TODOS' ? 'bg-gray-800 text-white shadow-md' : 'bg-white text-gray-600 border hover:bg-gray-100'}`}>Todos</button>
                            <button onClick={() => setComparisonFilter('SEM_ENTREGA')} className={`px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2 transition-colors ${comparisonFilter === 'SEM_ENTREGA' ? 'bg-red-600 text-white shadow-md' : 'bg-white text-red-600 border border-red-200 hover:bg-red-50'}`}>
                                <span className="w-2 h-2 rounded-full bg-current"></span> Sem Entrega (0%)
                            </button>
                            <button onClick={() => setComparisonFilter('ATENCAO')} className={`px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2 transition-colors ${comparisonFilter === 'ATENCAO' ? 'bg-orange-500 text-white shadow-md' : 'bg-white text-orange-600 border border-orange-200 hover:bg-orange-50'}`}>
                                <span className="w-2 h-2 rounded-full bg-current"></span> Atenção (&lt; 50%)
                            </button>
                            <button onClick={() => setComparisonFilter('AVANCADO')} className={`px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2 transition-colors ${comparisonFilter === 'AVANCADO' ? 'bg-blue-500 text-white shadow-md' : 'bg-white text-blue-600 border border-blue-200 hover:bg-blue-50'}`}>
                                <span className="w-2 h-2 rounded-full bg-current"></span> Avançado (≥ 70%)
                            </button>
                            <button onClick={() => setComparisonFilter('CONCLUIDO')} className={`px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2 transition-colors ${comparisonFilter === 'CONCLUIDO' ? 'bg-green-600 text-white shadow-md' : 'bg-white text-green-600 border border-green-200 hover:bg-green-50'}`}>
                                <span className="w-2 h-2 rounded-full bg-current"></span> Concluído (100%)
                            </button>
                            <button onClick={() => setComparisonFilter('COM_EMPENHO')} className={`px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2 transition-colors ${comparisonFilter === 'COM_EMPENHO' ? 'bg-purple-600 text-white shadow-md' : 'bg-white text-purple-600 border border-purple-200 hover:bg-purple-50'}`}>
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                Com Empenho
                            </button>
                        </div>
                        <div 
                            className="overflow-x-auto custom-scrollbar"
                            onScroll={(e) => {
                                const bottomScroll = document.getElementById('comparison-bottom-scroll');
                                if (bottomScroll) bottomScroll.scrollLeft = e.currentTarget.scrollLeft;
                            }}
                        >
                            <div id="comparison-top-dummy" style={{ height: '1px' }}></div>
                        </div>
                        <div 
                            id="comparison-bottom-scroll"
                            className="overflow-x-auto custom-scrollbar"
                            onScroll={(e) => {
                                const topScroll = e.currentTarget.previousElementSibling;
                                if (topScroll) topScroll.scrollLeft = e.currentTarget.scrollLeft;
                            }}
                        >
                            <table 
                                className="w-full text-sm"
                                ref={(el) => {
                                    if (el) {
                                        const dummy = document.getElementById('comparison-top-dummy');
                                        if (dummy) dummy.style.width = `${el.offsetWidth}px`;
                                    }
                                }}
                            >
                                <thead className="bg-gray-100 text-xs uppercase text-gray-600">
                                    <tr>
                                        <th className="p-3 text-center">#</th>
                                        <th className="p-3 text-left">Item</th>
                                        <th className="p-3 text-center">Qtd. Contratada</th>
                                        <th className="p-3 text-center">Qtd. Recebida</th>
                                        <th className="p-3 text-center">Restam Entregar</th>
                                        <th className="p-3 text-center w-32">Progresso</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                    {filteredComparison.map((item, index) => {
                                        return (
                                            <tr key={item.name} className="hover:bg-gray-50">
                                                <td className="p-3 text-center font-mono text-gray-500">{index + 1}</td>
                                                <td className="p-3 font-semibold text-gray-800">
                                                    <div className="flex flex-col">
                                                        <div className="flex items-center gap-2 flex-wrap">
                                                            <span>{item.name}</span>
                                                            {item.empenhos.length > 0 && (
                                                                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-gray-100 text-gray-600 border border-gray-200">
                                                                    Empenho: {item.empenhos.join(', ')}
                                                                </span>
                                                            )}
                                                            {item.status === 'SEM_ENTREGA' && <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-700">SEM ENTREGA</span>}
                                                            {item.status === 'ATENCAO' && <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-700">ATENÇÃO</span>}
                                                            {item.status === 'AVANCADO' && <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-700">AVANÇADO</span>}
                                                            {item.status === 'CONCLUIDO' && <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-green-100 text-green-700">CONCLUÍDO</span>}
                                                        </div>
                                                        {item.suppliers.length > 0 && (
                                                            <span className="text-[10px] font-normal text-gray-400 mt-0.5">
                                                                {item.suppliers.join(', ')}
                                                            </span>
                                                        )}
                                                    </div>
                                                </td>
                                                <td className="p-3 text-center font-mono text-gray-500">{item.contracted.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {item.unit}</td>
                                                <td className="p-3 text-center font-mono text-gray-500">{item.received.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {item.unit}</td>
                                                <td className="p-3 text-center font-mono font-bold text-blue-600">
                                                    {item.remaining.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {item.unit}
                                                </td>
                                                <td className="p-3 w-32">
                                                    <div className="flex items-center gap-2">
                                                        <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                                                            <div 
                                                                className={`h-full rounded-full ${item.status === 'SEM_ENTREGA' ? 'bg-red-500' : item.status === 'ATENCAO' ? 'bg-orange-500' : item.status === 'AVANCADO' ? 'bg-blue-500' : item.status === 'CONCLUIDO' ? 'bg-green-500' : 'bg-blue-400'}`} 
                                                                style={{ width: `${Math.min(100, item.percentage)}%` }}
                                                            ></div>
                                                        </div>
                                                        <span className="text-[10px] font-mono font-bold text-gray-500 w-8 text-right">{item.percentage.toFixed(0)}%</span>
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                )}

                {suppliersWithoutEmpenho.length > 0 && (
                        <div className="mt-12 animate-fade-in">
                            <h3 className="text-xl font-black text-red-800 text-center uppercase tracking-tighter mb-6 flex items-center justify-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                                Empresas que faltam emitir o empenho
                            </h3>
                            <div className="border border-red-100 rounded-lg overflow-hidden shadow-sm">
                                <table className="w-full text-sm">
                                    <thead className="bg-red-50 text-xs uppercase text-red-800">
                                        <tr>
                                            <th className="p-3 text-left">Empresa</th>
                                            <th className="p-3 text-center">CNPJ/CPF</th>
                                            <th className="p-3 text-center">Peso a Empenhar</th>
                                            <th className="p-3 text-center">Valor a Empenhar</th>
                                            <th className="p-3 text-left">Observações</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-red-50 bg-white">
                                        {suppliersWithoutEmpenho.map((supplier) => (
                                            <React.Fragment key={supplier.document}>
                                                <tr className="hover:bg-red-50/50 transition-colors">
                                                    <td className="p-3 font-semibold text-gray-800">
                                                        {supplier.name}
                                                        {supplier.items.length > 0 && (
                                                            <div className="mt-2 pl-4 border-l-2 border-red-100 space-y-1">
                                                                {supplier.items.map((item, idx) => (
                                                                    <div key={idx} className="text-[10px] text-gray-500 flex justify-between items-center max-w-sm">
                                                                        <span className="truncate pr-2" title={item.name}>• {item.name}</span>
                                                                        <span className="font-mono text-gray-400 whitespace-nowrap">
                                                                            {item.contracted.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {item.unit} - {formatCurrency(item.value)}
                                                                        </span>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        )}
                                                    </td>
                                                    <td className="p-3 text-center font-mono text-gray-500 align-top">{supplier.document}</td>
                                                    <td className="p-3 text-center font-mono text-gray-600 align-top">{supplier.totalWeight.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} KG</td>
                                                    <td className="p-3 text-center font-mono font-bold text-red-600 align-top">{formatCurrency(supplier.totalValue)}</td>
                                                    <td className="p-3 align-top">
                                                        <textarea 
                                                            className="w-full p-2 text-[10px] border border-gray-200 rounded-md focus:ring-1 focus:ring-red-500 focus:border-red-500 outline-none resize-none"
                                                            rows={2}
                                                            placeholder="Adicionar observação..."
                                                            defaultValue={supplier.observations}
                                                            onBlur={(e) => {
                                                                if (onUpdateSupplierObservations && e.target.value !== supplier.observations) {
                                                                    onUpdateSupplierObservations(supplier.document, e.target.value);
                                                                }
                                                            }}
                                                        />
                                                    </td>
                                                </tr>
                                            </React.Fragment>
                                        ))}
                                    </tbody>
                                    <tfoot className="bg-red-50 font-bold text-red-900">
                                        <tr>
                                            <td colSpan={2} className="p-3 text-right uppercase text-xs tracking-wider">Total a Empenhar:</td>
                                            <td className="p-3 text-center font-mono">{suppliersWithoutEmpenho.reduce((acc, s) => acc + s.totalWeight, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} KG</td>
                                            <td className="p-3 text-center font-mono">{formatCurrency(suppliersWithoutEmpenho.reduce((acc, s) => acc + s.totalValue, 0))}</td>
                                            <td className="p-3"></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    )}
                </>
            ) : (
                    <div className="space-y-8 animate-fade-in">
                    {/* Cabeçalho de Contexto do Processo */}
                    <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
                        <div className="flex flex-col md:flex-row gap-8">
                            <div className="flex-1 space-y-2">
                                <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest ml-1">Número do Processo SEI</label>
                                <div className="relative group">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                        <svg className="h-4 w-4 text-zinc-400 group-focus-within:text-indigo-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                    </div>
                                    <input 
                                        type="text"
                                        value={getSeiValue(seiProcessNumbers, activeSubTab)}
                                        onChange={(e) => handleSeiNumberChange(activeSubTab, e.target.value)}
                                        placeholder="Ex: 00000.000000/0000-00" 
                                        className="w-full bg-zinc-50 border-2 border-zinc-100 rounded-2xl pl-11 pr-5 py-4 font-mono text-sm font-bold focus:border-indigo-500 focus:bg-white outline-none transition-all"
                                    />
                                </div>
                            </div>
                            <div className="flex-1 space-y-2">
                                <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest ml-1">Definição do Processo</label>
                                <div className="relative group">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                        <svg className="h-4 w-4 text-zinc-400 group-focus-within:text-indigo-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                                    </div>
                                    <input 
                                        type="text"
                                        value={getSeiValue(seiProcessDefinitions, activeSubTab)}
                                        onChange={(e) => handleSeiDefinitionChange(activeSubTab, e.target.value)}
                                        placeholder="Ex: Aquisição de gêneros alimentícios..." 
                                        className="w-full bg-zinc-50 border-2 border-zinc-100 rounded-2xl pl-11 pr-5 py-4 font-bold text-sm focus:border-indigo-500 focus:bg-white outline-none transition-all"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Seletor de Ano e Quadrimestre para PERECÍVEIS e ESTOCÁVEIS */}
                    {(activeSubTab.startsWith('PERECÍVEIS') || activeSubTab.startsWith('ESTOCÁVEIS')) && (
                        <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm space-y-4">
                            <div className="flex flex-wrap items-center justify-between gap-4">
                                <div className="flex items-center gap-3">
                                    <span className="text-xs font-black uppercase text-zinc-400 tracking-wider">Ano de Exercício:</span>
                                    <div className="flex bg-zinc-100 p-1 rounded-xl border border-zinc-200">
                                        <button
                                            type="button"
                                            onClick={() => setSelectedYear(2026)}
                                            className={`px-4 py-1.5 rounded-lg text-xs font-black transition-all ${selectedYear === 2026 ? 'bg-white text-indigo-600 shadow-sm' : 'text-zinc-500 hover:text-zinc-800'}`}
                                        >
                                            2026
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => setSelectedYear(2027)}
                                            className={`px-4 py-1.5 rounded-lg text-xs font-black transition-all ${selectedYear === 2027 ? 'bg-white text-indigo-600 shadow-sm' : 'text-zinc-500 hover:text-zinc-800'}`}
                                        >
                                            2027
                                        </button>
                                    </div>
                                </div>

                                <div className="text-xs text-zinc-500 font-medium">
                                    {selectedYear === 2026 ? (
                                        <span>Exibindo contratos e cronogramas de <strong>2026</strong></span>
                                    ) : (
                                        <span>Planejamento e novos contratos de <strong>2027</strong></span>
                                    )}
                                </div>
                            </div>

                            <div className="flex flex-wrap gap-2 pt-2 border-t border-zinc-100">
                                <button
                                    type="button"
                                    onClick={() => setSelectedQuadrimestre('1Q')}
                                    className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all ${
                                        selectedQuadrimestre === '1Q'
                                            ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100 ring-2 ring-indigo-600 ring-offset-2'
                                            : 'bg-zinc-50 text-zinc-600 hover:bg-zinc-100 border border-zinc-200'
                                    }`}
                                >
                                    <span>1º Quadrimestre</span>
                                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${selectedQuadrimestre === '1Q' ? 'bg-indigo-700 text-indigo-100' : 'bg-zinc-200 text-zinc-600'}`}>
                                        Jan - Abr
                                    </span>
                                </button>

                                <button
                                    type="button"
                                    onClick={() => setSelectedQuadrimestre('2Q')}
                                    className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all ${
                                        selectedQuadrimestre === '2Q'
                                            ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100 ring-2 ring-indigo-600 ring-offset-2'
                                            : 'bg-zinc-50 text-zinc-600 hover:bg-zinc-100 border border-zinc-200'
                                    }`}
                                >
                                    <span>2º Quadrimestre</span>
                                    <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${selectedQuadrimestre === '2Q' ? 'bg-indigo-700 text-indigo-100' : 'bg-emerald-100 text-emerald-800 border border-emerald-200'}`}>
                                        Mai - Ago {selectedYear === 2026 ? '• Dados Anteriores' : ''}
                                    </span>
                                </button>

                                <button
                                    type="button"
                                    onClick={() => setSelectedQuadrimestre('3Q')}
                                    className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all ${
                                        selectedQuadrimestre === '3Q'
                                            ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100 ring-2 ring-indigo-600 ring-offset-2'
                                            : 'bg-zinc-50 text-zinc-600 hover:bg-zinc-100 border border-zinc-200'
                                    }`}
                                >
                                    <span>3º Quadrimestre</span>
                                    <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${selectedQuadrimestre === '3Q' ? 'bg-indigo-700 text-indigo-100' : 'bg-amber-100 text-amber-800 border border-amber-200'}`}>
                                        Set - Dez {selectedYear === 2026 ? '• Novo Período' : ''}
                                    </span>
                                </button>
                            </div>

                            {/* Banner informativo de preservação dos dados de Maio a Agosto */}
                            {selectedYear === 2026 && selectedQuadrimestre === '2Q' && (
                                <div className="p-3.5 bg-emerald-50/80 rounded-2xl border border-emerald-200/80 flex items-center justify-between gap-3 text-xs text-emerald-900">
                                    <div className="flex items-center gap-2.5">
                                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse flex-shrink-0"></span>
                                        <p>
                                            <strong>2º Quadrimestre (Maio a Agosto / 2026):</strong> Todos os dados cadastrados dos meses anteriores estão <strong>ativos e preservados</strong> (itens, fornecedores, preços e contratos).
                                        </p>
                                    </div>
                                    <span className="text-[10px] font-black uppercase px-2.5 py-1 bg-emerald-200/70 text-emerald-900 rounded-lg whitespace-nowrap">
                                        Base de Dados Preservada
                                    </span>
                                </div>
                            )}

                            {selectedYear === 2026 && selectedQuadrimestre === '3Q' && (
                                <div className="p-3.5 bg-blue-50/80 rounded-2xl border border-blue-200/80 flex items-center justify-between gap-3 text-xs text-blue-900">
                                    <div className="flex items-center gap-2.5">
                                        <span className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0"></span>
                                        <p>
                                            <strong>3º Quadrimestre (Setembro a Dezembro / 2026):</strong> Período independente. Os dados cadastrados de Maio a Agosto permanecem intocados no 2º Quadrimestre e podem ser clonados para este período via botões de cópia.
                                        </p>
                                    </div>
                                    <button 
                                        type="button"
                                        onClick={() => setSelectedQuadrimestre('2Q')}
                                        className="text-[10px] font-black uppercase px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg whitespace-nowrap transition-colors"
                                    >
                                        Ver Maio a Agosto
                                    </button>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Navegação Interna de Alta Densidade (Sub-abas) */}
                    {(activeSubTab === 'PPAIS' || activeSubTab.startsWith('PERECÍVEIS') || activeSubTab.startsWith('ESTOCÁVEIS')) && (
                        <div className="flex gap-2 bg-zinc-100 p-1.5 rounded-2xl border border-zinc-200 w-fit">
                            <button 
                                onClick={() => {
                                    if (activeSubTab === 'PPAIS') setPpaisSubTab('ITEMS');
                                    else if (activeSubTab.startsWith('PERECÍVEIS')) setPereciveisSubTab('ITEMS');
                                    else if (activeSubTab.startsWith('ESTOCÁVEIS')) setEstocaveisSubTab('ITEMS');
                                }}
                                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                    (activeSubTab === 'PPAIS' ? ppaisSubTab === 'ITEMS' : activeSubTab.startsWith('PERECÍVEIS') ? pereciveisSubTab === 'ITEMS' : estocaveisSubTab === 'ITEMS')
                                    ? 'bg-white text-zinc-900 shadow-sm' 
                                    : 'text-zinc-500 hover:text-zinc-700'
                                }`}
                            >
                                Itens de Aquisição
                            </button>
                            <button 
                                onClick={() => {
                                    if (activeSubTab === 'PPAIS') setPpaisSubTab('PRODUCERS');
                                    else if (activeSubTab.startsWith('PERECÍVEIS')) setPereciveisSubTab('SUPPLIERS');
                                    else if (activeSubTab.startsWith('ESTOCÁVEIS')) setEstocaveisSubTab('SUPPLIERS');
                                }}
                                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                    (activeSubTab === 'PPAIS' ? ppaisSubTab === 'PRODUCERS' : activeSubTab.startsWith('PERECÍVEIS') ? pereciveisSubTab === 'SUPPLIERS' : estocaveisSubTab === 'SUPPLIERS')
                                    ? 'bg-white text-zinc-900 shadow-sm' 
                                    : 'text-zinc-500 hover:text-zinc-700'
                                }`}
                            >
                                {activeSubTab === 'PPAIS' ? 'Cadastro de Produtores' : 'Cadastro de Fornecedores'}
                            </button>
                            <button 
                                onClick={() => {
                                    if (activeSubTab === 'PPAIS') setPpaisSubTab('CONTRACT');
                                    else if (activeSubTab.startsWith('PERECÍVEIS')) setPereciveisSubTab('CONTRACT');
                                    else if (activeSubTab.startsWith('ESTOCÁVEIS')) setEstocaveisSubTab('CONTRACT');
                                }}
                                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                    (activeSubTab === 'PPAIS' ? ppaisSubTab === 'CONTRACT' : activeSubTab.startsWith('PERECÍVEIS') ? pereciveisSubTab === 'CONTRACT' : estocaveisSubTab === 'CONTRACT')
                                    ? 'bg-white text-zinc-900 shadow-sm' 
                                    : 'text-zinc-500 hover:text-zinc-700'
                                }`}
                            >
                                Contrato
                            </button>
                            {activeSubTab === 'PPAIS' && (
                                <button 
                                    onClick={() => setPpaisSubTab('ATA')}
                                    className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                        ppaisSubTab === 'ATA'
                                        ? 'bg-white text-zinc-900 shadow-sm' 
                                        : 'text-zinc-500 hover:text-zinc-700'
                                    }`}
                                >
                                    Ata
                                </button>
                            )}
                            <button 
                                onClick={() => {
                                    if (activeSubTab === 'PPAIS') setPpaisSubTab('SCHEDULE');
                                    else if (activeSubTab.startsWith('PERECÍVEIS')) setPereciveisSubTab('SCHEDULE');
                                    else if (activeSubTab.startsWith('ESTOCÁVEIS')) setEstocaveisSubTab('SCHEDULE');
                                }}
                                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                    (activeSubTab === 'PPAIS' ? ppaisSubTab === 'SCHEDULE' : activeSubTab.startsWith('PERECÍVEIS') ? pereciveisSubTab === 'SCHEDULE' : estocaveisSubTab === 'SCHEDULE')
                                    ? 'bg-white text-zinc-900 shadow-sm' 
                                    : 'text-zinc-500 hover:text-zinc-700'
                                }`}
                            >
                                Cronograma
                            </button>
                        </div>
                    )}

                    {/* Área de Conteúdo Modular */}
                    <div className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
                        {activeSubTab === 'PPAIS' && ppaisSubTab === 'PRODUCERS' ? (
                            <AdminPerCapitaSuppliers 
                                suppliers={ppaisProducers}
                                onUpdate={handleUpdateProducers}
                                onSaveInvoice={onSaveInvoice}
                                onDeleteDelivery={onDeleteDelivery}
                                type="PRODUTOR"
                                colorScheme="emerald"
                            />
                        ) : activeSubTab.startsWith('PERECÍVEIS') && pereciveisSubTab === 'SUPPLIERS' ? (
                            <AdminPerCapitaSuppliers 
                                suppliers={currentPereciveisSuppliers}
                                onUpdate={handleUpdatePereciveisSuppliers}
                                onSaveInvoice={onSaveInvoice}
                                onDeleteDelivery={onDeleteDelivery}
                                type="FORNECEDOR"
                                colorScheme="indigo"
                                quadrimestreInfo={{ quadrimestre: selectedQuadrimestre, year: selectedYear }}
                                otherQuadrimestres={otherPereciveisQuadrimestres}
                            />
                        ) : activeSubTab.startsWith('ESTOCÁVEIS') && estocaveisSubTab === 'SUPPLIERS' ? (
                            <AdminPerCapitaSuppliers 
                                suppliers={currentEstocaveisSuppliers}
                                onUpdate={handleUpdateEstocaveisSuppliers}
                                onSaveInvoice={onSaveInvoice}
                                onDeleteDelivery={onDeleteDelivery}
                                type="FORNECEDOR"
                                colorScheme="indigo"
                                quadrimestreInfo={{ quadrimestre: selectedQuadrimestre, year: selectedYear }}
                                otherQuadrimestres={otherEstocaveisQuadrimestres}
                            />
                        ) : (activeSubTab === 'PPAIS' || activeSubTab.startsWith('PERECÍVEIS') || activeSubTab.startsWith('ESTOCÁVEIS')) && (activeSubTab === 'PPAIS' ? ppaisSubTab === 'CONTRACT' : activeSubTab.startsWith('PERECÍVEIS') ? pereciveisSubTab === 'CONTRACT' : estocaveisSubTab === 'CONTRACT') ? (
                            <div className="p-8 space-y-4">
                                <h3 className="text-lg font-black text-zinc-800 uppercase tracking-tighter">
                                    Selecione o Fornecedor para o Contrato ({activeSubTab.startsWith('PERECÍVEIS') || activeSubTab.startsWith('ESTOCÁVEIS') ? `${selectedYear} - ${selectedQuadrimestre}` : 'PPAIS'})
                                </h3>
                                <select 
                                    className="w-full p-4 bg-white border border-zinc-200 rounded-xl font-bold text-sm"
                                    value={selectedProducer?.id || ''}
                                    onChange={(e) => {
                                        const source = activeSubTab === 'PPAIS' ? ppaisProducers : (activeSubTab.startsWith('PERECÍVEIS') ? currentPereciveisSuppliers : currentEstocaveisSuppliers);
                                        const selected = source.find(p => p.id === e.target.value);
                                        setSelectedProducer(selected || null);
                                    }}
                                >
                                    <option value="">Selecione...</option>
                                    {(activeSubTab === 'PPAIS' ? ppaisProducers : (activeSubTab.startsWith('PERECÍVEIS') ? currentPereciveisSuppliers : currentEstocaveisSuppliers)).map(p => (
                                        <option key={p.id} value={p.id}>{p.name}</option>
                                    ))}
                                </select>
                                {selectedProducer && (
                                    <AdminContractGenerator 
                                        producer={selectedProducer}
                                    />
                                )}
                            </div>
                        ) : activeSubTab === 'PPAIS' && ppaisSubTab === 'ATA' ? (
                            <AdminAtaGenerator 
                                producers={ppaisProducers}
                                processNumber={getSeiValue(seiProcessNumbers, 'PPAIS')}
                                processDefinition={getSeiValue(seiProcessDefinitions, 'PPAIS')}
                                items={acquisitionItems.filter(item => item.category === 'PPAIS')}
                            />
                        ) : (activeSubTab === 'PPAIS' || activeSubTab.startsWith('PERECÍVEIS') || activeSubTab.startsWith('ESTOCÁVEIS')) && (activeSubTab === 'PPAIS' ? ppaisSubTab === 'SCHEDULE' : activeSubTab.startsWith('PERECÍVEIS') ? pereciveisSubTab === 'SCHEDULE' : estocaveisSubTab === 'SCHEDULE') ? (
                            <div className="p-8 space-y-8">
                                <div className="flex flex-wrap gap-4 items-center justify-between mb-8">
                                    <div className="flex bg-zinc-100 p-1 rounded-xl">
                                        <button 
                                            onClick={() => setScheduleView('CALENDAR')}
                                            className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${scheduleView === 'CALENDAR' ? 'bg-white text-indigo-600 shadow-sm' : 'text-zinc-500 hover:text-zinc-800'}`}
                                        >
                                            Visão Calendário
                                        </button>
                                        <button 
                                            onClick={() => setScheduleView('SUPPLIER')}
                                            className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${scheduleView === 'SUPPLIER' ? 'bg-white text-indigo-600 shadow-sm' : 'text-zinc-500 hover:text-zinc-800'}`}
                                        >
                                            Visão Fornecedor
                                        </button>
                                    </div>
                                    <div className="flex gap-3">
                                        {activeSubTab === 'PPAIS' && onSyncPPAISToAgenda && (
                                            <button 
                                                onClick={() => onSyncPPAISToAgenda()}
                                                className="px-8 py-3 bg-emerald-600 text-white font-black rounded-xl uppercase text-xs tracking-widest hover:bg-emerald-700 shadow-lg transition-all active:scale-95 flex items-center gap-2"
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                                                Sincronizar Agenda
                                            </button>
                                        )}
                                        <button 
                                            onClick={() => {
                                                const element = document.getElementById('delivery-schedule-print');
                                                if (!element) return;
                                                
                                                const scrollPos = window.scrollY;
                                                window.scrollTo(0, 0);

                                                const opt = {
                                                    margin: [10, 10, 10, 10] as [number, number, number, number],
                                                    filename: `Cronograma_Entrega_${activeSubTab}_${selectedYear}_${selectedQuadrimestre}.pdf`,
                                                    image: { type: 'jpeg' as const, quality: 0.98 },
                                                    html2canvas: { 
                                                        scale: 2, 
                                                        useCORS: true, 
                                                        letterRendering: false,
                                                        scrollY: 0,
                                                        windowWidth: element.clientWidth
                                                    },
                                                    jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' as const },
                                                    pagebreak: { mode: ['css', 'legacy'] }
                                                };
                                                html2pdf()
                                                    .set(opt)
                                                    .from(element)
                                                    .save()
                                                    .then(() => {
                                                        window.scrollTo(0, scrollPos);
                                                    });
                                            }}
                                            className="px-8 py-3 bg-indigo-600 text-white font-black rounded-xl uppercase text-xs tracking-widest hover:bg-indigo-700 shadow-lg transition-all active:scale-95 flex items-center gap-2"
                                        >
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                                            Gerar PDF
                                        </button>
                                    </div>
                                </div>
                                <div id="delivery-schedule-print" className="bg-white p-8 rounded-[2rem] border border-zinc-100 italic">
                                    <div className="flex items-center gap-4 mb-8 justify-center">
                                        <PoliciaPenalLogo className="h-16 w-auto" />
                                        <h3 className="text-xl font-black text-zinc-800 uppercase tracking-tighter text-center">
                                            Cronograma de Entrega - {activeSubTab} {activeSubTab !== 'PPAIS' ? `(${selectedYear} - ${selectedQuadrimestre})` : ''}
                                        </h3>
                                    </div>
                                    
                                    {scheduleView === 'CALENDAR' ? (
                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                            {(activeSubTab === 'PPAIS' ? months : (selectedQuadrimestre === '1Q' ? months.slice(0, 4) : selectedQuadrimestre === '2Q' ? months.slice(4, 8) : months.slice(8, 12))).map(month => {
                                                const currentSuppliers = activeSubTab === 'PPAIS' ? ppaisProducers : (activeSubTab.startsWith('PERECÍVEIS') ? currentPereciveisSuppliers : currentEstocaveisSuppliers);
                                                const suppliersInMonth = currentSuppliers.filter(s => getSafeScheduleWeeks(s.monthlySchedule, month).length > 0);
                                                if (suppliersInMonth.length === 0) return null;

                                                return (
                                                    <div key={month} className="bg-zinc-50 p-6 rounded-2xl border border-zinc-100">
                                                        <h4 className="text-sm font-black text-indigo-600 uppercase mb-4 border-b border-indigo-100 pb-2">{month}</h4>
                                                        <div className="space-y-4">
                                                            {[1, 2, 3, 4, 5].map(week => {
                                                                const suppliersInWeek = suppliersInMonth.filter(s => getSafeScheduleWeeks(s.monthlySchedule, month).includes(week));
                                                                if (suppliersInWeek.length === 0) return null;

                                                                return (
                                                                    <div key={week} className="space-y-1">
                                                                        <div className="text-[10px] font-black text-zinc-400 uppercase">Semana {week}</div>
                                                                        <div className="flex flex-col gap-1">
                                                                            {suppliersInWeek.map(s => {
                                                                                const items = (s.contractItems || []) as any[];
                                                                                return (
                                                                                    <div key={s.id} className="bg-white px-3 py-2 rounded-lg border border-zinc-200 shadow-sm">
                                                                                        <div className="flex justify-between items-center mb-1">
                                                                                            <span className="text-xs font-black text-zinc-900 uppercase leading-none">{s.name}</span>
                                                                                            <span className="text-[9px] text-zinc-400 font-mono">{s.cpfCnpj}</span>
                                                                                        </div>
                                                                                        {items.length > 0 && (
                                                                                            <div className="flex flex-wrap gap-1">
                                                                                                {items.map((it, i) => (
                                                                                                    <span key={i} className="text-[8px] bg-zinc-50 text-zinc-500 px-1.5 py-0.5 rounded border border-zinc-100 uppercase font-bold">
                                                                                                        {it.name} ({it.totalKg} {it.unit || 'KG'})
                                                                                                    </span>
                                                                                                ))}
                                                                                            </div>
                                                                                        )}
                                                                                    </div>
                                                                                );
                                                                            })}
                                                                        </div>
                                                                    </div>
                                                                );
                                                            })}
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ) : (
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                            {(activeSubTab === 'PPAIS' ? ppaisProducers : (activeSubTab.startsWith('PERECÍVEIS') ? currentPereciveisSuppliers : currentEstocaveisSuppliers)).sort((a, b) => (a.name || '').localeCompare(b.name || '')).map(s => {
                                                const targetMonths = activeSubTab === 'PPAIS' ? months : (selectedQuadrimestre === '1Q' ? months.slice(0, 4) : selectedQuadrimestre === '2Q' ? months.slice(4, 8) : months.slice(8, 12));
                                                const scheduledMonths = targetMonths.filter(m => getSafeScheduleWeeks(s.monthlySchedule, m).length > 0);
                                                
                                                const items = (s.contractItems || []) as any[];

                                                return (
                                                    <div key={s.id} className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm hover:border-indigo-200 transition-all">
                                                        <div className="flex justify-between items-start mb-6 border-b border-zinc-100 pb-4">
                                                            <div>
                                                                <h4 className="text-md font-black text-zinc-900 uppercase tracking-tighter leading-none">{s.name}</h4>
                                                                <p className="text-[10px] text-zinc-400 font-mono mt-1 uppercase tracking-widest">{s.cpfCnpj}</p>
                                                            </div>
                                                            <div className="bg-indigo-50 px-3 py-1 rounded-lg">
                                                                <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">{scheduledMonths.length} Meses</span>
                                                            </div>
                                                        </div>

                                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                                            <div>
                                                                <h5 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                                                                    <div className="w-1 h-3 bg-emerald-400 rounded-full"></div>
                                                                    Itens Contratados
                                                                </h5>
                                                                <div className="space-y-1.5">
                                                                    {items.map((it, i) => (
                                                                        <div key={i} className="flex justify-between items-center bg-zinc-50 px-3 py-1.5 rounded-lg border border-zinc-100">
                                                                            <span className="text-[10px] font-bold text-zinc-700 uppercase">{it.name}</span>
                                                                            <span className="text-[10px] font-black text-indigo-700">{it.totalKg} {it.unit || 'KG'}</span>
                                                                        </div>
                                                                    ))}
                                                                </div>
                                                            </div>

                                                            <div>
                                                                <h5 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                                                                    <div className="w-1 h-3 bg-indigo-400 rounded-full"></div>
                                                                    Cronograma Mensal
                                                                </h5>
                                                                <div className="space-y-2">
                                                                    {scheduledMonths.map(m => (
                                                                        <div key={m} className="flex items-center justify-between group">
                                                                            <span className="text-[11px] font-black text-zinc-800 uppercase w-20">{m}</span>
                                                                            <div className="flex gap-1">
                                                                                {[1, 2, 3, 4, 5].map(w => {
                                                                                    const isScheduled = getSafeScheduleWeeks(s.monthlySchedule, m).includes(w);
                                                                                    return (
                                                                                        <div 
                                                                                            key={w} 
                                                                                            className={`w-5 h-5 rounded-md flex items-center justify-center text-[9px] font-black transition-all ${
                                                                                                isScheduled 
                                                                                                ? 'bg-indigo-600 text-white shadow-sm ring-2 ring-indigo-100' 
                                                                                                : 'bg-zinc-100 text-zinc-300'
                                                                                            }`}
                                                                                            title={`Semana ${w}`}
                                                                                        >
                                                                                            {w}
                                                                                        </div>
                                                                                    );
                                                                                })}
                                                                            </div>
                                                                        </div>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    )}
                                </div>
                            </div>
                        ) : (
                                <AdminAcquisitionItems 
                                category={activeSubTab === 'AUDIT' ? 'PPAIS' : activeSubTab} 
                                items={acquisitionItems} 
                                perCapitaConfig={perCapitaConfig}
                                onUpdate={onUpdateAcquisitionItem} 
                                onDelete={onDeleteAcquisitionItem} 
                                contractItems={
                                    activeSubTab === 'PPAIS' ? contractItemNamesByCategory['PPAIS'] :
                                    (activeSubTab.startsWith('PERECÍVEIS') ? contractItemNamesByCategory['PERECÍVEIS'] :
                                    (activeSubTab.startsWith('ESTOCÁVEIS') ? contractItemNamesByCategory['ESTOCÁVEIS'] : contractItemNamesByCategory['OTHERS']))
                                }
                                suppliers={
                                    activeSubTab === 'PPAIS' ? ppaisAsSuppliers : 
                                    (activeSubTab.startsWith('PERECÍVEIS') ? pereciveisAsSuppliers : 
                                    (activeSubTab.startsWith('ESTOCÁVEIS') ? estocaveisAsSuppliers : suppliers))
                                }
                                allSuppliers={suppliers}
                                onUpdateContractForItem={handleUpdateContractForCurrentQuadrimestre}
                                year={selectedYear}
                                quadrimestre={selectedQuadrimestre}
                                allItems={acquisitionItems}
                            />
                        )}
                    </div>
                </div>
            )}
        </div>
    )}

        <style>{`
                .input-field { all: unset; box-sizing: border-box; display: block; width: 100%; padding: 1rem; border: 2px solid #F3F4F6; border-radius: 1rem; background-color: #fff; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); } 
                .input-field:focus { border-color: #10B981; background-color: #fff; box-shadow: 0 0 0 6px rgba(16, 185, 129, 0.15); }
                @keyframes fade-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
                .animate-fade-in { animation: fade-in 0.4s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default AdminPerCapita;