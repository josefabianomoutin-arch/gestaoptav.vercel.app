
import React, { useMemo } from 'react';
import { Truck } from 'lucide-react';
import { VehicleExitOrder, DriverAsset, VehicleAsset, ValidationRole, VehicleInspection } from '../types';
import AdminVehicleExitOrder from './AdminVehicleExitOrder';

interface JulioDashboardProps {
  vehicleExitOrders: VehicleExitOrder[];
  vehicleInspections: VehicleInspection[];
  driverAssets: DriverAsset[];
  vehicleAssets: VehicleAsset[];
  validationRoles: ValidationRole[];
  onLogout: () => void;
  onRegisterVehicleExitOrder: (order: Omit<VehicleExitOrder, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateVehicleExitOrder: (order: VehicleExitOrder) => Promise<{ success: boolean; message: string }>;
  onDeleteVehicleExitOrder: (id: string) => Promise<{ success: boolean; message: string }>;
  onRegisterDriverAsset: (s: Omit<DriverAsset, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateDriverAsset: (s: DriverAsset) => Promise<{ success: boolean; message: string }>;
  onDeleteDriverAsset: (id: string) => Promise<{ success: boolean; message: string }>;
  onRegisterVehicleAsset: (v: Omit<VehicleAsset, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateVehicleAsset: (v: VehicleAsset) => Promise<{ success: boolean; message: string }>;
  onDeleteVehicleAsset: (id: string) => Promise<{ success: boolean; message: string }>;
  onRegisterValidationRole: (vr: Omit<ValidationRole, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateValidationRole: (vr: ValidationRole) => Promise<{ success: boolean; message: string }>;
  onDeleteValidationRole: (id: string) => Promise<{ success: boolean; message: string }>;
  onRegisterVehicleInspection: (inspection: Omit<VehicleInspection, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateVehicleInspection: (inspection: VehicleInspection) => Promise<{ success: boolean; message: string }>;
  onDeleteVehicleInspection: (id: string) => Promise<{ success: boolean; message: string }>;
  [key: string]: any;
}

const JulioDashboard: React.FC<JulioDashboardProps> = ({
  vehicleExitOrders,
  vehicleInspections,
  driverAssets,
  vehicleAssets,
  validationRoles,
  onLogout,
  onRegisterVehicleExitOrder,
  onUpdateVehicleExitOrder,
  onDeleteVehicleExitOrder,
  onRegisterDriverAsset,
  onUpdateDriverAsset,
  onDeleteDriverAsset,
  onRegisterVehicleAsset,
  onUpdateVehicleAsset,
  onDeleteVehicleAsset,
  onRegisterValidationRole,
  onUpdateValidationRole,
  onDeleteValidationRole,
  onRegisterVehicleInspection,
  onUpdateVehicleInspection,
  onDeleteVehicleInspection,
}) => {
  const [activeTab, setActiveTab] = React.useState<'veiculos'>('veiculos');

  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'BOM DIA';
    if (hour >= 12 && hour < 18) return 'BOA TARDE';
    return 'BOA NOITE';
  }, []);

  const todayStr = new Date().toISOString().split('T')[0];

  const vehiclesOutside = useMemo(() => {
    return vehicleExitOrders.filter(o => o.exitTime && (!o.returnTime || o.returnTime.trim() === '') && o.status !== 'concluida');
  }, [vehicleExitOrders]);

  const availableVehicles = useMemo(() => {
    const outsidePlates = vehiclesOutside.map(o => (o.plate || '').replace(/[^A-Z0-9]/g, '').toUpperCase());
    return vehicleAssets.filter(v => {
      const p = (v.plate || '').replace(/[^A-Z0-9]/g, '').toUpperCase();
      return p && !outsidePlates.includes(p);
    });
  }, [vehicleAssets, vehiclesOutside]);

  const vehiclesPendingInspection = useMemo(() => {
    const inspectedVehicleIds = vehicleInspections
      .filter(i => i.date.startsWith(todayStr))
      .map(i => i.vehicleId);
    
    return vehicleAssets.filter(v => !inspectedVehicleIds.includes(v.id));
  }, [vehicleAssets, vehicleInspections, todayStr]);

  const marqueeMessage = `${greeting}, JULIO E FARLEY: ` +
    `VEÍCULOS FORA DA UNIDADE: ${vehiclesOutside.length > 0 ? vehiclesOutside.map(o => `${o.vehicle} (${o.plate}) - MOT: ${o.responsibleServer} - DEST: ${o.destination}`).join(' • ') : 'NENHUM'} | ` +
    `VEÍCULOS DISPONÍVEIS: ${availableVehicles.length > 0 ? availableVehicles.map(v => `${v.model} (${v.plate})`).join(' • ') : 'NENHUM'} | ` +
    `VEÍCULOS AGUARDANDO INSPEÇÃO HOJE: ${vehiclesPendingInspection.length > 0 ? vehiclesPendingInspection.map(v => `${v.model} (${v.plate})`).join(' • ') : 'NENHUM'}`;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white text-indigo-950 p-4 shadow-sm flex justify-between items-center sticky top-0 z-50 border-b border-gray-200">
        <div className="flex items-center gap-6 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-50 p-2 rounded-xl border border-indigo-100">
              <Truck className="h-6 w-6 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-lg font-black uppercase italic tracking-tighter leading-none whitespace-nowrap text-indigo-950">
                SEÇÃO DE INFRAESTRUTURA E LOGÍSTICA
              </h1>
              <p className="text-[9px] text-indigo-500 font-bold uppercase tracking-widest">Gestão de Ordem de Saída</p>
            </div>
          </div>

          <nav className="flex gap-2 bg-gray-50 p-1 rounded-xl border border-gray-200">
            <button
              onClick={() => setActiveTab('veiculos')}
              className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase transition-all ${
                activeTab === 'veiculos'
                  ? 'bg-white text-indigo-600 shadow-sm border border-gray-200'
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              Veículos
            </button>
          </nav>
        </div>

        {/* MENSAGEM DINÂMICA DE SAUDAÇÃO E VEÍCULOS */}
        <div className="flex-1 mx-4 md:mx-10 bg-indigo-50 border border-indigo-100 rounded-2xl p-2 overflow-hidden whitespace-nowrap relative h-12 flex items-center">
            <div className="animate-marquee inline-block text-indigo-900 font-black text-xs md:text-sm uppercase italic tracking-tight">
                {marqueeMessage}
            </div>
        </div>

        <button onClick={onLogout} className="flex-shrink-0 bg-red-50 hover:bg-red-100 text-red-600 font-black py-2 px-4 rounded-xl text-[10px] uppercase transition-all border border-red-200">Sair</button>
      </header>

      <main className="p-4 max-w-7xl mx-auto">
        <AdminVehicleExitOrder 
          orders={vehicleExitOrders}
          inspections={vehicleInspections}
          vehicleAssets={vehicleAssets}
          driverAssets={driverAssets}
          validationRoles={validationRoles}
          onRegister={onRegisterVehicleExitOrder}
          onUpdate={onUpdateVehicleExitOrder}
          onDelete={onDeleteVehicleExitOrder}
          onRegisterVehicleAsset={onRegisterVehicleAsset}
          onUpdateVehicleAsset={onUpdateVehicleAsset}
          onDeleteVehicleAsset={onDeleteVehicleAsset}
          onRegisterDriverAsset={onRegisterDriverAsset}
          onUpdateDriverAsset={onUpdateDriverAsset}
          onDeleteDriverAsset={onDeleteDriverAsset}
          onRegisterValidationRole={onRegisterValidationRole}
          onUpdateValidationRole={onUpdateValidationRole}
          onDeleteValidationRole={onDeleteValidationRole}
          onRegisterInspection={onRegisterVehicleInspection}
          onUpdateInspection={onUpdateVehicleInspection}
          onDeleteInspection={onDeleteVehicleInspection}
          hideAssets={false}
          securityMode={false}
          showGateTab={true}
          userRole="julio"
        />
      </main>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
        .animate-marquee {
          display: inline-block;
          white-space: nowrap;
          animation: marquee 150s linear infinite;
          padding-left: 100%;
        }
      `}</style>
    </div>
  );
};

export default JulioDashboard;
