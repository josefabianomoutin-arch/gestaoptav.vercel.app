
import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { Supplier, ThirdPartyEntryLog, Delivery, ContractItem } from '../types';
import { Calendar, Clock, Truck, UserCheck, AlertCircle, Search, Trash2, CheckCircle2, FilePlus, QrCode, FileText } from 'lucide-react';
import { toast } from 'sonner';
import SendInvoiceModal from './SendInvoiceModal';
import { Html5Qrcode } from 'html5-qrcode';
import { ensureArray } from '../lib/utils';
import { POLICIA_PENAL_BADGE_B64 } from './policiaPenalData';

interface AgendaChegadasProps {
    suppliers: Supplier[];
    thirdPartyEntries: ThirdPartyEntryLog[];
    embedded?: boolean;
    perCapitaConfig?: any;
    onDeleteDelivery?: (supplierCpf: string, deliveryId: string) => Promise<{ success: boolean; message?: string }>;
    onUpdateDelivery?: (supplierCpf: string, deliveryId: string, updates: Partial<Delivery>) => Promise<{ success: boolean; message?: string }>;
    onSaveInvoice?: (supplierCpf: string, deliveryIds: string[], invoiceNumber: string, invoiceUrl: string, updatedDeliveries: Delivery[], invoiceDate?: string) => Promise<void>;
    onUpdateThirdPartyEntry?: (log: ThirdPartyEntryLog) => Promise<{ success: boolean; message?: string }>;
}

const AgendaChegadas: React.FC<AgendaChegadasProps> = ({ 
    suppliers, 
    thirdPartyEntries, 
    embedded,
    perCapitaConfig,
    onDeleteDelivery,
    onUpdateDelivery,
    onSaveInvoice,
    onUpdateThirdPartyEntry
}) => {
    const [selectedAgendaDate, setSelectedAgendaDate] = useState(new Date().toISOString().split('T')[0]);
    const [searchTerm, setSearchTerm] = useState('');
    const [isArrivalModalOpen, setIsArrivalModalOpen] = useState(false);
    const [selectedItem, setSelectedItem] = useState<any>(null);
    const [arrivalData, setArrivalData] = useState({ arrivalTime: '', invoiceNumber: '' });
    const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
    const [invoiceInfo, setInvoiceInfo] = useState<{ date: string; deliveries: Delivery[]; supplierCpf: string } | null>(null);

    // Relatório Mensal States
    const [isMonthlyReportOpen, setIsMonthlyReportOpen] = useState(false);
    const [selectedMonth, setSelectedMonth] = useState(() => {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    });
    const [monthlySearch, setMonthlySearch] = useState('');
    const [monthlyStatusFilter, setMonthlyStatusFilter] = useState('ALL'); // ALL, ARRIVED, EXITED, PENDING
    const [monthlyTypeFilter, setMonthlyTypeFilter] = useState('ALL'); // ALL, FORNECEDOR, TERCEIRO

    // QR Code Scanner States
    const [isScannerOpen, setIsScannerOpen] = useState(false);
    const [scannerMode, setScannerMode] = useState<'camera' | 'manual'>('camera');
    const [scanAction, setScanAction] = useState<'entrada' | 'saida'>('entrada');
    const [isExitModalOpen, setIsExitModalOpen] = useState(false);
    const [exitTimeInput, setExitTimeInput] = useState('');
    const [manualInputValue, setManualInputValue] = useState('');
    const [manualTimeValue, setManualTimeValue] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const manualInputRef = useRef<HTMLInputElement>(null);

    // Auto focus manual scan input
    useEffect(() => {
        if (isScannerOpen && scannerMode === 'manual') {
            const timer = setTimeout(() => {
                manualInputRef.current?.focus();
            }, 300);
            return () => clearTimeout(timer);
        }
    }, [isScannerOpen, scannerMode]);

    const cleanCpfNormalized = (val: any) => {
        const raw = String(val || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
        return raw.length >= 11 ? raw.substring(0, 11) : raw;
    };

    const locateDeliveryForCpfAndDate = (cpf: string, targetDate: string) => {
        const groups: Record<string, any> = {};
        const processedDeliveryIds = new Set<string>();
        
        const cleanNumber = (val: string) => String(val || '').trim().replace(/^0+/, '').replace(/[^\d]/g, '');
        const targetClean = cleanNumber(cpf);
        
        const processDelivery = (s: Supplier, d: any) => {
            if (!d || d.date !== targetDate) return;
            if (d.id) {
                const idStr = String(d.id);
                if (processedDeliveryIds.has(idStr)) return;
                processedDeliveryIds.add(idStr);
            }

            const sClean = cleanNumber(s.cpf);
            
            // 1. Exact match with supplier CPF/CNPJ
            const isExactMatch = sClean && (sClean === targetClean || (sClean.length >= 11 && targetClean.length >= 11 && sClean.substring(0, 11) === targetClean.substring(0, 11)));
            
            // 2. Exact match with delivery barcode (if present)
            const dBarcodeClean = cleanNumber(d.barcode);
            const isBarcodeMatch = dBarcodeClean && dBarcodeClean === targetClean;
            
            // 3. Match CNPJ embedded in 44-digit NF-e key
            const isEmbeddedCnpjMatch = targetClean.length === 44 && sClean && sClean === targetClean.substring(6, 20);
            
            if (!isExactMatch && !isBarcodeMatch && !isEmbeddedCnpjMatch) return;
            
            const rawCpf = s.cpf || (s as any).cpfCnpj;
            const normCpf = cleanCpfNormalized(rawCpf);
            if (!groups[normCpf]) {
                groups[normCpf] = {
                    id: d.id,
                    allIds: [d.id],
                    supplierName: s.name,
                    supplierCpf: rawCpf || normCpf,
                    time: d.time || '',
                    arrivalTime: d.arrivalTime,
                    exitTime: d.exitTime,
                    deliveries: [d]
                };
            } else {
                if (d.id && !groups[normCpf].allIds.includes(d.id)) {
                    groups[normCpf].allIds.push(d.id);
                }
                groups[normCpf].deliveries.push(d);
                if (d.time && (!groups[normCpf].time || groups[normCpf].time === '00:00')) {
                    groups[normCpf].time = d.time;
                }
                if (d.arrivalTime && !groups[normCpf].arrivalTime) {
                    groups[normCpf].arrivalTime = d.arrivalTime;
                }
                if (d.exitTime && !groups[normCpf].exitTime) {
                    groups[normCpf].exitTime = d.exitTime;
                }
            }
        };

        ensureArray(suppliers).forEach(s => {
            if (!s) return;
            const deliveries = ensureArray(s.deliveries);
            deliveries.forEach(d => processDelivery(s as any, d));
        });

        if (perCapitaConfig) {
            ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'].forEach(key => {
                const producers = ensureArray(perCapitaConfig[key]);
                producers.forEach((p: any) => {
                    const deliveries = ensureArray(p.deliveries);
                    deliveries.forEach(d => processDelivery({ name: p.name, cpf: p.cpfCnpj || p.cpf } as any, d));
                });
            });
        }

        const list = Object.values(groups);
        return list.length > 0 ? list[0] : null;
    };

    const handleScanSuccess = async (text: string) => {
        if (!text) return;
        if (isSubmitting) return;

        setIsSubmitting(true);
        try {
            let cpf = '';
            let date = selectedAgendaDate;
            
            if (text.startsWith('CHECKIN_DELIVERY:')) {
                const parts = text.split(':');
                if (parts.length >= 3) {
                    cpf = parts[1];
                    date = parts[2];
                }
            } else {
                // Tenta buscar por CPF bruto ou CNPJ
                cpf = text.replace(/[^\d]/g, '');
            }

            if (!cpf) {
                toast.error("Código QR ou CPF inválido.");
                setIsScannerOpen(false);
                return;
            }
            
            if (date !== selectedAgendaDate) {
                toast.error(`Ação NÃO liberada! Este agendamento é para o dia ${date}, mas a data selecionada na portaria é ${selectedAgendaDate}.`);
                setIsScannerOpen(false);
                return;
            }
            
            const foundGroup = locateDeliveryForCpfAndDate(cpf, date);
            const nowTime = (scannerMode === 'manual' && manualTimeValue) ? manualTimeValue : new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

            if (foundGroup) {
                if (scanAction === 'entrada') {
                    if (foundGroup.arrivalTime) {
                        toast.info(`Chegada de ${foundGroup.supplierName} já foi registrada às ${foundGroup.arrivalTime}`);
                        setIsScannerOpen(false);
                        return;
                    }
                    
                    if (onUpdateDelivery) {
                        let success = true;
                        for (const id of foundGroup.allIds) {
                            const res = await onUpdateDelivery(foundGroup.supplierCpf, id, {
                                arrivalTime: nowTime
                            });
                            if (!res.success) success = false;
                        }
                        if (success) {
                            toast.success(`Check-In Realizado! Entrada de ${foundGroup.supplierName} liberada às ${nowTime}`);
                        } else {
                            toast.error(`Falha ao registrar a chegada no servidor.`);
                        }
                    } else {
                        toast.success(`QR Code validado com sucesso para ${foundGroup.supplierName}!`);
                    }
                } else {
                    // scanAction === 'saida'
                    if (foundGroup.exitTime) {
                        toast.info(`Saída de ${foundGroup.supplierName} já foi registrada às ${foundGroup.exitTime}`);
                        setIsScannerOpen(false);
                        return;
                    }
                    
                    if (onUpdateDelivery) {
                        let success = true;
                        for (const id of foundGroup.allIds) {
                            const res = await onUpdateDelivery(foundGroup.supplierCpf, id, {
                                exitTime: nowTime
                            });
                            if (!res.success) success = false;
                        }
                        if (success) {
                            toast.success(`Check-Out Realizado! Saída de ${foundGroup.supplierName} confirmada às ${nowTime}`);
                        } else {
                            toast.error(`Falha ao registrar a saída no servidor.`);
                        }
                    } else {
                        toast.success(`Saída validada com sucesso para ${foundGroup.supplierName}!`);
                    }
                }
                setIsScannerOpen(false);
            } else {
                // Tenta localizar nos Terceiros
                const targetClean = cpf.replace(/[^\d]/g, '');
                const companyCnpjToMatch = targetClean.length === 44 ? targetClean.substring(6, 20) : targetClean;

                const log = (thirdPartyEntries || []).find(l => {
                    const cleanCnpj = (l.companyCnpj || '').replace(/[^\d]/g, '');
                    const dBarcodeClean = (l.barcode || '').replace(/[^\d]/g, '');
                    return l.date === date && (
                        cleanCnpj === companyCnpjToMatch || 
                        (dBarcodeClean && dBarcodeClean === targetClean)
                    );
                });

                if (log) {
                    if (scanAction === 'entrada') {
                        if (log.arrivalTime) {
                            toast.info(`Chegada de ${log.companyName} já foi registrada às ${log.arrivalTime}`);
                            setIsScannerOpen(false);
                            return;
                        }
                        if (onUpdateThirdPartyEntry) {
                            const res = await onUpdateThirdPartyEntry({
                                ...log,
                                arrivalTime: nowTime,
                                status: 'concluido'
                            });
                            if (res.success) {
                                toast.success(`Check-In Realizado! Entrada de ${log.companyName} confirmada às ${nowTime}`);
                            } else {
                                toast.error("Erro ao registrar entrada.");
                            }
                        }
                    } else {
                        // scanAction === 'saida'
                        if (log.exitTime) {
                            toast.info(`Saída de ${log.companyName} já foi registrada às ${log.exitTime}`);
                            setIsScannerOpen(false);
                            return;
                        }
                        if (onUpdateThirdPartyEntry) {
                            const res = await onUpdateThirdPartyEntry({
                                ...log,
                                exitTime: nowTime,
                                status: 'concluido'
                            });
                            if (res.success) {
                                toast.success(`Check-Out Realizado! Saída de ${log.companyName} confirmada às ${nowTime}`);
                            } else {
                                toast.error("Erro ao registrar saída.");
                            }
                        }
                    }
                    setIsScannerOpen(false);
                } else {
                    toast.error(`Nenhum agendamento pendente encontrado para o CPF/CNPJ ${cpf} no dia ${date}.`);
                    setIsScannerOpen(false);
                }
            }
        } catch (err) {
            console.error("Error saving manual arrival/exit:", err);
            toast.error("Erro ao registrar no servidor. Verifique a conexão.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleManualSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (manualInputValue.trim()) {
            handleScanSuccess(manualInputValue.trim());
            setManualInputValue('');
        } else {
            toast.error("Por favor, informe o CPF, CNPJ ou código do fornecedor.");
        }
    };

    // Camera Scan effect
    useEffect(() => {
        let html5QrCode: Html5Qrcode | null = null;
        let isStopped = false;

        if (isScannerOpen && scannerMode === 'camera') {
            const timer = setTimeout(() => {
                try {
                    const element = document.getElementById("qr-reader");
                    if (!element) return;

                    html5QrCode = new Html5Qrcode("qr-reader");
                    
                    const startScanner = async () => {
                        try {
                            await html5QrCode?.start(
                                { facingMode: "environment" },
                                {
                                    fps: 10,
                                    qrbox: { width: 250, height: 250 }
                                },
                                (decodedText) => {
                                    handleScanSuccess(decodedText);
                                    if (html5QrCode && html5QrCode.isScanning && !isStopped) {
                                        isStopped = true;
                                        html5QrCode.stop().catch(err => console.warn("Erro ao parar camera:", err));
                                    }
                                },
                                () => {}
                            );
                        } catch (err) {
                            console.warn("Failed with environment camera, trying user camera...", err);
                            if (isStopped) return;
                            try {
                                await html5QrCode?.start(
                                    { facingMode: "user" },
                                    {
                                        fps: 10,
                                        qrbox: { width: 250, height: 250 }
                                    },
                                    (decodedText) => {
                                        handleScanSuccess(decodedText);
                                        if (html5QrCode && html5QrCode.isScanning && !isStopped) {
                                            isStopped = true;
                                            html5QrCode.stop().catch(stopErr => console.warn("Erro:", stopErr));
                                        }
                                    },
                                    () => {}
                                );
                            } catch (fallbackErr) {
                                console.error("Camera fallback failed too:", fallbackErr);
                                try {
                                    const devices = await Html5Qrcode.getCameras();
                                    if (devices && devices.length > 0 && !isStopped) {
                                        const cameraId = devices[devices.length - 1].id;
                                        await html5QrCode?.start(
                                            cameraId,
                                            { fps: 10, qrbox: { width: 250, height: 250 } },
                                            (decodedText) => {
                                                handleScanSuccess(decodedText);
                                                if (html5QrCode && html5QrCode.isScanning && !isStopped) {
                                                    isStopped = true;
                                                    html5QrCode.stop().catch(() => {});
                                                }
                                            },
                                            () => {}
                                        );
                                    } else {
                                        toast.error("Nenhuma câmera encontrada no dispositivo.");
                                    }
                                } catch (_deviceErr) {
                                    toast.error("Não foi possível acessar a câmera do dispositivo.");
                                }
                            }
                        }
                    };

                    startScanner();
                } catch (e) {
                    console.error("Camera scanner instance error:", e);
                }
            }, 300);

            return () => {
                clearTimeout(timer);
                isStopped = true;
                if (html5QrCode) {
                    const stopScanner = async () => {
                        try {
                            if (html5QrCode && html5QrCode.isScanning) {
                                await html5QrCode.stop();
                            }
                        } catch (err) {
                            console.warn("Erro ao parar camera no cleanup:", err);
                        }
                    };
                    stopScanner();
                }
            };
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isScannerOpen, scannerMode, selectedAgendaDate]);

    const monthlyDeliveries = useMemo(() => {
        const groups: Record<string, any> = {};
        const processedDeliveryIds = new Set<string>();
        
        const processDelivery = (s: Supplier, d: any, type: 'FORNECEDOR' | 'TERCEIRO') => {
            if (!d || !d.date || !d.date.startsWith(selectedMonth)) return;
            
            if (d.id) {
                const idStr = String(d.id);
                if (processedDeliveryIds.has(idStr)) return;
                processedDeliveryIds.add(idStr);
            }

            const rawCpf = s.cpf || (s as any).cpfCnpj;
            const normCpf = cleanCpfNormalized(rawCpf);
            if (!normCpf) return;

            const groupKey = `${type}-${normCpf}-${d.date}`;
            if (!groups[groupKey]) {
                const isFaturado = d.item !== 'AGENDAMENTO PENDENTE' && (d.invoiceNumber || d.invoiceUploaded);
                groups[groupKey] = {
                    id: d.id,
                    allIds: [d.id],
                    supplierName: s.name,
                    supplierCpf: rawCpf || normCpf,
                    date: d.date,
                    time: d.time || '00:00',
                    arrivalTime: d.arrivalTime,
                    exitTime: d.exitTime,
                    status: isFaturado ? 'CONCLUÍDO' : 'AGENDADO',
                    type: type,
                    items: [d],
                    deliveries: [d],
                    observations: d.observations || ''
                };
            } else {
                if (d.id && !groups[groupKey].allIds.includes(d.id)) {
                    groups[groupKey].allIds.push(d.id);
                }
                groups[groupKey].items.push(d);
                groups[groupKey].deliveries.push(d);
                if (d.time && (!groups[groupKey].time || groups[groupKey].time === '00:00')) {
                    groups[groupKey].time = d.time;
                }
                if (d.arrivalTime && !groups[groupKey].arrivalTime) {
                    groups[groupKey].arrivalTime = d.arrivalTime;
                }
                if (d.exitTime && !groups[groupKey].exitTime) {
                    groups[groupKey].exitTime = d.exitTime;
                }
                if (d.observations && !groups[groupKey].observations.includes(d.observations)) {
                    groups[groupKey].observations = groups[groupKey].observations 
                        ? `${groups[groupKey].observations}; ${d.observations}`
                        : d.observations;
                }
                if (!(d.item !== 'AGENDAMENTO PENDENTE' && (d.invoiceNumber || d.invoiceUploaded))) {
                    groups[groupKey].status = 'AGENDADO';
                }
            }
        };

        ensureArray(suppliers).forEach(s => {
            if (!s) return;
            const deliveries = ensureArray(s.deliveries);
            deliveries.forEach(d => processDelivery(s as any, d, 'FORNECEDOR'));
        });

        if (perCapitaConfig) {
            ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'].forEach(key => {
                const producers = ensureArray(perCapitaConfig[key]);
                producers.forEach((p: any) => {
                    const deliveries = ensureArray(p.deliveries);
                    deliveries.forEach(d => processDelivery({ name: p.name, cpf: p.cpfCnpj || p.cpf } as any, d, 'FORNECEDOR'));
                });
            });
        }

        const list = Object.values(groups);

        (thirdPartyEntries || []).forEach(log => {
            if (log.date && log.date.startsWith(selectedMonth)) {
                let status: 'AGENDADO' | 'CONCLUÍDO' | 'TERCEIRO' | 'CANCELADO' = 'TERCEIRO';
                if (log.status === 'concluido') status = 'CONCLUÍDO';
                else if (log.status === 'cancelado') status = 'CANCELADO';
                else if (log.status === 'agendado') status = 'AGENDADO';

                list.push({
                    id: log.id,
                    allIds: [log.id],
                    supplierName: log.companyName,
                    supplierCpf: log.companyCnpj,
                    date: log.date,
                    time: log.time || '00:00',
                    arrivalTime: log.arrivalTime,
                    exitTime: log.exitTime,
                    status: status,
                    type: 'TERCEIRO',
                    items: [],
                    deliveries: []
                });
            }
        });

        return list.sort((a, b) => {
            const dateCompare = (a.date || '').localeCompare(b.date || '');
            if (dateCompare !== 0) return dateCompare;
            return (a.time || '00:00').localeCompare(b.time || '00:00');
        });
    }, [suppliers, thirdPartyEntries, selectedMonth, perCapitaConfig]);

    const dailyDeliveries = useMemo(() => {
        const groups: Record<string, any> = {};
        const processedDeliveryIds = new Set<string>();
        
        const processDelivery = (s: Supplier, d: any, type: 'FORNECEDOR' | 'TERCEIRO') => {
            if (!d || d.date !== selectedAgendaDate) return;
            
            if (d.id) {
                const idStr = String(d.id);
                if (processedDeliveryIds.has(idStr)) return;
                processedDeliveryIds.add(idStr);
            }

            const rawCpf = s.cpf || (s as any).cpfCnpj;
            const normCpf = cleanCpfNormalized(rawCpf);
            if (!normCpf) return;

            const groupKey = `${type}-${normCpf}`;
            if (!groups[groupKey]) {
                const isFaturado = d.item !== 'AGENDAMENTO PENDENTE' && (d.invoiceNumber || d.invoiceUploaded);
                groups[groupKey] = {
                    id: d.id, // Primary ID for modal usage
                    allIds: [d.id],
                    supplierName: s.name,
                    supplierCpf: rawCpf || normCpf,
                    time: d.time || '',
                    arrivalTime: d.arrivalTime,
                    exitTime: d.exitTime,
                    status: isFaturado ? 'CONCLUÍDO' : 'AGENDADO',
                    type: type,
                    items: [d],
                    deliveries: [d],
                    observations: d.observations || ''
                };
            } else {
                if (d.id && !groups[groupKey].allIds.includes(d.id)) {
                    groups[groupKey].allIds.push(d.id);
                }
                groups[groupKey].items.push(d);
                groups[groupKey].deliveries.push(d);
                if (d.time && (!groups[groupKey].time || groups[groupKey].time === '00:00')) {
                    groups[groupKey].time = d.time;
                }
                if (d.arrivalTime && !groups[groupKey].arrivalTime) {
                    groups[groupKey].arrivalTime = d.arrivalTime;
                }
                if (d.exitTime && !groups[groupKey].exitTime) {
                    groups[groupKey].exitTime = d.exitTime;
                }
                if (d.observations && !groups[groupKey].observations.includes(d.observations)) {
                    groups[groupKey].observations = groups[groupKey].observations 
                        ? `${groups[groupKey].observations}; ${d.observations}`
                        : d.observations;
                }
                if (!(d.item !== 'AGENDAMENTO PENDENTE' && (d.invoiceNumber || d.invoiceUploaded))) {
                    groups[groupKey].status = 'AGENDADO';
                }
            }
        };

        ensureArray(suppliers).forEach(s => {
            if (!s) return;
            const deliveries = ensureArray(s.deliveries);
            deliveries.forEach(d => processDelivery(s as any, d, 'FORNECEDOR'));
        });

        if (perCapitaConfig) {
            ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'].forEach(key => {
                const producers = ensureArray(perCapitaConfig[key]);
                producers.forEach((p: any) => {
                    const deliveries = ensureArray(p.deliveries);
                    deliveries.forEach(d => processDelivery({ name: p.name, cpf: p.cpfCnpj || p.cpf } as any, d, 'FORNECEDOR'));
                });
            });
        }

        const list = Object.values(groups);

        (thirdPartyEntries || []).forEach(log => {
            if (log.date === selectedAgendaDate) {
                let status: 'AGENDADO' | 'CONCLUÍDO' | 'TERCEIRO' | 'CANCELADO' = 'TERCEIRO';
                if (log.status === 'concluido') status = 'CONCLUÍDO';
                else if (log.status === 'cancelado') status = 'CANCELADO';
                else if (log.status === 'agendado') status = 'AGENDADO';

                list.push({
                    id: log.id,
                    allIds: [log.id],
                    supplierName: log.companyName,
                    supplierCpf: log.companyCnpj,
                    time: log.time || '00:00',
                    arrivalTime: log.arrivalTime,
                    exitTime: log.exitTime,
                    status: status,
                    type: 'TERCEIRO',
                    items: [],
                    deliveries: []
                });
            }
        });

        return list
            .filter(item => 
                (item.supplierName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                (item.supplierCpf || '').toLowerCase().includes(searchTerm.toLowerCase())
            )
            .sort((a, b) => (a.time || '00:00').localeCompare(b.time || '00:00'));
    }, [suppliers, thirdPartyEntries, selectedAgendaDate, searchTerm, perCapitaConfig]);

    const pendingItems = useMemo(() => {
        return dailyDeliveries.filter(item => {
            if (item.status === 'CANCELADO') return false;
            if (scanAction === 'entrada') {
                return !item.arrivalTime;
            } else {
                return !item.exitTime;
            }
        });
    }, [dailyDeliveries, scanAction]);

    const handleDelete = async (item: any) => {
        if (!onDeleteDelivery) return;
        const msg = item.status === 'CONCLUÍDO' 
            ? `ATENÇÃO: Este agendamento já possui Nota Fiscal vinculada. Deseja realmente EXCLUIR permanentemente o agendamento de ${item.supplierName}?`
            : `Excluir agendamento de ${item.supplierName}?`;
            
        if (confirm(msg)) {
            let success = true;
            for (const id of item.allIds) {
                const res = await onDeleteDelivery(item.supplierCpf, id);
                if (!res.success) success = false;
            }
            if (success) toast.success("Agendamentos excluídos!");
            else toast.error("Erro ao excluir alguns itens.");
        }
    };

    const handleRegisterArrival = (item: any) => {
        setSelectedItem(item);
        setArrivalData({ 
            arrivalTime: item.arrivalTime || new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }), 
            invoiceNumber: item.items?.[0]?.invoiceNumber || '' 
        });
        setExitTimeInput(item.exitTime || '');
        setIsArrivalModalOpen(true);
    };

    const handleOpenInvoiceModal = (item: any) => {
        if (!item.deliveries || item.deliveries.length === 0) return;
        setSelectedItem(item);
        setInvoiceInfo({
            date: item.deliveries[0].date,
            deliveries: item.deliveries.map((d: any) => ({ ...d })),
            supplierCpf: item.supplierCpf
        });
        setIsInvoiceModalOpen(true);
    };

    const handleRegisterExit = (item: any) => {
        setSelectedItem(item);
        setArrivalData({ 
            arrivalTime: item.arrivalTime || '', 
            invoiceNumber: item.items?.[0]?.invoiceNumber || '' 
        });
        setExitTimeInput(item.exitTime || new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }));
        setIsExitModalOpen(true);
    };

    const savePortaria = async () => {
        if (!selectedItem) return;
        if (isSubmitting) return;
        
        setIsSubmitting(true);
        try {
            if (selectedItem.type === 'FORNECEDOR' && onUpdateDelivery) {
                for (const id of selectedItem.allIds) {
                    await onUpdateDelivery(selectedItem.supplierCpf, id, { 
                        arrivalTime: arrivalData.arrivalTime || '',
                        exitTime: exitTimeInput || '',
                        invoiceNumber: arrivalData.invoiceNumber || selectedItem.items?.[0]?.invoiceNumber || ''
                    });
                }
                toast.success("Dados de portaria atualizados!");
            } else if (selectedItem.type === 'TERCEIRO' && onUpdateThirdPartyEntry) {
                const log = (thirdPartyEntries || []).find(l => l.id === selectedItem.id);
                if (log) {
                    await onUpdateThirdPartyEntry({
                        ...log,
                        arrivalTime: arrivalData.arrivalTime || '',
                        exitTime: exitTimeInput || '',
                        status: (arrivalData.arrivalTime && exitTimeInput) ? 'concluido' : log.status
                    });
                    toast.success("Dados de portaria atualizados!");
                }
            }
            setIsArrivalModalOpen(false);
            setIsExitModalOpen(false);
        } catch (_e) {
            toast.error("Erro ao salvar dados de portaria.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleGenerateReport = () => {
        const printWindow = window.open('', '_blank');
        if (!printWindow) {
            toast.error("Por favor, permita popups para imprimir o relatório.");
            return;
        }

        const dateParts = selectedAgendaDate.split('-');
        const formattedDateReport = dateParts.length === 3 ? `${dateParts[2]}/${dateParts[1]}/${dateParts[0]}` : selectedAgendaDate;

        const totalActive = dailyDeliveries.filter(d => d.status !== 'CANCELADO').length;
        const totalArrived = dailyDeliveries.filter(d => d.arrivalTime && d.status !== 'CANCELADO').length;
        const totalExited = dailyDeliveries.filter(d => d.exitTime && d.status !== 'CANCELADO').length;
        const totalPending = totalActive - totalArrived;

        const rowsHtml = dailyDeliveries.map(item => {
            const itemsList = (item.items || []).map((it: any) => `${it.item || it.itemName || ''} (${it.kg}kg)`).join(', ');
            return `
                <tr>
                    <td class="text-center font-bold" style="font-size: 9px;">${item.time}</td>
                    <td style="font-size: 9px; font-weight: bold;">${item.supplierName.toUpperCase()}</td>
                    <td class="text-center font-mono" style="font-size: 8px;">${item.supplierCpf}</td>
                    <td class="text-center font-bold text-xs" style="font-size: 8px;">${item.type}</td>
                    <td class="text-center ${item.arrivalTime ? 'font-bold' : 'italic text-red'}" style="font-size: 9px;">${item.arrivalTime || 'Aguardando...'}</td>
                    <td class="text-center ${item.exitTime ? 'font-bold' : 'italic text-red'}" style="font-size: 9px;">${item.exitTime || 'Aguardando...'}</td>
                    <td class="text-center font-bold text-xs" style="font-size: 8px;">${item.status}</td>
                    <td style="font-size: 8px;">${itemsList || 'N/A'}</td>
                    <td style="font-size: 8px; font-style: italic;">${item.observations || ''}</td>
                </tr>
            `;
        }).join('');

        const htmlContent = `
            <html>
            <head>
                <title>Relatório de Portaria (Controle de Entrada e Saída) - ${formattedDateReport}</title>
                <style>
                    @page { size: A4 landscape; margin: 10mm; }
                    body { font-family: Arial, sans-serif; font-size: 8.5pt; line-height: 1.3; color: #000; margin: 0; padding: 0; }
                    .header-title { text-align: center; font-weight: bold; font-size: 14pt; text-transform: uppercase; margin-bottom: 5px; }
                    .header-subtitle { text-align: center; font-weight: bold; font-size: 9pt; text-transform: uppercase; margin-bottom: 15px; border-bottom: 2px solid #000; padding-bottom: 5px; color: #333; }
                    
                    .summary-boxes { display: flex; gap: 10px; margin-bottom: 15px; }
                    .summary-box { flex: 1; border: 1.5px solid #000; padding: 8px; border-radius: 4px; text-align: center; }
                    .summary-val { font-size: 14pt; font-weight: bold; margin-top: 3px; }
                    .label { font-weight: bold; text-transform: uppercase; font-size: 7.5pt; color: #555; }
                    
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; text-transform: uppercase; }
                    th, td { border: 1px solid #000; padding: 5px; text-align: left; vertical-align: middle; }
                    th { font-weight: bold; text-transform: uppercase; background-color: #f2f2f2; text-align: center; font-size: 8pt; }
                    
                    .text-center { text-align: center; }
                    .text-right { text-align: right; }
                    .font-bold { font-weight: bold; }
                    .text-red { color: #b91c1c; font-style: italic; font-weight: normal; }
                    
                    .signatures { display: flex; justify-content: space-between; margin-top: 50px; padding: 0 50px; }
                    .signature-box { text-align: center; width: 250px; }
                    .signature-line { border-top: 1px solid #000; margin-bottom: 5px; }
                    .signature-title { font-weight: bold; text-transform: uppercase; font-size: 7.5pt; }
                </style>
            </head>
            <body>
                <div style="text-align: center; margin-bottom: 8px;">
                    <img src="${POLICIA_PENAL_BADGE_B64}" style="height: 50px; width: auto; margin: 0 auto; display: block;" alt="Polícia Penal" />
                </div>
                <div class="header-title">PENITENCIÁRIA DE TAÍUVA</div>
                <div class="header-subtitle">Relatório de Controle de Portaria (Entradas e Saídas) - Data: ${formattedDateReport}</div>
                
                <div class="summary-boxes">
                    <div class="summary-box">
                        <div class="label">Total Agendado</div>
                        <div class="summary-val">${totalActive}</div>
                    </div>
                    <div class="summary-box" style="border-color: #16a34a; background-color: #f0fdf4;">
                        <div class="label" style="color: #16a34a;">Registraram Entrada</div>
                        <div class="summary-val" style="color: #16a34a;">${totalArrived}</div>
                    </div>
                    <div class="summary-box" style="border-color: #dc2626; background-color: #fef2f2;">
                        <div class="label" style="color: #dc2626;">Registraram Saída</div>
                        <div class="summary-val" style="color: #dc2626;">${totalExited}</div>
                    </div>
                    <div class="summary-box" style="border-color: #ea580c; background-color: #fff7ed;">
                        <div class="label" style="color: #ea580c;">Pendentes (Sem Entrada)</div>
                        <div class="summary-val" style="color: #ea580c;">${totalPending}</div>
                    </div>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th style="width: 7%;">Hora Agendada</th>
                            <th style="width: 22%;">Fornecedor / Empresa</th>
                            <th style="width: 12%;">CPF / CNPJ</th>
                            <th style="width: 8%;">Tipo</th>
                            <th style="width: 10%;">Horário Entrada</th>
                            <th style="width: 10%;">Horário Saída</th>
                            <th style="width: 8%;">Status</th>
                            <th style="width: 13%;">Itens / Peso</th>
                            <th style="width: 10%;">Observações</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsHtml || '<tr><td colspan="9" class="text-center italic font-bold">Nenhuma entrega agendada ou registrada para este dia.</td></tr>'}
                    </tbody>
                </table>
                
                <div class="signatures">
                    <div class="signature-box">
                        <div class="signature-line" style="margin-top: 30px;"></div>
                        <div class="signature-title">Responsável pela Portaria</div>
                        <div style="font-size: 7pt; color: #666; margin-top: 2px;">Assinatura e Carimbo</div>
                    </div>
                    <div class="signature-box">
                        <div class="signature-line" style="margin-top: 30px;"></div>
                        <div class="signature-title">Responsável pelo Almoxarifado / Estoque</div>
                        <div style="font-size: 7pt; color: #666; margin-top: 2px;">Assinatura e Carimbo</div>
                    </div>
                </div>

                <script>
                    window.onload = function() {
                        window.print();
                    }
                </script>
            </body>
            </html>
        `;

        printWindow.document.write(htmlContent);
        printWindow.document.close();
    };

    const formatDateBR = (dateStr: string) => {
        if (!dateStr) return '';
        const parts = dateStr.split('-');
        if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
        return dateStr;
    };

    const filteredMonthlyDeliveries = useMemo(() => {
        return monthlyDeliveries.filter(item => {
            // Search filter
            const matchesSearch = 
                (item.supplierName || '').toLowerCase().includes(monthlySearch.toLowerCase()) ||
                (item.supplierCpf || '').toLowerCase().includes(monthlySearch.toLowerCase());
                
            // Status filter
            let matchesStatus = true;
            if (monthlyStatusFilter === 'ARRIVED') {
                matchesStatus = !!item.arrivalTime;
            } else if (monthlyStatusFilter === 'EXITED') {
                matchesStatus = !!item.exitTime;
            } else if (monthlyStatusFilter === 'PENDING') {
                matchesStatus = !item.arrivalTime && item.status !== 'CANCELADO';
            } else if (monthlyStatusFilter === 'CANCELLED') {
                matchesStatus = item.status === 'CANCELADO';
            }
            
            // Type filter
            let matchesType = true;
            if (monthlyTypeFilter !== 'ALL') {
                matchesType = item.type === monthlyTypeFilter;
            }
            
            return matchesSearch && matchesStatus && matchesType;
        });
    }, [monthlyDeliveries, monthlySearch, monthlyStatusFilter, monthlyTypeFilter]);

    const handleGenerateMonthlyReportPrint = () => {
        const printWindow = window.open('', '_blank');
        if (!printWindow) {
            toast.error("Por favor, permita popups para imprimir o relatório.");
            return;
        }

        const monthParts = selectedMonth.split('-');
        const year = monthParts[0];
        const monthNum = parseInt(monthParts[1] || '1');
        const monthNamesBR = [
            "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
            "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
        ];
        const monthName = monthNamesBR[monthNum - 1] || 'Geral';
        const formattedMonthReport = `${monthName} de ${year}`;

        const totalActive = filteredMonthlyDeliveries.filter(d => d.status !== 'CANCELADO').length;
        const totalArrived = filteredMonthlyDeliveries.filter(d => d.arrivalTime && d.status !== 'CANCELADO').length;
        const totalExited = filteredMonthlyDeliveries.filter(d => d.exitTime && d.status !== 'CANCELADO').length;
        const totalPending = totalActive - totalArrived;

        const rowsHtml = filteredMonthlyDeliveries.map(item => {
            const itemsList = (item.items || []).map((it: any) => `${it.item || it.itemName || ''} (${it.kg}kg)`).join(', ');
            return `
                <tr>
                    <td class="text-center font-bold" style="font-size: 8px;">${formatDateBR(item.date)}</td>
                    <td class="text-center" style="font-size: 8px;">${item.time}</td>
                    <td style="font-size: 8px; font-weight: bold;">${item.supplierName.toUpperCase()}</td>
                    <td class="text-center font-mono" style="font-size: 8px;">${item.supplierCpf}</td>
                    <td class="text-center font-bold" style="font-size: 8px;">${item.type}</td>
                    <td class="text-center ${item.arrivalTime ? 'font-bold' : 'italic text-red'}" style="font-size: 8px;">${item.arrivalTime || 'Aguardando...'}</td>
                    <td class="text-center ${item.exitTime ? 'font-bold' : 'italic text-red'}" style="font-size: 8px;">${item.exitTime || 'Aguardando...'}</td>
                    <td class="text-center font-bold text-xs" style="font-size: 8px;">${item.status}</td>
                    <td style="font-size: 8px;">${itemsList || 'N/A'}</td>
                    <td style="font-size: 8px; font-style: italic;">${item.observations || ''}</td>
                </tr>
            `;
        }).join('');

        const htmlContent = `
            <html>
            <head>
                <title>Relatório Mensal de Portaria - ${formattedMonthReport}</title>
                <style>
                    @page { size: A4 landscape; margin: 10mm; }
                    body { font-family: Arial, sans-serif; font-size: 8.5pt; line-height: 1.3; color: #000; margin: 0; padding: 0; }
                    .header-title { text-align: center; font-weight: bold; font-size: 14pt; text-transform: uppercase; margin-bottom: 5px; }
                    .header-subtitle { text-align: center; font-weight: bold; font-size: 9pt; text-transform: uppercase; margin-bottom: 15px; border-bottom: 2px solid #000; padding-bottom: 5px; color: #333; }
                    
                    .summary-boxes { display: flex; gap: 10px; margin-bottom: 15px; }
                    .summary-box { flex: 1; border: 1.5px solid #000; padding: 8px; border-radius: 4px; text-align: center; }
                    .summary-val { font-size: 14pt; font-weight: bold; margin-top: 3px; }
                    .label { font-weight: bold; text-transform: uppercase; font-size: 7.5pt; color: #555; }
                    
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; text-transform: uppercase; }
                    th, td { border: 1px solid #000; padding: 5px; text-align: left; vertical-align: middle; }
                    th { font-weight: bold; text-transform: uppercase; background-color: #f2f2f2; text-align: center; font-size: 8pt; }
                    
                    .text-center { text-align: center; }
                    .text-right { text-align: right; }
                    .font-bold { font-weight: bold; }
                    .text-red { color: #b91c1c; font-style: italic; font-weight: normal; }
                    
                    .signatures { display: flex; justify-content: space-between; margin-top: 50px; padding: 0 50px; page-break-inside: avoid; }
                    .signature-box { text-align: center; width: 250px; }
                    .signature-line { border-top: 1px solid #000; margin-bottom: 5px; }
                    .signature-title { font-weight: bold; text-transform: uppercase; font-size: 7.5pt; }
                </style>
            </head>
            <body>
                <div style="text-align: center; margin-bottom: 8px;">
                    <img src="${POLICIA_PENAL_BADGE_B64}" style="height: 50px; width: auto; margin: 0 auto; display: block;" alt="Polícia Penal" />
                </div>
                <div class="header-title">PENITENCIÁRIA DE TAÍUVA</div>
                <div class="header-subtitle">Relatório Mensal de Controle de Portaria (Entradas e Saídas) - Mês: ${formattedMonthReport}</div>
                
                <div class="summary-boxes">
                    <div class="summary-box">
                        <div class="label">Total Mensal Agendado</div>
                        <div class="summary-val">${totalActive}</div>
                    </div>
                    <div class="summary-box" style="border-color: #16a34a; background-color: #f0fdf4;">
                        <div class="label" style="color: #16a34a;">Registraram Entrada</div>
                        <div class="summary-val" style="color: #16a34a;">${totalArrived}</div>
                    </div>
                    <div class="summary-box" style="border-color: #dc2626; background-color: #fef2f2;">
                        <div class="label" style="color: #dc2626;">Registraram Saída</div>
                        <div class="summary-val" style="color: #dc2626;">${totalExited}</div>
                    </div>
                    <div class="summary-box" style="border-color: #ea580c; background-color: #fff7ed;">
                        <div class="label" style="color: #ea580c;">Pendentes (Sem Entrada)</div>
                        <div class="summary-val" style="color: #ea580c;">${totalPending}</div>
                    </div>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th style="width: 8%;">Data</th>
                            <th style="width: 7%;">Hora</th>
                            <th style="width: 22%;">Fornecedor / Empresa</th>
                            <th style="width: 12%;">CPF / CNPJ</th>
                            <th style="width: 8%;">Tipo</th>
                            <th style="width: 10%;">Horário Entrada</th>
                            <th style="width: 10%;">Horário Saída</th>
                            <th style="width: 8%;">Status</th>
                            <th style="width: 15%;">Itens / Peso</th>
                            <th style="width: 10%;">Observações</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsHtml || '<tr><td colspan="10" class="text-center italic font-bold">Nenhuma entrega agendada ou registrada para este período.</td></tr>'}
                    </tbody>
                </table>
                
                <div class="signatures">
                    <div class="signature-box">
                        <div class="signature-line" style="margin-top: 30px;"></div>
                        <div class="signature-title">Responsável pela Portaria</div>
                        <div style="font-size: 7pt; color: #666; margin-top: 2px;">Assinatura e Carimbo</div>
                    </div>
                    <div class="signature-box">
                        <div class="signature-line" style="margin-top: 30px;"></div>
                        <div class="signature-title">Responsável pelo Almoxarifado / Estoque</div>
                        <div style="font-size: 7pt; color: #666; margin-top: 2px;">Assinatura e Carimbo</div>
                    </div>
                </div>

                <script>
                    window.onload = function() {
                        window.print();
                    }
                </script>
            </body>
            </html>
        `;

        printWindow.document.write(htmlContent);
        printWindow.document.close();
    };

    const handleSaveInvoiceWithItems = async (invoiceNumber: string, invoiceUrl: string, deliveries: Delivery[], invoiceDate?: string) => {
        if (!onSaveInvoice || !invoiceInfo) return;
        try {
            // We use the deliveries passed back from the modal, which may have updated weights/values
            await onSaveInvoice(invoiceInfo.supplierCpf, selectedItem.allIds, invoiceNumber, invoiceUrl, deliveries, invoiceDate);
            toast.success("Nota fiscal cadastrada com sucesso!");
            setIsInvoiceModalOpen(false);
        } catch (_e) {
            toast.error("Erro ao salvar nota fiscal.");
        }
    };

    const handleThirdPartyArrival = async (item: any) => {
        setSelectedItem(item);
        setArrivalData({ 
            arrivalTime: item.arrivalTime || new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }), 
            invoiceNumber: '' 
        });
        setIsArrivalModalOpen(true);
    };

    const handleThirdPartyExit = async (item: any) => {
        setSelectedItem(item);
        setExitTimeInput(item.exitTime || new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }));
        setIsExitModalOpen(true);
    };

    const currentSupplierItems = useMemo<ContractItem[]>(() => {
        if (!invoiceInfo) return [];
        const mainSup = ensureArray(suppliers).find(s => s.cpf === invoiceInfo.supplierCpf);
        if (mainSup) return ensureArray(mainSup.contractItems);
        
        if (perCapitaConfig) {
            const allPC = [
                ...ensureArray(perCapitaConfig.ppaisProducers),
                ...ensureArray(perCapitaConfig.pereciveisSuppliers),
                ...ensureArray(perCapitaConfig.estocaveisSuppliers)
            ];
            const pcSup = allPC.find((p: any) => (p.cpfCnpj || p.cpf) === invoiceInfo.supplierCpf);
            if (pcSup) return ensureArray((pcSup as any).contractItems);
        }
        return [];
    }, [invoiceInfo, suppliers, perCapitaConfig]);

    return (
        <>
            {isInvoiceModalOpen && invoiceInfo && (
                <SendInvoiceModal
                    invoiceInfo={invoiceInfo}
                    contractItems={currentSupplierItems}
                    onClose={() => setIsInvoiceModalOpen(false)}
                    onSave={handleSaveInvoiceWithItems}
                />
            )}
            {/* Scanner Modal */}
            {isScannerOpen && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
                    <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 animate-scale-in">
                        <div className={`p-6 md:p-8 border-b flex justify-between items-center ${scanAction === 'entrada' ? 'bg-emerald-50 border-b-emerald-100' : 'bg-rose-50 border-b-rose-100'}`}>
                            <div>
                                <h3 className={`text-xl font-black uppercase italic tracking-tighter ${scanAction === 'entrada' ? 'text-emerald-950' : 'text-rose-950'}`}>
                                    Leitor Portaria ({scanAction === 'entrada' ? 'Entrada' : 'Saída'})
                                </h3>
                                <p className={`font-bold text-[10px] uppercase tracking-widest ${scanAction === 'entrada' ? 'text-emerald-600' : 'text-rose-600'}`}>
                                    Escanear ou Digitar para registrar {scanAction === 'entrada' ? 'Entrada (Check-In)' : 'Saída (Check-Out)'}
                                </p>
                            </div>
                            <button 
                                onClick={() => setIsScannerOpen(false)} 
                                className="text-gray-400 hover:text-gray-800 text-3xl font-light leading-none"
                            >
                                &times;
                            </button>
                        </div>
                        <div className="p-6 md:p-8 space-y-6">
                            {/* Mode Toggle */}
                            <div className="flex gap-1 bg-slate-100 p-1 rounded-2xl">
                                <button
                                    type="button"
                                    onClick={() => setScannerMode('camera')}
                                    className={`flex-1 py-3 rounded-xl font-black uppercase text-[10px] tracking-widest transition-all ${
                                        scannerMode === 'camera' 
                                            ? `bg-white ${scanAction === 'entrada' ? 'text-emerald-600' : 'text-rose-600'} shadow-sm` 
                                            : 'text-slate-500 hover:text-slate-700'
                                    }`}
                                >
                                    Câmera Integrada
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setScannerMode('manual')}
                                    className={`flex-1 py-3 rounded-xl font-black uppercase text-[10px] tracking-widest transition-all ${
                                        scannerMode === 'manual' 
                                            ? `bg-white ${scanAction === 'entrada' ? 'text-emerald-600' : 'text-rose-600'} shadow-sm` 
                                            : 'text-slate-500 hover:text-slate-700'
                                    }`}
                                >
                                    Leitor de Mão / Código
                                </button>
                            </div>

                            {scannerMode === 'camera' ? (
                                <div className="space-y-4">
                                    <div className="bg-slate-50 p-2 rounded-3xl border-2 border-dashed border-slate-200 overflow-hidden relative">
                                        <div id="qr-reader" className="w-full max-w-md mx-auto rounded-2xl overflow-hidden shadow-inner bg-slate-950 min-h-[280px] flex flex-col items-center justify-center p-6 text-center text-slate-400">
                                             <div className={`w-8 h-8 border-4 ${scanAction === 'entrada' ? 'border-emerald-500' : 'border-rose-500'} border-t-transparent rounded-full animate-spin mb-4`}></div>
                                             <span className="text-xs font-black uppercase tracking-widest text-slate-300">Ativando Câmera...</span>
                                             <span className="text-[10px] text-slate-500 mt-1">Por favor, conceda permissão de câmera ao navegador</span>
                                         </div>
                                    </div>
                                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider text-center max-w-sm mx-auto leading-relaxed">
                                        Posicione o QR Code impresso ou na tela do celular em frente à câmera para leitura.
                                    </p>
                                </div>
                            ) : (
                                <form onSubmit={handleManualSubmit} className="space-y-4">
                                    {pendingItems.length > 0 && (
                                        <div>
                                            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">
                                                Ou escolha da Agenda de Hoje
                                            </label>
                                            <select
                                                onChange={(e) => {
                                                    const val = e.target.value;
                                                    if (val) {
                                                        setManualInputValue(val);
                                                    }
                                                }}
                                                className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-bold text-gray-700 outline-none focus:ring-4 focus:ring-indigo-100 transition-all text-xs"
                                                value={manualInputValue}
                                            >
                                                <option value="">-- Selecione um agendamento pendente --</option>
                                                {pendingItems.map((item) => (
                                                    <option key={item.id} value={item.supplierCpf}>
                                                        {item.time} - {item.supplierName.toUpperCase()} ({item.type === 'TERCEIRO' ? 'Terceiro' : 'Fornecedor'})
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                    )}
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">
                                            Leitor de Código ou CPF
                                        </label>
                                        <input
                                            ref={manualInputRef}
                                            type="text"
                                            value={manualInputValue}
                                            onChange={(e) => setManualInputValue(e.target.value)}
                                            placeholder="Escaneie com leitor de mão ou digite o CPF..."
                                            className={`w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-bold text-gray-700 outline-none focus:ring-4 ${scanAction === 'entrada' ? 'focus:ring-emerald-100' : 'focus:ring-rose-100'} transition-all placeholder:text-gray-300`}
                                            autoFocus
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">
                                            Horário (Opcional - Retroativo)
                                        </label>
                                        <input
                                            type="time"
                                            value={manualTimeValue}
                                            onChange={(e) => setManualTimeValue(e.target.value)}
                                            className={`w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-bold text-gray-700 outline-none focus:ring-4 ${scanAction === 'entrada' ? 'focus:ring-emerald-100' : 'focus:ring-rose-100'} transition-all placeholder:text-gray-300`}
                                        />
                                    </div>
                                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider text-center max-w-sm mx-auto leading-relaxed">
                                        Aponte o leitor de mão para o QR Code para preencher e validar a {scanAction === 'entrada' ? 'entrada' : 'saída'} automaticamente.
                                    </p>
                                    <div className="flex gap-4 pt-2">
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setManualInputValue('');
                                                setManualTimeValue('');
                                            }}
                                            className="flex-1 py-4 rounded-2xl bg-gray-100 text-gray-500 font-black text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all"
                                        >
                                            Limpar
                                        </button>
                                        <button
                                            type="submit"
                                            disabled={isSubmitting}
                                            className={`flex-1 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest text-white transition-all shadow-xl ${
                                                isSubmitting ? 'bg-gray-400 cursor-not-allowed shadow-none' :
                                                scanAction === 'entrada' 
                                                    ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-100' 
                                                    : 'bg-rose-600 hover:bg-rose-700 shadow-rose-100'
                                            }`}
                                        >
                                            {isSubmitting ? 'Salvando...' : `Confirmar ${scanAction === 'entrada' ? 'Entrada' : 'Saída'}`}
                                        </button>
                                    </div>
                                </form>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Unified Portaria Modal */}
            {(isArrivalModalOpen || isExitModalOpen) && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
                    <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden border border-indigo-100 animate-scale-in">
                        <div className="p-8 border-b bg-indigo-50">
                            <h3 className="text-xl font-black text-indigo-950 uppercase italic tracking-tighter">Dados da Portaria</h3>
                            <p className="text-indigo-600 font-bold text-[10px] uppercase tracking-widest">{selectedItem?.supplierName}</p>
                            <p className="text-gray-400 font-bold text-[9px] uppercase tracking-widest">Agendamento: {selectedItem?.time}</p>
                        </div>
                        <div className="p-8 space-y-6">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Horário de Chegada</label>
                                    <input 
                                        type="time" 
                                        value={arrivalData.arrivalTime}
                                        onChange={e => setArrivalData(prev => ({ ...prev, arrivalTime: e.target.value }))}
                                        className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-black text-indigo-900 outline-none focus:ring-4 focus:ring-indigo-100 transition-all text-xl text-center"
                                    />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Horário de Saída</label>
                                    <input 
                                        type="time" 
                                        value={exitTimeInput}
                                        onChange={e => setExitTimeInput(e.target.value)}
                                        className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-black text-rose-900 outline-none focus:ring-4 focus:ring-rose-100 transition-all text-xl text-center"
                                    />
                                </div>
                            </div>
                            
                            {selectedItem?.type === 'FORNECEDOR' && (
                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Número da NF (Opcional)</label>
                                    <input 
                                        type="text" 
                                        placeholder="Ex: 000123"
                                        value={arrivalData.invoiceNumber}
                                        onChange={e => setArrivalData(prev => ({ ...prev, invoiceNumber: e.target.value }))}
                                        className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-bold text-gray-600 outline-none focus:ring-4 focus:ring-indigo-100 transition-all"
                                    />
                                </div>
                            )}

                            <div className="flex gap-4">
                                <button 
                                    onClick={() => {
                                        setIsArrivalModalOpen(false);
                                        setIsExitModalOpen(false);
                                    }} 
                                    className="flex-1 py-4 rounded-2xl bg-gray-100 text-gray-500 font-black text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all"
                                >
                                    Cancelar
                                </button>
                                <button 
                                    onClick={savePortaria} 
                                    disabled={isSubmitting}
                                    className="flex-1 py-4 rounded-2xl bg-indigo-600 text-white font-black text-[10px] uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 disabled:bg-gray-400 disabled:cursor-not-allowed"
                                >
                                    {isSubmitting ? 'Salvando...' : 'Salvar Dados'}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Monthly Report Modal */}
            {isMonthlyReportOpen && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[100] flex items-center justify-center p-4">
                    <div className="bg-slate-50 rounded-[2.5rem] shadow-2xl w-full max-w-5xl overflow-hidden border border-slate-200 animate-scale-in flex flex-col max-h-[90vh]">
                        
                        {/* Header */}
                        <div className="p-6 md:p-8 border-b bg-indigo-950 text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                            <div>
                                <div className="flex items-center gap-3">
                                    <Calendar className="h-6 w-6 text-indigo-400" />
                                    <h3 className="text-xl font-black uppercase italic tracking-tighter">
                                        Relatório Mensal de Portaria
                                    </h3>
                                </div>
                                <p className="text-indigo-200 font-bold text-[10px] uppercase tracking-widest mt-1">
                                    Controle Consolidado de Entradas e Saídas por Mês
                                </p>
                            </div>
                            
                            <div className="flex items-center gap-3 w-full md:w-auto">
                                <label className="text-xs font-black uppercase tracking-wider text-indigo-300">Selecione o Mês:</label>
                                <input 
                                    type="month" 
                                    value={selectedMonth} 
                                    onChange={e => setSelectedMonth(e.target.value)}
                                    className="p-3 bg-indigo-900 border border-indigo-800 rounded-xl outline-none focus:ring-4 focus:ring-indigo-500 font-black text-white text-sm"
                                />
                                <button 
                                    onClick={() => setIsMonthlyReportOpen(false)} 
                                    className="text-indigo-300 hover:text-white text-3xl font-light leading-none ml-auto"
                                >
                                    &times;
                                </button>
                            </div>
                        </div>

                        {/* Search & Filters */}
                        <div className="bg-white p-6 border-b border-slate-100 flex flex-col md:flex-row justify-between gap-4 items-center">
                            <div className="relative w-full md:w-72">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                                <input 
                                    type="text" 
                                    placeholder="Pesquisar fornecedor ou CPF/CNPJ..."
                                    value={monthlySearch}
                                    onChange={e => setMonthlySearch(e.target.value)}
                                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-indigo-100 font-bold text-xs transition-all"
                                />
                            </div>

                            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                                <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
                                    <button
                                        onClick={() => setMonthlyStatusFilter('ALL')}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${monthlyStatusFilter === 'ALL' ? 'bg-white text-indigo-950 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                                    >
                                        Todos
                                    </button>
                                    <button
                                        onClick={() => setMonthlyStatusFilter('ARRIVED')}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${monthlyStatusFilter === 'ARRIVED' ? 'bg-emerald-500 text-white shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                                    >
                                        Entradas
                                    </button>
                                    <button
                                        onClick={() => setMonthlyStatusFilter('EXITED')}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${monthlyStatusFilter === 'EXITED' ? 'bg-rose-500 text-white shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                                    >
                                        Saídas
                                    </button>
                                    <button
                                        onClick={() => setMonthlyStatusFilter('PENDING')}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${monthlyStatusFilter === 'PENDING' ? 'bg-amber-500 text-white shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                                    >
                                        Pendentes
                                    </button>
                                    <button
                                        onClick={() => setMonthlyStatusFilter('CANCELLED')}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${monthlyStatusFilter === 'CANCELLED' ? 'bg-slate-500 text-white shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                                    >
                                        Cancelados
                                    </button>
                                </div>

                                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                                    <button
                                        onClick={() => setMonthlyTypeFilter('ALL')}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${monthlyTypeFilter === 'ALL' ? 'bg-white text-indigo-950 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                                    >
                                        Tipos: Todos
                                    </button>
                                    <button
                                        onClick={() => setMonthlyTypeFilter('FORNECEDOR')}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${monthlyTypeFilter === 'FORNECEDOR' ? 'bg-white text-indigo-950 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                                    >
                                        Fornecedor
                                    </button>
                                    <button
                                        onClick={() => setMonthlyTypeFilter('TERCEIRO')}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${monthlyTypeFilter === 'TERCEIRO' ? 'bg-white text-indigo-950 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                                    >
                                        Terceiro
                                    </button>
                                </div>

                                <button
                                    onClick={handleGenerateMonthlyReportPrint}
                                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-black py-2.5 px-4 rounded-xl text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-md transition-all cursor-pointer font-sans"
                                >
                                    <FileText className="h-3.5 w-3.5" />
                                    Imprimir / PDF
                                </button>
                            </div>
                        </div>

                        {/* Content Area - Scrollable */}
                        <div className="p-6 md:p-8 space-y-6 overflow-y-auto flex-1 text-slate-800">
                            {/* Consolidated Stats */}
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-4">
                                    <div className="bg-indigo-50 p-2.5 rounded-xl text-indigo-900">
                                        <Truck className="h-5 w-5" />
                                    </div>
                                    <div>
                                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-wider">Agendamentos no Mês</p>
                                        <p className="text-lg font-black text-slate-800">{filteredMonthlyDeliveries.filter(d => d.status !== 'CANCELADO').length}</p>
                                    </div>
                                </div>

                                <div className="bg-emerald-50/50 p-5 rounded-2xl border border-emerald-100/50 shadow-xs flex items-center gap-4">
                                    <div className="bg-emerald-500 text-white p-2.5 rounded-xl">
                                        <UserCheck className="h-5 w-5" />
                                    </div>
                                    <div>
                                        <p className="text-[9px] font-black text-emerald-800 uppercase tracking-wider">Entradas Registradas</p>
                                        <p className="text-lg font-black text-emerald-950">{filteredMonthlyDeliveries.filter(d => d.arrivalTime && d.status !== 'CANCELADO').length}</p>
                                    </div>
                                </div>

                                <div className="bg-rose-50/50 p-5 rounded-2xl border border-rose-100/50 shadow-xs flex items-center gap-4">
                                    <div className="bg-rose-500 text-white p-2.5 rounded-xl">
                                        <UserCheck className="h-5 w-5" />
                                    </div>
                                    <div>
                                        <p className="text-[9px] font-black text-rose-800 uppercase tracking-wider font-sans">Saídas Registradas</p>
                                        <p className="text-lg font-black text-rose-950">{filteredMonthlyDeliveries.filter(d => d.exitTime && d.status !== 'CANCELADO').length}</p>
                                    </div>
                                </div>

                                <div className="bg-amber-50/50 p-5 rounded-2xl border border-amber-100/50 shadow-xs flex items-center gap-4">
                                    <div className="bg-amber-500 text-white p-2.5 rounded-xl">
                                        <AlertCircle className="h-5 w-5" />
                                    </div>
                                    <div>
                                        <p className="text-[9px] font-black text-amber-800 uppercase tracking-wider font-sans">Pendentes de Chegada</p>
                                        <p className="text-lg font-black text-amber-950">{filteredMonthlyDeliveries.filter(d => !d.arrivalTime && d.status !== 'CANCELADO').length}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Monthly Table */}
                            <div className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-xs">
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left border-collapse">
                                        <thead>
                                            <tr className="bg-slate-50/80 text-slate-500 text-[10px] font-bold uppercase border-b border-slate-100">
                                                <th className="p-4 text-center">Data</th>
                                                <th className="p-4 text-center">Hora</th>
                                                <th className="p-4">Fornecedor / Empresa</th>
                                                <th className="p-4 text-center">CPF / CNPJ</th>
                                                <th className="p-4 text-center">Tipo</th>
                                                <th className="p-4 text-center">Entrada</th>
                                                <th className="p-4 text-center">Saída</th>
                                                <th className="p-4 text-center">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-100 text-xs">
                                            {filteredMonthlyDeliveries.length > 0 ? (
                                                filteredMonthlyDeliveries.map((item, idx) => {
                                                    const isCompleted = item.status === 'CONCLUÍDO';
                                                    const isCancelled = item.status === 'CANCELADO';
                                                    
                                                    return (
                                                        <tr key={`${item.id}-${idx}`} className={`hover:bg-slate-50/30 ${isCancelled ? 'bg-red-50/20 text-slate-400' : ''}`}>
                                                            <td className="p-4 text-center font-bold text-slate-600">
                                                                {formatDateBR(item.date)}
                                                            </td>
                                                            <td className="p-4 text-center text-slate-500 font-medium">
                                                                {item.time}
                                                            </td>
                                                            <td className="p-4 font-black text-slate-800 uppercase">
                                                                {item.supplierName}
                                                            </td>
                                                            <td className="p-4 text-center font-mono text-slate-500">
                                                                {item.supplierCpf}
                                                            </td>
                                                            <td className="p-4 text-center">
                                                                <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                                                    item.type === 'TERCEIRO' 
                                                                        ? 'bg-amber-50 text-amber-700 border border-amber-200' 
                                                                        : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                                                                }`}>
                                                                    {item.type}
                                                                </span>
                                                            </td>
                                                            <td className="p-4 text-center">
                                                                {item.arrivalTime ? (
                                                                    <span className="text-emerald-600 font-bold bg-emerald-50 px-2.5 py-1 rounded-lg">
                                                                        {item.arrivalTime}
                                                                    </span>
                                                                ) : (
                                                                    <span className="text-rose-500 italic font-medium">
                                                                        Aguardando
                                                                    </span>
                                                                )}
                                                            </td>
                                                            <td className="p-4 text-center">
                                                                {item.exitTime ? (
                                                                    <span className="text-rose-600 font-bold bg-rose-50 px-2.5 py-1 rounded-lg">
                                                                        {item.exitTime}
                                                                    </span>
                                                                ) : (
                                                                    <span className="text-slate-400 italic font-medium">
                                                                        -
                                                                    </span>
                                                                )}
                                                            </td>
                                                            <td className="p-4 text-center">
                                                                <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                                                                    isCompleted 
                                                                        ? 'bg-indigo-950 text-white' 
                                                                        : isCancelled 
                                                                            ? 'bg-rose-100 text-rose-800' 
                                                                            : item.arrivalTime 
                                                                                ? 'bg-emerald-100 text-emerald-800' 
                                                                                : 'bg-amber-100 text-amber-800'
                                                                }`}>
                                                                    {item.status}
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    );
                                                })
                                            ) : (
                                                <tr>
                                                    <td colSpan={8} className="p-12 text-center text-slate-400 italic">
                                                        Nenhum registro encontrado para os filtros selecionados.
                                                    </td>
                                                </tr>
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="p-6 bg-white border-t border-slate-100 flex justify-end gap-3">
                            <button 
                                onClick={() => setIsMonthlyReportOpen(false)} 
                                className="px-6 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-black text-xs uppercase tracking-wider transition-all"
                            >
                                Fechar Relatório
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <div className={`space-y-6 animate-fade-in ${embedded ? '' : 'p-4 md:p-8 max-w-6xl mx-auto'}`}>
                {/* Header / Selector */}
                <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-gray-100">
                <div className="flex flex-col md:flex-row justify-between items-center gap-6">
                    <div>
                        <h2 className="text-2xl font-black text-indigo-950 uppercase tracking-tighter italic">Agenda de Chegadas</h2>
                        <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest">Visualização de Entregas Programadas</p>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 w-full md:w-auto">
                        <div className="relative flex-1 md:w-64">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <input 
                                type="text" 
                                placeholder="Pesquisar fornecedor..."
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-100 font-bold text-sm transition-all"
                            />
                        </div>
                        <div className="bg-indigo-50 px-4 py-2 rounded-2xl border border-indigo-100">
                            <span className="text-xs font-black text-indigo-600 uppercase">{dailyDeliveries.length} Veículos</span>
                        </div>
                        <input 
                            type="date" 
                            value={selectedAgendaDate} 
                            onChange={e => setSelectedAgendaDate(e.target.value)}
                            className="p-3 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-100 font-black text-indigo-900 transition-all text-sm"
                        />
                        <button
                            type="button"
                            onClick={() => {
                                setScanAction('entrada');
                                setScannerMode('camera');
                                setIsScannerOpen(true);
                            }}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3 px-4 rounded-2xl text-xs uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-emerald-100 transition-all active:scale-95 cursor-pointer"
                        >
                            <QrCode className="h-4 w-4" />
                            Escanear Entrada
                        </button>
                        <button
                            type="button"
                            onClick={() => {
                                setScanAction('saida');
                                setScannerMode('camera');
                                setIsScannerOpen(true);
                            }}
                            className="bg-rose-600 hover:bg-rose-700 text-white font-black py-3 px-4 rounded-2xl text-xs uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-rose-100 transition-all active:scale-95 cursor-pointer"
                        >
                            <QrCode className="h-4 w-4" />
                            Escanear Saída
                        </button>
                        <button
                            type="button"
                            onClick={handleGenerateReport}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white font-black py-3 px-4 rounded-2xl text-xs uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-indigo-100 transition-all active:scale-95 cursor-pointer"
                        >
                            <FileText className="h-4 w-4" />
                            Relatório Portaria
                        </button>
                        <button
                            type="button"
                            onClick={() => setIsMonthlyReportOpen(true)}
                            className="bg-slate-800 hover:bg-black text-white font-black py-3 px-4 rounded-2xl text-xs uppercase tracking-widest flex items-center gap-2 shadow-lg hover:shadow-slate-200 transition-all active:scale-95 cursor-pointer"
                        >
                            <Calendar className="h-4 w-4" />
                            Relatório Mensal
                        </button>
                    </div>
                </div>
            </div>

            {/* Daily Summary Info */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white p-6 rounded-3xl shadow-md border border-indigo-50 flex items-center gap-4">
                    <div className="bg-indigo-100 p-3 rounded-2xl text-indigo-600">
                        <Truck className="h-6 w-6" />
                    </div>
                    <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Ativo</p>
                        <p className="text-xl font-black text-indigo-900">{dailyDeliveries.filter(d => d.status !== 'CANCELADO').length}</p>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-3xl shadow-md border border-green-50 flex items-center gap-4">
                    <div className="bg-green-100 p-3 rounded-2xl text-green-600">
                        <UserCheck className="h-6 w-6" />
                    </div>
                    <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest font-sans">Entradas Confirmadas</p>
                        <p className="text-xl font-black text-green-700">{dailyDeliveries.filter(d => d.arrivalTime && d.status !== 'CANCELADO').length}</p>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-3xl shadow-md border border-rose-50 flex items-center gap-4">
                    <div className="bg-rose-100 p-3 rounded-2xl text-rose-600">
                        <UserCheck className="h-6 w-6" />
                    </div>
                    <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Saídas Confirmadas</p>
                        <p className="text-xl font-black text-rose-700">{dailyDeliveries.filter(d => d.exitTime && d.status !== 'CANCELADO').length}</p>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-3xl shadow-md border border-red-50 flex items-center gap-4">
                    <div className="bg-red-100 p-3 rounded-2xl text-red-600">
                        <AlertCircle className="h-6 w-6" />
                    </div>
                    <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest font-sans">Pendentes Chegada</p>
                        <p className="text-xl font-black text-red-700">{dailyDeliveries.filter(d => !d.arrivalTime && d.status !== 'CANCELADO').length}</p>
                    </div>
                </div>
            </div>

            {/* List of Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {dailyDeliveries.length > 0 ? dailyDeliveries.map(item => (
                    <div 
                        key={item.id} 
                        className={`relative overflow-hidden bg-white rounded-[2rem] shadow-md border-2 transition-all ${
                            item.status === 'CONCLUÍDO' 
                                ? 'border-indigo-100 opacity-80' 
                                : item.status === 'CANCELADO'
                                    ? 'border-red-100 opacity-50 grayscale'
                                    : item.status === 'AGENDADO' && !item.arrivalTime
                                        ? 'border-red-500 bg-red-50'
                                        : item.status === 'AGENDADO' && item.arrivalTime
                                            ? 'border-orange-500 bg-orange-50/30'
                                            : 'border-green-200 bg-green-50/30' 
                        }`}
                    >
                        <div className={`absolute top-0 left-0 w-2 h-full ${
                            item.status === 'CONCLUÍDO' ? 'bg-indigo-900' : 
                            item.status === 'CANCELADO' ? 'bg-gray-400' :
                            item.arrivalTime ? 'bg-green-500' : 'bg-red-600'
                        }`} />

                        <div className="p-5 pl-7">
                            <div className="flex justify-between items-start mb-4">
                                <div className={`px-4 py-2 rounded-xl text-lg font-black font-mono shadow-sm ${
                                    item.status === 'CONCLUÍDO' 
                                        ? 'bg-indigo-900 text-white' 
                                        : item.status === 'CANCELADO'
                                            ? 'bg-gray-400 text-white'
                                            : item.arrivalTime 
                                                ? 'bg-green-600 text-white' 
                                                : 'bg-red-600 text-white shadow-red-100'
                                }`}>
                                    {item.time}
                                </div>
                                
                                <div className="flex items-center gap-2">
                                    <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${
                                        item.status === 'CONCLUÍDO' ? 'bg-indigo-100 text-indigo-700' : 
                                        item.status === 'CANCELADO' ? 'bg-red-100 text-red-700' :
                                        item.status === 'TERCEIRO' ? 'bg-amber-100 text-amber-700' : 
                                        item.status === 'AGENDADO' && item.arrivalTime ? 'bg-green-100 text-green-700' :
                                        'bg-gray-100 text-gray-600'
                                    }`}>
                                        {item.status}
                                    </span>
                                    {item.type === 'FORNECEDOR' && (
                                        <button 
                                            onClick={() => handleDelete(item)}
                                            className="p-1.5 text-red-500 hover:bg-red-100 rounded-lg transition-all"
                                            title="Excluir Agendamento"
                                        >
                                            <Trash2 className="h-4 w-4" />
                                        </button>
                                    )}
                                </div>
                            </div>

                            <div>
                                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter leading-tight line-clamp-1">
                                    {item.supplierName}
                                </h3>
                                <p className="text-[10px] font-mono text-slate-400 mt-1">{item.supplierCpf}</p>
                                {item.observations && (
                                    <div className="mt-2 p-2.5 bg-amber-50 border border-amber-200/50 rounded-xl text-[10px] text-amber-950 font-medium">
                                        <span className="font-black uppercase text-[8px] text-amber-800 tracking-wider block mb-0.5">Observações da Carga / Preparação:</span>
                                        {item.observations}
                                    </div>
                                )}
                            </div>

                                <div className="mt-4 pt-4 border-t border-dashed border-slate-100 flex justify-between items-center">
                                <div className="flex flex-wrap items-center gap-4">
                                    <div className="flex items-center gap-2">
                                        <Clock className="h-3 w-3 text-slate-300" />
                                        <span className="text-[10px] font-black text-slate-400 uppercase">
                                            {item.type === 'TERCEIRO' ? 'Entrada:' : 'Chegada:'}
                                        </span>
                                        <span onClick={() => item.type === 'FORNECEDOR' ? handleRegisterArrival(item) : handleThirdPartyArrival(item)} className={`cursor-pointer hover:underline text-[11px] font-black ${item.arrivalTime ? 'text-green-600' : 'text-red-600 italic'}`}>
                                            {item.arrivalTime || 'Aguardando...'}
                                        </span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Clock className="h-3 w-3 text-slate-300" />
                                        <span className="text-[10px] font-black text-slate-400 uppercase">Saída:</span>
                                        <span onClick={() => item.type === 'FORNECEDOR' ? handleRegisterExit(item) : handleThirdPartyExit(item)} className={`cursor-pointer hover:underline text-[11px] font-black ${item.exitTime ? 'text-rose-600' : 'text-red-600 italic'}`}>
                                            {item.exitTime || 'Aguardando...'}
                                        </span>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    {item.type === 'TERCEIRO' && onUpdateThirdPartyEntry && (
                                        <>
                                            {!item.arrivalTime ? (
                                                <button 
                                                    onClick={() => handleThirdPartyArrival(item)}
                                                    className="bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all flex items-center gap-1.5 shadow-md shadow-indigo-100"
                                                >
                                                    <CheckCircle2 className="h-3 w-3" />
                                                    Confirmar Entrada
                                                </button>
                                            ) : !item.exitTime ? (
                                                <button 
                                                    onClick={() => handleThirdPartyExit(item)}
                                                    className="bg-rose-600 text-white px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all flex items-center gap-1.5 shadow-md shadow-rose-100"
                                                >
                                                    <CheckCircle2 className="h-3 w-3" />
                                                    Confirmar Saída
                                                </button>
                                            ) : (
                                                <div className="bg-slate-100 text-slate-500 p-1.5 rounded-lg flex items-center gap-1 text-[9px] font-black uppercase">
                                                    <UserCheck className="h-4 w-4" />
                                                    Concluído
                                                </div>
                                            )}
                                        </>
                                    )}
                                    {item.type === 'FORNECEDOR' && (
                                        <div className="flex gap-1.5">
                                            {!item.arrivalTime ? (
                                                <button 
                                                    onClick={() => handleRegisterArrival(item)}
                                                    className="bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all flex items-center gap-1.5 shadow-md shadow-indigo-100"
                                                >
                                                    <CheckCircle2 className="h-3 w-3" />
                                                    Confirmar Chegada
                                                </button>
                                            ) : !item.exitTime ? (
                                                <button 
                                                    onClick={() => handleRegisterExit(item)}
                                                    className="bg-rose-600 text-white px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all flex items-center gap-1.5 shadow-md shadow-rose-100"
                                                >
                                                    <CheckCircle2 className="h-3 w-3" />
                                                    Confirmar Saída
                                                </button>
                                            ) : (
                                                <button 
                                                    onClick={() => {
                                                        handleRegisterArrival(item);
                                                    }}
                                                    className="bg-slate-100 text-slate-500 hover:bg-slate-200 px-3 py-1.5 rounded-lg flex items-center gap-1.5 text-[9px] font-black uppercase"
                                                >
                                                    <UserCheck className="h-3.5 w-3.5 text-emerald-500" />
                                                    Registrado
                                                </button>
                                            )}
                                        </div>
                                    )}
                                    {item.type === 'FORNECEDOR' && item.arrivalTime && (
                                        <button 
                                            onClick={() => handleOpenInvoiceModal(item)}
                                            className={`${item.status === 'CONCLUÍDO' ? 'bg-indigo-600' : 'bg-emerald-600'} text-white px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest hover:brightness-110 transition-all flex items-center gap-1.5 shadow-md`}
                                            title={item.status === 'CONCLUÍDO' ? "Ver/Editar Nota Fiscal" : "Cadastrar Nota Fiscal"}
                                        >
                                            <FilePlus className="h-3 w-3" />
                                            {item.status === 'CONCLUÍDO' ? 'Ver Nota' : 'Faturar'}
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                )) : (
                    <div className="col-span-full py-20 bg-white rounded-[3rem] shadow-xl border-4 border-dashed border-gray-100 flex flex-col items-center justify-center gap-4">
                        <Calendar className="h-16 w-16 text-gray-200" />
                        <p className="text-xl font-black text-gray-300 uppercase tracking-[0.3em] italic">Nenhuma entrega agendada para este dia</p>
                    </div>
                )}
            </div>
        </div>
        </>
    );
};

export default AgendaChegadas;
