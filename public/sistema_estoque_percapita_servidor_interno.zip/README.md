# Sistema de Estoque / Almoxarifado, Ordens de Saída e Per Capita - Servidor Linux Fechado

Pacote de execução autônoma para servidores e computadores Linux (Ubuntu, Debian, Rocky, RHEL, CentOS) operando em rede fechada (100% offline).

---

## 🖥️ Como Abrir Como Aplicativo (Sem Barra de Internet)

Para abrir o sistema em **janela dedicada nativa** (sem barra de URL, sem abas e sem botões de navegador):

### Opção 1: Iniciar como Janela de Aplicativo Direto
```bash
chmod +x *.sh
./iniciar_como_aplicativo_linux.sh
```
*(Inicia o servidor e abre automaticamente a janela do aplicativo nativo sem barra de internet)*

### Opção 2: Criar Ícone na Área de Trabalho (Dois Cliques)
```bash
./instalar_atalho_area_de_trabalho_linux.sh
```
*(Cria o atalho oficial com brasão na Área de Trabalho e no Menu de Aplicativos do Linux. Bastará dar dois cliques no ícone!)*

---

## 🚀 Como Iniciar Como Servidor (Em Segundo Plano ou Terminal):

1. **Permissões de Execução:**
   ```bash
   chmod +x *.sh
   ```

2. **Iniciar Servidor no Terminal:**
   ```bash
   ./iniciar_servidor.sh
   ```

3. **Instalar como Serviço 24/7 (systemd - Inicia sozinho no boot do Linux):**
   ```bash
   sudo ./instalar_servico_linux.sh
   ```

4. **Para parar o servidor:**
   ```bash
   ./parar_servidor.sh
   ```

---

## 💻 Para Computadores Windows:
Dentro da pasta, basta dar dois cliques em:
- `Abrir_Como_Aplicativo_Windows.bat` (Abre o sistema em janela de app nativa via Microsoft Edge/Chrome, sem barra de navegação).

---

## 📂 Estrutura e Recursos Locais
- **Frontend Compilado:** Pré-embutido em `dist/`. Carrega imediatamente como app de alta performance, sem aparecer como HTML bruto.
- **Banco de Dados Local:** Salvo em `server-data/db.json` (146 MB com todos os dados reais já sincronizados).
- **Uploads de Notas Fiscais:** Os arquivos PDF enviados via "Gestão de Entradas" são salvos de forma permanente na pasta `uploads/`.
- **Docker:** Utilize `docker-compose up -d` se preferir rodar em containers isolados.

Consulte `MANUAL_INSTALACAO_SERVIDOR.md` para instruções completas de firewall, backup e configuração.
