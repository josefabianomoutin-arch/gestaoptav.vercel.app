import express from "express";
import path from "path";
import fs from "fs";
import os from "os";

async function startServer() {
  console.log("-----------------------------------------");
  console.log("  SERVIDOR INTERNO - ESTOQUE PER CAPITA  ");
  console.log("-----------------------------------------");
  
  const app = express();
  const PORT = 3000;

  // Limite alto para suportar PDFs e Base64
  app.use(express.json({ limit: '200mb' }));
  app.use(express.urlencoded({ limit: '200mb', extended: true }));

  const baseDir = __dirname || process.cwd();
  const publicDir = path.join(baseDir, 'public');
  const uploadsDir = path.join(baseDir, 'uploads');
  const serverDataDir = path.join(baseDir, 'server-data');
  const distDir = fs.existsSync(path.join(baseDir, 'dist'))
    ? path.join(baseDir, 'dist')
    : path.join(process.cwd(), 'dist');
  const dbPath = path.join(serverDataDir, 'db.json');

  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
  if (!fs.existsSync(serverDataDir)) fs.mkdirSync(serverDataDir, { recursive: true });

  // Banco de dados Local em memória
  let database: any = {};
  if (fs.existsSync(dbPath)) {
    try {
      database = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
      console.log(`[DB] Banco de dados carregado: ${dbPath} (${(fs.statSync(dbPath).size / (1024 * 1024)).toFixed(2)} MB)`);
    } catch (e) {
      console.error("[DB] Erro ao carregar arquivo de dados:", e);
    }
  }

  const saveDatabase = () => {
    try {
      fs.writeFileSync(dbPath, JSON.stringify(database, null, 2));
    } catch (e) {
      console.error("[DB] Erro ao salvar arquivo de dados:", e);
    }
  };

  app.use(express.static(publicDir));
  app.use('/uploads', express.static(uploadsDir));

  // --- API DE DADOS LOCAL ---
  app.get("/api/db", (req, res) => {
    const { path: dbPathQuery } = req.query;
    if (!dbPathQuery || dbPathQuery === "/") return res.json(database);
    
    const parts = (dbPathQuery as string).split('/').filter(Boolean);
    let current = database;
    for (const part of parts) {
      if (current && typeof current === 'object') {
        current = current[part];
      } else {
        return res.json(null);
      }
    }
    res.json(current);
  });

  app.post("/api/db/update", (req, res) => {
    const { path: dbPathUpdate, data } = req.body;
    if (!dbPathUpdate) return res.status(400).json({ error: "Caminho obrigatório" });

    const parts = (dbPathUpdate as string).split('/').filter(Boolean);
    let current = database;
    
    if (parts.length === 0) {
      database = { ...database, ...data };
    } else {
      for (let i = 0; i < parts.length - 1; i++) {
        const part = parts[i];
        if (!current[part] || typeof current[part] !== 'object') current[part] = {};
        current = current[part];
      }
      const lastPart = parts[parts.length - 1];
      if (!current[lastPart] || typeof current[lastPart] !== 'object') {
        current[lastPart] = data;
      } else {
        current[lastPart] = { ...current[lastPart], ...data };
      }
    }
    
    saveDatabase();
    res.json({ success: true });
  });

  app.post("/api/db/set", (req, res) => {
    const { path: dbPathSet, data } = req.body;
    if (!dbPathSet) return res.status(400).json({ error: "Caminho obrigatório" });

    const parts = (dbPathSet as string).split('/').filter(Boolean);
    let current = database;
    
    if (parts.length === 0) {
      database = data;
    } else {
      for (let i = 0; i < parts.length - 1; i++) {
        const part = parts[i];
        if (!current[part] || typeof current[part] !== 'object') current[part] = {};
        current = current[part];
      }
      current[parts[parts.length - 1]] = data;
    }
    
    saveDatabase();
    res.json({ success: true });
  });

  app.post("/api/db/push", (req, res) => {
    const { path: dbPathPush, data } = req.body;
    const parts = (dbPathPush as string).split('/').filter(Boolean);
    let current = database;
    
    for (const part of parts) {
      if (!current[part]) current[part] = {};
      current = current[part];
    }
    
    const newId = `id_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    if (typeof data === 'object' && data !== null) {
      current[newId] = { ...data, id: data.id || newId };
    } else {
      current[newId] = data;
    }
    
    saveDatabase();
    res.json({ success: true, id: newId });
  });

  // Proxy de upload
  app.post("/api/proxy-storage-upload", (req, res) => {
    try {
      const { path: filePath, base64 } = req.body;
      if (!base64 || !filePath) {
        return res.status(400).json({ success: false, error: "Dados incompletos para upload" });
      }

      const base64Data = base64.replace(/^data:.*?;base64,/, "");
      const buffer = Buffer.from(base64Data, 'base64');

      const safePath = filePath.replace(/[^a-zA-Z0-9./-]/g, '_');
      const fullLocalPath = path.join(uploadsDir, safePath);
      const dir = path.dirname(fullLocalPath);

      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(fullLocalPath, buffer);

      console.log(`[UPLOAD] Arquivo salvo em: ${fullLocalPath}`);

      res.json({ success: true, url: `/uploads/${safePath}` });
    } catch (error: any) {
      console.error("[UPLOAD] Erro:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  app.get("/api/status", (req, res) => {
    res.json({
      status: 'ONLINE',
      mode: 'OFFLINE_STANDALONE',
      uptime: Math.floor(process.uptime()),
      dbSize: fs.existsSync(dbPath) ? fs.statSync(dbPath).size : 0
    });
  });

  app.get("/api/backup/export", (req, res) => {
    if (fs.existsSync(dbPath)) {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="backup_estoque_${new Date().toISOString().slice(0,10)}.json"`);
      fs.createReadStream(dbPath).pipe(res);
    } else {
      res.status(404).json({ error: "Banco não encontrado" });
    }
  });

  // Servir frontend compilado
  if (fs.existsSync(distDir) && fs.existsSync(path.join(distDir, 'index.html'))) {
    app.use(express.static(distDir));
    app.get('*', (req, res) => {
      if (req.path.startsWith('/api/') || req.path.startsWith('/uploads/')) {
        return res.status(404).json({ error: "Endpoint não encontrado" });
      }
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    app.get('*', (req, res) => {
      res.send(`<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Sistema de Estoque e Per Capita</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; background: #0f172a; color: #f8fafc; padding: 40px; text-align: center; }
    .card { max-width: 600px; margin: 40px auto; background: #1e293b; padding: 32px; border-radius: 20px; border: 1px solid #334155; }
    h1 { color: #38bdf8; font-size: 22px; margin-bottom: 12px; }
    p { color: #cbd5e1; font-size: 14px; line-height: 1.6; }
    .code { background: #020617; padding: 12px; border-radius: 12px; font-family: monospace; color: #a5f3fc; text-align: left; font-size: 13px; margin: 20px 0; border: 1px solid #1e293b; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Sistema de Gestão de Estoque e Almoxarifado</h1>
    <p>O servidor backend está rodando normalmente.</p>
    <p>Para abrir a aplicação como aplicativo nativo no Linux, execute:</p>
    <div class="code">./iniciar_como_aplicativo_linux.sh</div>
  </div>
</body>
</html>`);
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[SERVER] Rodando em http://localhost:${PORT}`);
  });
}

startServer();
