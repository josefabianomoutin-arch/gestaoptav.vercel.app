
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Toaster, toast } from 'sonner';
import { Supplier, Delivery, WarehouseMovement, PerCapitaConfig, CleaningLog, DirectorPerCapitaLog, StandardMenu, DailyMenus, FinancialRecord, UserRole, ThirdPartyEntryLog, AcquisitionItem, VehicleExitOrder, VehicleAsset, DriverAsset, VehicleInspection, ServiceOrder, MaintenanceSchedule, PublicInfo, ValidationRole, EpiLog, SegregationLog, MarmitaWeightLog, EnergyAccountingRecord } from './types';
import LoginScreen from './components/LoginScreen';
import Dashboard from './components/Dashboard';
import AdminDashboard from './components/AdminDashboard';
import AlmoxarifadoDashboard from './components/AlmoxarifadoDashboard';
import ItespDashboard from './components/ItespDashboard';
import FinanceDashboard from './components/FinanceDashboard';
import SubportariaDashboard from './components/SubportariaDashboard';
import MenuDashboard from './components/MenuDashboard';

import VehicleOrderDashboard from './components/VehicleOrderDashboard';
import JulioDashboard from './components/JulioDashboard';
import ServiceOrderDashboard from './components/ServiceOrderDashboard';
import InfobarTicker from './components/InfobarTicker';
import { getDatabase, ref, onValue, set, runTransaction, push, child, update, remove, get } from 'firebase/database';
import { app } from './firebaseConfig';
import { getCombinedSuppliers, calculateAllowedWeeksFromSchedule, getWeekNumber } from './lib/supplierUtils';
import { ensureArray, safeLocalStorageSetItem, safeLocalStorageSetItemAsync, sanitizeForFirebase } from './lib/utils';
import { DEFAULT_ENERGY_RECORD_AGO_26, DEFAULT_ENERGY_RECORD_JUL_26 } from './data/energyAccountingDefaults';
import { OFFICIAL_SERVICE_ORDERS, OFFICIAL_MAINTENANCE_SCHEDULES } from './data/infrastructureOfficialData';

const INITIAL_ENERGY_ACCOUNTING_RECORDS: Record<string, EnergyAccountingRecord> = {
  'jul-26': DEFAULT_ENERGY_RECORD_JUL_26,
  'ago-26': DEFAULT_ENERGY_RECORD_AGO_26
};

let database: any;
let rootRef: any;
let suppliersRef: any;
let warehouseLogRef: any;
let perCapitaConfigRef: any;
let cleaningLogsRef: any;
let segregationLogsRef: any;
let epiLogsRef: any;
let temperatureLogsRef: any;
let marmitaWeightLogsRef: any;
let directorWithdrawalsRef: any;
let standardMenuRef: any;
let dailyMenusRef: any;
let financialRecordsRef: any;
let thirdPartyEntriesRef: any;
let acquisitionItemsRef: any;
let vehicleExitOrdersRef: any;
let vehicleInspectionsRef: any;
let serviceOrdersRef: any;
let vehicleAssetsRef: any;
let driverAssetsRef: any;
let dailyAllowancesRef: any;
let staffRef: any;
let validationRolesRef: any;
let systemPasswordsRef: any;
let maintenanceSchedulesRef: any;
let publicInfoRef: any;
let directorPerCapitaRef: any;
let energyAccountingRecordsRef: any;

try {
  database = getDatabase(app);
  rootRef = ref(database);
  suppliersRef = ref(database, 'suppliers');
  warehouseLogRef = ref(database, 'warehouseLog');
  perCapitaConfigRef = ref(database, 'perCapitaConfig');
  cleaningLogsRef = ref(database, 'cleaningLogs');
  segregationLogsRef = ref(database, 'segregationLogs');
  epiLogsRef = ref(database, 'epiLogs');
  temperatureLogsRef = ref(database, 'temperatureLogs');
  marmitaWeightLogsRef = ref(database, 'marmitaWeightLogs');
  directorWithdrawalsRef = ref(database, 'directorWithdrawals');
  directorPerCapitaRef = ref(database, 'directorPerCapita');
  energyAccountingRecordsRef = ref(database, 'energyAccountingRecords');
  standardMenuRef = ref(database, 'standardMenu');
  dailyMenusRef = ref(database, 'dailyMenus');
  financialRecordsRef = ref(database, 'financialRecords');
  thirdPartyEntriesRef = ref(database, 'thirdPartyEntries');
  acquisitionItemsRef = ref(database, 'acquisitionItems');
  vehicleExitOrdersRef = ref(database, 'vehicleExitOrders');
  vehicleInspectionsRef = ref(database, 'vehicleInspections');
  serviceOrdersRef = ref(database, 'serviceOrders');
  vehicleAssetsRef = ref(database, 'vehicleAssets');
  driverAssetsRef = ref(database, 'driverAssets');
  dailyAllowancesRef = ref(database, 'dailyAllowances');
  staffRef = ref(database, 'staff');
  validationRolesRef = ref(database, 'validationRoles');
  systemPasswordsRef = ref(database, 'systemPasswords');
  maintenanceSchedulesRef = ref(database, 'maintenanceSchedules');
  publicInfoRef = ref(database, 'publicInfo');
} catch (error) {
  console.error("Erro ao inicializar Firebase:", error);
}

// Helpers para operações offline/online ultra-seguras no Firebase
const _safeGet = async (dbRef: any, fallbackValue: any = null, timeoutMs = 2500) => {
  try {
    const timeoutPromise = new Promise((resolve) => setTimeout(() => resolve(null), timeoutMs));
    const snapshotPromise = get(dbRef);
    const result: any = await Promise.race([snapshotPromise, timeoutPromise]);
    if (result && typeof result.val === 'function') {
      const val = result.val();
      return val !== null && val !== undefined ? val : fallbackValue;
    }
    return fallbackValue;
  } catch (err) {
    console.warn('safeGet falhou ou deu timeout, utilizando fallback:', err);
    return fallbackValue;
  }
};

const safeRunTransaction = async (
  dbRef: any,
  transactionUpdate: (currentData: any) => any,
  currentFallbackData: any = null,
  timeoutMs = 3000
) => {
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    try {
      const newData = transactionUpdate(currentFallbackData);
      if (newData !== undefined) {
        await set(dbRef, newData);
        return { committed: true, snapshot: null };
      }
      return { committed: false, snapshot: null };
    } catch (e) {
      console.warn('Erro na transação offline, tentando fallback:', e);
      return { committed: false, snapshot: null };
    }
  }

  try {
    const timeoutPromise = new Promise<{ committed: boolean; snapshot: null }>((resolve) =>
      setTimeout(() => resolve({ committed: false, snapshot: null }), timeoutMs)
    );
    const txPromise = runTransaction(dbRef, transactionUpdate);
    const result = await Promise.race([txPromise, timeoutPromise]);

    if (result && result.committed) {
      return result;
    }

    console.warn('Transação excedeu limite de tempo ou foi abortada, aplicando fallback direto com set');
    const newData = transactionUpdate(currentFallbackData);
    if (newData !== undefined) {
      await set(dbRef, newData);
      return { committed: true, snapshot: null };
    }
    return { committed: false, snapshot: null };
  } catch (err) {
    console.warn('Erro na transação Firebase, aplicando fallback com set:', err);
    try {
      const newData = transactionUpdate(currentFallbackData);
      if (newData !== undefined) {
        await set(dbRef, newData);
        return { committed: true, snapshot: null };
      }
    } catch (fallbackErr) {
      console.error('Falha crítica no fallback:', fallbackErr);
    }
    return { committed: false, snapshot: null };
  }
};

const getCachedState = <T,>(key: string, fallback: T): T => {
  try {
    const saved = localStorage.getItem(`cached_${key}`);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed !== undefined && parsed !== null) return parsed;
    }
  } catch (e) {
    console.error(`Error parsing cached_${key}:`, e);
  }
  return fallback;
};

const App: React.FC = () => {
  const [user, setUser] = useState<{ name: string; cpf: string; role: UserRole } | null>(null);
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => getCachedState('suppliers', []));
  const [warehouseLog, setWarehouseLog] = useState<WarehouseMovement[]>(() => getCachedState('warehouseLog', []));
  const [perCapitaConfig, setPerCapitaConfig] = useState<PerCapitaConfig>(() => getCachedState('perCapitaConfig', {}));
  const [cleaningLogs, setCleaningLogs] = useState<CleaningLog[]>(() => getCachedState('cleaningLogs', []));
  const [segregationLogs, setSegregationLogs] = useState<SegregationLog[]>(() => getCachedState('segregationLogs', []));
  const [temperatureLogs, setTemperatureLogs] = useState<any[]>(() => getCachedState('temperatureLogs', []));
  const [marmitaWeightLogs, setMarmitaWeightLogs] = useState<MarmitaWeightLog[]>(() => getCachedState('marmitaWeightLogs', []));
  const [epiLogs, setEpiLogs] = useState<EpiLog[]>(() => getCachedState('epiLogs', []));
  const [directorWithdrawals, setDirectorWithdrawals] = useState<DirectorPerCapitaLog[]>(() => getCachedState('directorWithdrawals', []));
  const [standardMenu, setStandardMenu] = useState<StandardMenu>(() => getCachedState('standardMenu', {}));
  const [dailyMenus, setDailyMenus] = useState<DailyMenus>(() => getCachedState('dailyMenus', {}));
  const [financialRecords, setFinancialRecords] = useState<FinancialRecord[]>(() => getCachedState('financialRecords', []));
  const [thirdPartyEntries, setThirdPartyEntries] = useState<ThirdPartyEntryLog[]>(() => getCachedState('thirdPartyEntries', []));
  const [acquisitionItems, setAcquisitionItems] = useState<AcquisitionItem[]>(() => getCachedState('acquisitionItems', []));
  const [vehicleExitOrders, setVehicleExitOrders] = useState<VehicleExitOrder[]>(() => getCachedState('vehicleExitOrders', []));
  const [vehicleInspections, setVehicleInspections] = useState<VehicleInspection[]>(() => getCachedState('vehicleInspections', []));
  const [serviceOrders, setServiceOrders] = useState<ServiceOrder[]>(() => {
    const cached = getCachedState<ServiceOrder[]>('serviceOrders', []);
    if (cached && cached.length > 0) return cached;
    return Object.values(OFFICIAL_SERVICE_ORDERS);
  });
  const [vehicleAssets, setVehicleAssets] = useState<VehicleAsset[]>(() => getCachedState('vehicleAssets', []));
  const [driverAssets, setDriverAssets] = useState<DriverAsset[]>(() => getCachedState('driverAssets', []));
  const [validationRoles, setValidationRoles] = useState<ValidationRole[]>(() => getCachedState('validationRoles', []));
  const [systemPasswords, setSystemPasswords] = useState<Record<string, string>>(() => getCachedState('systemPasswords', {}));
  const [maintenanceSchedules, setMaintenanceSchedules] = useState<MaintenanceSchedule[]>(() => {
    const cached = getCachedState<MaintenanceSchedule[]>('maintenanceSchedules', []);
    if (cached && cached.length > 0) return cached;
    return Object.values(OFFICIAL_MAINTENANCE_SCHEDULES);
  });
  const [_dailyAllowances, setDailyAllowances] = useState<any[]>([]);
  const [_staff, setStaff] = useState<any[]>([]);
  const [publicInfo, setPublicInfo] = useState<PublicInfo[]>(() => getCachedState('publicInfo', []));
  const [directorPerCapita, setDirectorPerCapita] = useState<any>(() => getCachedState('directorPerCapita', null));
  const hasOutdatedDummyEnergy = (rec?: any): boolean => {
    if (!rec) return true;
    const comps = Array.isArray(rec.companies) ? rec.companies : [];
    return comps.some((c: any) => 
      c.companyName?.toUpperCase().includes('ONETECH') || 
      c.companyName?.toUpperCase().includes('BIFON') || 
      c.companyName?.toUpperCase().includes('MRV')
    );
  };

  const [energyAccountingRecords, setEnergyAccountingRecords] = useState<Record<string, EnergyAccountingRecord>>(() => {
    const cached = getCachedState<Record<string, EnergyAccountingRecord>>('energyAccountingRecords', INITIAL_ENERGY_ACCOUNTING_RECORDS);
    if (cached && typeof cached === 'object' && Object.keys(cached).length > 0) {
      let changed = false;
      if (!cached['jul-26'] || hasOutdatedDummyEnergy(cached['jul-26'])) {
        cached['jul-26'] = DEFAULT_ENERGY_RECORD_JUL_26;
        changed = true;
      }
      if (!cached['ago-26'] || hasOutdatedDummyEnergy(cached['ago-26'])) {
        cached['ago-26'] = DEFAULT_ENERGY_RECORD_AGO_26;
        changed = true;
      }
      if (changed) {
        safeLocalStorageSetItem('cached_energyAccountingRecords', JSON.stringify(cached));
      }
      return cached;
    }
    return INITIAL_ENERGY_ACCOUNTING_RECORDS;
  });
  const [isPasswordsLoaded, setIsPasswordsLoaded] = useState(() => !!localStorage.getItem('cached_systemPasswords'));
  const [isSuppliersLoaded, setIsSuppliersLoaded] = useState(() => !!localStorage.getItem('cached_suppliers'));
  const [isPerCapitaConfigLoaded, setIsPerCapitaConfigLoaded] = useState(() => !!localStorage.getItem('cached_perCapitaConfig'));

  console.log("App mounted, user:", user);

  const [hasError, setHasError] = useState(false);
  const [errorDetails, setErrorDetails] = useState<string | null>(null);

  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      console.error("Global Error Captured:", event.error);
      setHasError(true);
      setErrorDetails(event.error?.message || String(event.error));
    };
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    const handleKeyDown = (e: KeyboardEvent) => {
      // Bloquear F12, Ctrl+Shift+I (Inspeção), Ctrl+Shift+J (Console), Ctrl+Shift+C (Elementos), Ctrl+U (Código-fonte)
      if (
        e.key === 'F12' || 
        (e.ctrlKey && e.shiftKey && (e.key.toUpperCase() === 'I' || e.key.toUpperCase() === 'J' || e.key.toUpperCase() === 'C')) || 
        (e.ctrlKey && e.key.toUpperCase() === 'U')
      ) {
        e.preventDefault();
      }
    };
    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  // 1. Carrega os dados persistidos do LocalStorage IMEDIATAMENTE no mount para tempo de carregamento zero 
  useEffect(() => {
    const collectionsToPersist = [
      { key: 'suppliers', setter: setSuppliers },
      { key: 'warehouseLog', setter: setWarehouseLog },
      { key: 'perCapitaConfig', setter: setPerCapitaConfig },
      { key: 'thirdPartyEntries', setter: setThirdPartyEntries },
      { key: 'acquisitionItems', setter: setAcquisitionItems },
      { key: 'standardMenu', setter: setStandardMenu },
      { key: 'dailyMenus', setter: setDailyMenus },
      { key: 'publicInfo', setter: setPublicInfo },
      { key: 'financialRecords', setter: setFinancialRecords },
      { key: 'vehicleExitOrders', setter: setVehicleExitOrders },
      { key: 'vehicleInspections', setter: setVehicleInspections },
      { key: 'serviceOrders', setter: setServiceOrders },
      { key: 'vehicleAssets', setter: setVehicleAssets },
      { key: 'driverAssets', setter: setDriverAssets },
      { key: 'validationRoles', setter: setValidationRoles },
      { key: 'systemPasswords', setter: setSystemPasswords },
      { key: 'maintenanceSchedules', setter: setMaintenanceSchedules },
      { key: 'directorPerCapita', setter: setDirectorPerCapita },
      { key: 'cleaningLogs', setter: setCleaningLogs },
      { key: 'segregationLogs', setter: setSegregationLogs },
      { key: 'temperatureLogs', setter: setTemperatureLogs },
      { key: 'marmitaWeightLogs', setter: setMarmitaWeightLogs },
      { key: 'epiLogs', setter: setEpiLogs },
      { key: 'directorWithdrawals', setter: setDirectorWithdrawals },
      { key: 'energyAccountingRecords', setter: setEnergyAccountingRecords }
    ];

    collectionsToPersist.forEach(({ key, setter }) => {
      const saved = localStorage.getItem(`cached_${key}`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed) {
            if (key === 'perCapitaConfig') {
              const pConfig = { ...parsed };
              const pLegacy = Array.isArray(pConfig.pereciveisSuppliers) ? pConfig.pereciveisSuppliers : Object.values(pConfig.pereciveisSuppliers || {});
              const p2Q = Array.isArray(pConfig.pereciveisSuppliers2Q) ? pConfig.pereciveisSuppliers2Q : Object.values(pConfig.pereciveisSuppliers2Q || {});
              const p3Q = Array.isArray(pConfig.pereciveisSuppliers3Q) ? pConfig.pereciveisSuppliers3Q : Object.values(pConfig.pereciveisSuppliers3Q || {});
              const restoredP2Q = p2Q.length > 0 ? p2Q : pLegacy;
              pConfig.pereciveisSuppliers2Q = restoredP2Q;
              pConfig.pereciveisSuppliers = restoredP2Q;
              pConfig.pereciveisSuppliers3Q = p3Q;

              const eLegacy = Array.isArray(pConfig.estocaveisSuppliers) ? pConfig.estocaveisSuppliers : Object.values(pConfig.estocaveisSuppliers || {});
              const e2Q = Array.isArray(pConfig.estocaveisSuppliers2Q) ? pConfig.estocaveisSuppliers2Q : Object.values(pConfig.estocaveisSuppliers2Q || {});
              const e3Q = Array.isArray(pConfig.estocaveisSuppliers3Q) ? pConfig.estocaveisSuppliers3Q : Object.values(pConfig.estocaveisSuppliers3Q || {});
              const restoredE2Q = e2Q.length > 0 ? e2Q : eLegacy;
              pConfig.estocaveisSuppliers2Q = restoredE2Q;
              pConfig.estocaveisSuppliers = restoredE2Q;
              pConfig.estocaveisSuppliers3Q = e3Q;

              setter(pConfig);
              setIsPerCapitaConfigLoaded(true);
            } else if (key === 'acquisitionItems' && Array.isArray(parsed)) {
              const sanitizedAcq = parsed.map((item: any) => {
                if (!item) return item;
                const cat = (item.category || '').trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
                // Preservar itens de todos os quadrimestres (1Q, 2Q, 3Q); atribuir 2Q apenas a itens legados sem quadrimestre
                if (cat === 'PERECIVEIS' || cat === 'ESTOCAVEIS') {
                  if (!item.quadrimestre) {
                    return { ...item, year: item.year || 2026, quadrimestre: '2Q' };
                  }
                }
                return item;
              });
              setter(sanitizedAcq);
            } else {
              setter(parsed);
            }
            if (key === 'systemPasswords') setIsPasswordsLoaded(true);
            if (key === 'suppliers') setIsSuppliersLoaded(true);
            if (key === 'perCapitaConfig') setIsPerCapitaConfigLoaded(true);
          }
        } catch (e) {
          console.error(`Error loading cached ${key}:`, e);
        }
      }
    });
  }, []);

  // 2. Conecta aos dados públicos essenciais no mount de forma leve (PublicInfo para tela de Login e Senhas do sistema)
  useEffect(() => {
    // Safety fallback timer to ensure loading flags unlock after 1.5s even if network is slow/offline
    const fallbackTimer = setTimeout(() => {
      setIsPasswordsLoaded(true);
      setIsSuppliersLoaded(true);
      setIsPerCapitaConfigLoaded(true);
    }, 1500);

    if (!database) {
      setTimeout(() => {
        setIsPasswordsLoaded(true);
        setIsSuppliersLoaded(true);
        setIsPerCapitaConfigLoaded(true);
      }, 0);
      return () => clearTimeout(fallbackTimer);
    }

    const unsubscribes: (() => void)[] = [];

    const connectedRef = ref(database, '.info/connected');
    const unsubConnected = onValue(connectedRef, (snap) => {
      if (snap.val() === true) {
        console.log("Conectado ao Firebase Realtime Database!");
      } else {
        console.warn("Desconectado do Firebase Realtime Database.");
      }
    });
    unsubscribes.push(unsubConnected);

    const unsubPublicInfo = onValue(publicInfoRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      list.sort((a: any, b: any) => new Date(b.updatedAt || b.date || 0).getTime() - new Date(a.updatedAt || a.date || 0).getTime());
      setPublicInfo(list as PublicInfo[]);
      safeLocalStorageSetItem('cached_publicInfo', JSON.stringify(list));
    });
    unsubscribes.push(unsubPublicInfo);

    const unsubPasswords = onValue(systemPasswordsRef, (snapshot) => {
      const data = snapshot.val() || {};
      setSystemPasswords(data);
      setIsPasswordsLoaded(true);
      safeLocalStorageSetItem('cached_systemPasswords', JSON.stringify(data));
    }, (err) => {
      console.error("Erro ao carregar senhas do sistema:", err);
      setIsPasswordsLoaded(true);
    });
    unsubscribes.push(unsubPasswords);

    // Carregamento de Fornecedores e PerCapitaConfig ANTES do usuário autenticar, pois são necessários para o login dos produtores
    const unsubSuppliers = onValue(suppliersRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.entries(data).map(([key, value]: [string, any]) => ({
        ...value,
        id: value.id || key,
        cpf: value.cpf || key
      })) : [];
      setSuppliers(list as Supplier[]);
      setIsSuppliersLoaded(true);
      safeLocalStorageSetItem('cached_suppliers', JSON.stringify(list));
    }, (err) => {
      console.error("Erro ao carregar fornecedores:", err);
      setIsSuppliersLoaded(true);
    });
    unsubscribes.push(unsubSuppliers);

    const unsubPerCapita = onValue(perCapitaConfigRef, (snapshot) => {
      const data = snapshot.val();
      const config = data || {};
      
      // Preserva e carrega os fornecedores de todos os quadrimestres (1Q, 2Q, 3Q) de 2026 e 2027
      const pLegacy = Array.isArray(config.pereciveisSuppliers) ? config.pereciveisSuppliers : Object.values(config.pereciveisSuppliers || {});
      const p2Q = Array.isArray(config.pereciveisSuppliers2Q) ? config.pereciveisSuppliers2Q : Object.values(config.pereciveisSuppliers2Q || {});
      const p3Q = Array.isArray(config.pereciveisSuppliers3Q) ? config.pereciveisSuppliers3Q : Object.values(config.pereciveisSuppliers3Q || {});
      
      const restoredP2Q = p2Q.length > 0 ? p2Q : pLegacy;
      config.pereciveisSuppliers2Q = restoredP2Q;
      if (!config.pereciveisSuppliers || config.pereciveisSuppliers.length === 0) {
        config.pereciveisSuppliers = restoredP2Q;
      }
      config.pereciveisSuppliers3Q = p3Q;

      const eLegacy = Array.isArray(config.estocaveisSuppliers) ? config.estocaveisSuppliers : Object.values(config.estocaveisSuppliers || {});
      const e2Q = Array.isArray(config.estocaveisSuppliers2Q) ? config.estocaveisSuppliers2Q : Object.values(config.estocaveisSuppliers2Q || {});
      const e3Q = Array.isArray(config.estocaveisSuppliers3Q) ? config.estocaveisSuppliers3Q : Object.values(config.estocaveisSuppliers3Q || {});

      const restoredE2Q = e2Q.length > 0 ? e2Q : eLegacy;
      config.estocaveisSuppliers2Q = restoredE2Q;
      if (!config.estocaveisSuppliers || config.estocaveisSuppliers.length === 0) {
        config.estocaveisSuppliers = restoredE2Q;
      }
      config.estocaveisSuppliers3Q = e3Q;

      // Se o 2Q ainda não estava salvo no banco a partir do legado, persiste 2Q:
      if (database && navigator.onLine) {
        if (pLegacy.length > 0 && (!config.pereciveisSuppliers2Q || config.pereciveisSuppliers2Q.length === 0)) {
          update(perCapitaConfigRef, {
            pereciveisSuppliers2Q: restoredP2Q,
            estocaveisSuppliers2Q: restoredE2Q
          }).catch(e => console.warn("Erro ao salvar 2Q no perCapitaConfig:", e));
        }
      }

      setPerCapitaConfig(config);
      setIsPerCapitaConfigLoaded(true);
      safeLocalStorageSetItem('cached_perCapitaConfig', JSON.stringify(config));
    }, (err) => {
      console.error("Erro ao carregar perCapitaConfig:", err);
      setIsPerCapitaConfigLoaded(true);
    });
    unsubscribes.push(unsubPerCapita);

    return () => {
      clearTimeout(fallbackTimer);
      unsubscribes.forEach((unsub) => unsub());
    };
  }, []);

  const hasRunCleanup = useRef(false);

  const runDatabaseCleanup = useCallback(async () => {
    try {
      console.log("Iniciando a limpeza automática de agendamentos duplicados idênticos...");
      let totalCleanedCount = 0;

      // 1. Limpeza de entregas dos Fornecedores Principais (Main Suppliers)
      if (suppliers && suppliers.length > 0) {
        for (const sup of suppliers) {
          if (!sup) continue;
          const deliveries = Array.isArray(sup.deliveries) 
            ? sup.deliveries 
            : Object.values(sup.deliveries || {});
          if (deliveries.length === 0) continue;

          // Agrupa as entregas por data, horário e item para identificar duplicados exatos
          const uniqueGroups = new Map<string, any[]>();
          deliveries.forEach(d => {
            if (!d || !d.date) return;
            const key = `${d.date}_${d.time || ''}_${d.item || ''}_${d.status || ''}`;
            const group = uniqueGroups.get(key) || [];
            group.push(d);
            uniqueGroups.set(key, group);
          });

          let needsUpdate = false;
          const cleanedDeliveries: any[] = [];

          uniqueGroups.forEach((group) => {
            if (group.length <= 1) {
              cleanedDeliveries.push(...group);
              return;
            }

            // Múltiplos agendamentos idênticos. Mantemos apenas um.
            // Priorizamos entregas com nota fiscal enviada ou concluídas, e desempatamos por IDs existentes
            group.sort((a, b) => {
              const aInvoiced = a.invoiceUploaded || a.status === 'CONCLUÍDO';
              const bInvoiced = b.invoiceUploaded || b.status === 'CONCLUÍDO';
              if (aInvoiced && !bInvoiced) return -1;
              if (!aInvoiced && bInvoiced) return 1;
              return (a.id || '').localeCompare(b.id || '');
            });

            cleanedDeliveries.push(group[0]);
            totalCleanedCount += (group.length - 1);
            needsUpdate = true;
          });

          if (needsUpdate) {
            console.log(`Limpando duplicados idênticos para o fornecedor CPF ${sup.cpf}: mantendo ${cleanedDeliveries.length} de ${deliveries.length} agendamentos.`);
            // Certifica-se de que cada entrega salva tenha um ID persistente
            const finalDeliveries = cleanedDeliveries.map((d, index) => {
              if (d && typeof d === 'object') {
                return { ...d, id: d.id || `delivery-${index}-${Date.now()}` };
              }
              return d;
            });
            const deliveriesRef = child(suppliersRef, `${sup.id || sup.cpf}/deliveries`);
            await set(deliveriesRef, finalDeliveries);
          }
        }
      }

      // 2. Limpeza de listas de Per Capita Config
      if (perCapitaConfig) {
        const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
        for (const listKey of lists) {
          const list = ensureArray(perCapitaConfig[listKey]);
          let listNeedsUpdate = false;
          const updatedList = [...list];

          for (let idx = 0; idx < updatedList.length; idx++) {
            const p = updatedList[idx];
            if (!p) continue;
            const deliveries = Array.isArray(p.deliveries) 
              ? p.deliveries 
              : Object.values(p.deliveries || {});
            if (deliveries.length === 0) continue;

            const uniqueGroups = new Map<string, any[]>();
            deliveries.forEach((d: any) => {
              if (!d || !d.date) return;
              const key = `${d.date}_${d.time || ''}_${d.item || ''}_${d.status || ''}`;
              const group = uniqueGroups.get(key) || [];
              group.push(d);
              uniqueGroups.set(key, group);
            });

            let needsUpdate = false;
            const cleanedDeliveries: any[] = [];

            uniqueGroups.forEach((group) => {
              if (group.length <= 1) {
                cleanedDeliveries.push(...group);
                return;
              }

              group.sort((a, b) => {
                const aInvoiced = a.invoiceUploaded || a.status === 'CONCLUÍDO';
                const bInvoiced = b.invoiceUploaded || b.status === 'CONCLUÍDO';
                if (aInvoiced && !bInvoiced) return -1;
                if (!aInvoiced && bInvoiced) return 1;
                return (a.id || '').localeCompare(b.id || '');
              });

              cleanedDeliveries.push(group[0]);
              totalCleanedCount += (group.length - 1);
              needsUpdate = true;
            });

            if (needsUpdate) {
              const finalDeliveries = cleanedDeliveries.map((d, dIdx) => {
                if (d && typeof d === 'object') {
                  return { ...d, id: d.id || `delivery-${dIdx}-${Date.now()}` };
                }
                return d;
              });
              updatedList[idx] = { ...p, deliveries: finalDeliveries };
              listNeedsUpdate = true;
            }
          }

          if (listNeedsUpdate) {
            console.log(`Limpando duplicados idênticos na lista PerCapita ${listKey}.`);
            await set(child(perCapitaConfigRef, listKey), updatedList);
          }
        }
      }

      // 3. Limpeza de itens de contrato duplicados (contractItems)
      let itemsCleanedCount = 0;
      
      const cleanContractItems = (items: any[]) => {
        if (!items || !Array.isArray(items)) return items;
        const uniqueItems = new Map<string, any>();
        items.forEach(item => {
          if (!item || !item.name) return;
          const key = String(item.name).toUpperCase().trim();
          if (uniqueItems.has(key)) {
            itemsCleanedCount++;
          } else {
            uniqueItems.set(key, item);
          }
        });
        return Array.from(uniqueItems.values());
      };

      if (suppliers && suppliers.length > 0) {
        for (const sup of suppliers) {
          if (!sup || !sup.contractItems || !Array.isArray(sup.contractItems) || sup.contractItems.length === 0) continue;
          const cleanedItems = cleanContractItems(sup.contractItems);
          if (cleanedItems.length !== sup.contractItems.length) {
            await set(child(suppliersRef, `${sup.id || sup.cpf}/contractItems`), cleanedItems);
          }
        }
      }

      if (perCapitaConfig) {
        const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
        for (const listKey of lists) {
          const list = ensureArray(perCapitaConfig[listKey]);
          let listNeedsUpdate = false;
          const updatedList = [...list];

          for (let idx = 0; idx < updatedList.length; idx++) {
            const p = updatedList[idx];
            if (!p || !p.contractItems || !Array.isArray(p.contractItems)) continue;
            const cleanedItems = cleanContractItems(p.contractItems);
            if (cleanedItems.length !== p.contractItems.length) {
              updatedList[idx] = { ...p, contractItems: cleanedItems };
              listNeedsUpdate = true;
            }
          }

          if (listNeedsUpdate) {
             await set(child(perCapitaConfigRef, listKey), updatedList);
          }
        }
      }

      if (totalCleanedCount > 0 || itemsCleanedCount > 0) {
        toast.info(`Limpeza concluída: ${totalCleanedCount} entregas duplicadas e ${itemsCleanedCount} itens duplicados no contrato removidos.`);
      } else {
        console.log("Nenhum agendamento duplicado idêntico encontrado para limpar.");
      }
    } catch (err) {
      console.error("Erro durante a limpeza automática de agendamentos:", err);
    }
  }, [suppliers, perCapitaConfig]);

  useEffect(() => {
    if (!database || !user || user.role !== 'admin' || hasRunCleanup.current || !isSuppliersLoaded || !isPerCapitaConfigLoaded) return;

    hasRunCleanup.current = true;
    runDatabaseCleanup();
  }, [user, isSuppliersLoaded, isPerCapitaConfigLoaded, runDatabaseCleanup]);

  // 3. Conecta aos dados pesados dinamicamente e APENAS quando o usuário estiver autenticado
  useEffect(() => {
    if (!database || !user) return;

    const unsubscribes: (() => void)[] = [];

    // Logs de Movimentação do Almoxarifado (Altamente pesado)
    const unsubWarehouseLog = onValue(warehouseLogRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.entries(data).map(([key, value]: [string, any]) => ({
        ...value,
        id: value.id || key
      })) : [];
      setWarehouseLog(list as WarehouseMovement[]);
      safeLocalStorageSetItem('cached_warehouseLog', JSON.stringify(list));
    });
    unsubscribes.push(unsubWarehouseLog);

    // Registros de Limpeza
    const unsubCleaningLogs = onValue(cleaningLogsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setCleaningLogs(list as CleaningLog[]);
      safeLocalStorageSetItem('cached_cleaningLogs', JSON.stringify(list));
    });
    unsubscribes.push(unsubCleaningLogs);

    // Registros de Segregação
    const unsubSegregationLogs = onValue(segregationLogsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setSegregationLogs(list as SegregationLog[]);
      safeLocalStorageSetItem('cached_segregationLogs', JSON.stringify(list));
    });
    unsubscribes.push(unsubSegregationLogs);

    // Registros de Temperatura das Câmaras Frias
    const unsubTemperatureLogs = onValue(temperatureLogsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setTemperatureLogs(list);
      safeLocalStorageSetItem('cached_temperatureLogs', JSON.stringify(list));
    });
    unsubscribes.push(unsubTemperatureLogs);

    // Registros de Peso das Marmitas
    const unsubMarmitaWeightLogs = onValue(marmitaWeightLogsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setMarmitaWeightLogs(list as MarmitaWeightLog[]);
      safeLocalStorageSetItem('cached_marmitaWeightLogs', JSON.stringify(list));
    });
    unsubscribes.push(unsubMarmitaWeightLogs);

    // Registros de EPI
    const unsubEpiLogs = onValue(epiLogsRef, (snapshot) => {
        const data = snapshot.val();
        const list = data ? Object.values(data) : [];
        setEpiLogs(list as EpiLog[]);
        safeLocalStorageSetItem('cached_epiLogs', JSON.stringify(list));
    });
    unsubscribes.push(unsubEpiLogs);

    // Retiradas dos Diretores
    const unsubDirectorWithdrawals = onValue(directorWithdrawalsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setDirectorWithdrawals(list as DirectorPerCapitaLog[]);
      safeLocalStorageSetItem('cached_directorWithdrawals', JSON.stringify(list));
    });
    unsubscribes.push(unsubDirectorWithdrawals);

    // Cardápio Padrão
    const unsubStandardMenu = onValue(standardMenuRef, (snapshot) => {
      const data = snapshot.val() || {};
      setStandardMenu(data);
      safeLocalStorageSetItem('cached_standardMenu', JSON.stringify(data));
    });
    unsubscribes.push(unsubStandardMenu);

    // Cardápios Diários
    const unsubDailyMenus = onValue(dailyMenusRef, (snapshot) => {
      const data = snapshot.val() || {};
      setDailyMenus(data);
      safeLocalStorageSetItem('cached_dailyMenus', JSON.stringify(data));
    });
    unsubscribes.push(unsubDailyMenus);

    // Registros Financeiros
    const unsubFinancial = onValue(financialRecordsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.entries(data).map(([key, value]: [string, any]) => ({
        ...value,
        id: value.id || key
      })) : [];
      setFinancialRecords(list as FinancialRecord[]);
      safeLocalStorageSetItem('cached_financialRecords', JSON.stringify(list));
    });
    unsubscribes.push(unsubFinancial);

    // Entradas de Terceiros
    const unsubThirdParty = onValue(thirdPartyEntriesRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setThirdPartyEntries(list as ThirdPartyEntryLog[]);
      safeLocalStorageSetItem('cached_thirdPartyEntries', JSON.stringify(list));
    });
    unsubscribes.push(unsubThirdParty);

    // Itens de Aquisição
    const unsubAcquisitionItems = onValue(acquisitionItemsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      
      let needsFirebaseUpdate = false;
      const updatesToFirebase: Record<string, any> = {};

      const processedItems = (list as AcquisitionItem[]).map(item => {
        if (!item || !item.name) return item;
        const normCat = (item.category || '').trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();

        // PPAIS não entra nesta regra: permanece inalterado!
        if (normCat === 'PPAIS') {
          return item;
        }

        if (normCat === 'PERECIVEIS' || normCat === 'ESTOCAVEIS') {
          // Se o item não possui quadrimestre definido (item legado), atribui 2Q por padrão.
          // Preserva itens que já possuem quadrimestre (1Q, 2Q ou 3Q) e ano definidos!
          if (!item.quadrimestre) {
            needsFirebaseUpdate = true;
            const updated: AcquisitionItem = {
              ...item,
              year: item.year || 2026,
              quadrimestre: '2Q'
            };
            if (item.id) {
              updatesToFirebase[`acquisitionItems/${item.id}/quadrimestre`] = '2Q';
              updatesToFirebase[`acquisitionItems/${item.id}/year`] = item.year || 2026;
            }
            return updated;
          }
        }
        return item;
      });

      if (needsFirebaseUpdate && database && navigator.onLine && Object.keys(updatesToFirebase).length > 0) {
        update(ref(database), updatesToFirebase).catch(e => console.warn("Erro ao sincronizar quadrimestre dos itens no Firebase:", e));
      }

      setAcquisitionItems(processedItems);
      safeLocalStorageSetItem('cached_acquisitionItems', JSON.stringify(processedItems));
    });
    unsubscribes.push(unsubAcquisitionItems);

    // Autorizações de Saída de Veículos
    const unsubVehicleOrders = onValue(vehicleExitOrdersRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setVehicleExitOrders(list as VehicleExitOrder[]);
      safeLocalStorageSetItemAsync('cached_vehicleExitOrders', list, 300);
    });
    unsubscribes.push(unsubVehicleOrders);

    // Inspeções de Veículos
    const unsubVehicleInspections = onValue(vehicleInspectionsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setVehicleInspections(list as VehicleInspection[]);
      safeLocalStorageSetItem('cached_vehicleInspections', JSON.stringify(list));
    });
    unsubscribes.push(unsubVehicleInspections);

    // Ordens de Serviço
    const unsubServiceOrders = onValue(serviceOrdersRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      if (list.length === 0) {
        const officialOrders = Object.values(OFFICIAL_SERVICE_ORDERS);
        setServiceOrders(officialOrders);
        safeLocalStorageSetItem('cached_serviceOrders', JSON.stringify(officialOrders));
        if (database) {
          set(serviceOrdersRef, OFFICIAL_SERVICE_ORDERS).catch((err) =>
            console.warn('Auto-sync serviceOrders to Firebase:', err)
          );
        }
      } else {
        setServiceOrders(list as ServiceOrder[]);
        safeLocalStorageSetItem('cached_serviceOrders', JSON.stringify(list));
      }
    });
    unsubscribes.push(unsubServiceOrders);

    // Veículos Ativos
    const unsubVehicleAssets = onValue(vehicleAssetsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setVehicleAssets(list as VehicleAsset[]);
      safeLocalStorageSetItem('cached_vehicleAssets', JSON.stringify(list));
    });
    unsubscribes.push(unsubVehicleAssets);

    // Motoristas Ativos
    const unsubDriverAssets = onValue(driverAssetsRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setDriverAssets(list as DriverAsset[]);
      safeLocalStorageSetItem('cached_driverAssets', JSON.stringify(list));
    });
    unsubscribes.push(unsubDriverAssets);

    // Diárias/Ajuda de Custo
    const unsubDailyAllowances = onValue(dailyAllowancesRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setDailyAllowances(list);
    });
    unsubscribes.push(unsubDailyAllowances);

    // Funcionários Ativos
    const unsubStaff = onValue(staffRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setStaff(list);
    });
    unsubscribes.push(unsubStaff);

    // Perfis de Validação
    const unsubValidationRoles = onValue(validationRolesRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) : [];
      setValidationRoles(list as ValidationRole[]);
      safeLocalStorageSetItem('cached_validationRoles', JSON.stringify(list));
    });
    unsubscribes.push(unsubValidationRoles);

    // Agendamentos de Manutenção
    const unsubMaintenance = onValue(maintenanceSchedulesRef, (snapshot) => {
      const data = snapshot.val();
      const list = data ? Object.values(data) as MaintenanceSchedule[] : [];
      
      if (list.length === 0 || (list.length === 1 && list[0].description === 'Manutenção da Câmara Fria')) {
        const officialSchedules = Object.values(OFFICIAL_MAINTENANCE_SCHEDULES);
        setMaintenanceSchedules(officialSchedules);
        safeLocalStorageSetItem('cached_maintenanceSchedules', JSON.stringify(officialSchedules));
        if (database) {
          set(maintenanceSchedulesRef, OFFICIAL_MAINTENANCE_SCHEDULES).catch((err) =>
            console.warn('Auto-sync maintenanceSchedules to Firebase:', err)
          );
        }
      } else {
        setMaintenanceSchedules(list as MaintenanceSchedule[]);
        safeLocalStorageSetItem('cached_maintenanceSchedules', JSON.stringify(list));
      }
    });
    unsubscribes.push(unsubMaintenance);

    // Registros Per Capita dos Diretores
    const unsubDirectorPerCapita = onValue(directorPerCapitaRef, (snapshot) => {
      const data = snapshot.val() || {};
      
      const createEmptyItems = () => Array.from({ length: 25 }, (_, i) => ({
        index: i + 1,
        itemName: '',
        quantity: '',
        observation: ''
      }));

      const chefeDep = data.chefeDep || {
        activeOrder: {
          items: createEmptyItems(),
          id: 'atual',
          signed: false,
          signedAt: '',
          signerName: ''
        },
        history: {}
      };

      const chefeSeg = data.chefeSeg || {
        activeOrder: {
          items: createEmptyItems(),
          id: 'atual',
          signed: false,
          signedAt: '',
          signerName: ''
        },
        history: {}
      };

      if (!chefeDep.activeOrder) {
        chefeDep.activeOrder = {
          items: createEmptyItems(),
          id: 'atual',
          signed: false,
          signedAt: '',
          signerName: ''
        };
      }
      if (!chefeDep.history) {
        chefeDep.history = {};
      }

      if (!chefeSeg.activeOrder) {
        chefeSeg.activeOrder = {
          items: createEmptyItems(),
          id: 'atual',
          signed: false,
          signedAt: '',
          signerName: ''
        };
      }
      if (!chefeSeg.history) {
        chefeSeg.history = {};
      }

      const merged = { chefeDep, chefeSeg };
      setDirectorPerCapita(merged);
      safeLocalStorageSetItem('cached_directorPerCapita', JSON.stringify(merged));
    });
    unsubscribes.push(unsubDirectorPerCapita);

    // Contabilização de Energia Elétrica (Taiúva)
    const unsubEnergyAccounting = onValue(energyAccountingRecordsRef, (snapshot) => {
      const data = snapshot.val();
      if (data && typeof data === 'object') {
        const merged = { ...data };
        let needsSeed = false;
        if (!merged['jul-26'] || hasOutdatedDummyEnergy(merged['jul-26'])) {
          merged['jul-26'] = DEFAULT_ENERGY_RECORD_JUL_26;
          needsSeed = true;
        }
        if (!merged['ago-26'] || hasOutdatedDummyEnergy(merged['ago-26'])) {
          merged['ago-26'] = DEFAULT_ENERGY_RECORD_AGO_26;
          needsSeed = true;
        }
        if (needsSeed) {
          set(energyAccountingRecordsRef, merged).catch(console.error);
        }
        setEnergyAccountingRecords(merged);
        safeLocalStorageSetItem('cached_energyAccountingRecords', JSON.stringify(merged));
      } else {
        set(energyAccountingRecordsRef, INITIAL_ENERGY_ACCOUNTING_RECORDS).catch(console.error);
        setEnergyAccountingRecords(INITIAL_ENERGY_ACCOUNTING_RECORDS);
        safeLocalStorageSetItem('cached_energyAccountingRecords', JSON.stringify(INITIAL_ENERGY_ACCOUNTING_RECORDS));
      }
    });
    unsubscribes.push(unsubEnergyAccounting);

    return () => {
      console.log("Desinscrevendo de todos os listeners pesados do Firebase Realtime Database.");
      unsubscribes.forEach((unsub) => unsub());
    };
  }, [user]);

  const handleUpdateDirectorPerCapita = async (updatedData: any) => {
    try {
      await set(directorPerCapitaRef, updatedData);
      return { success: true };
    } catch (e) {
      console.error('Erro ao atualizar per capita dos diretores:', e);
      return { success: false, message: 'Erro ao salvar os dados no banco de dados.' };
    }
  };

  const handleSaveEnergyAccountingRecord = async (record: EnergyAccountingRecord) => {
    try {
      const recRef = child(energyAccountingRecordsRef, record.id);
      await set(recRef, record);
      setEnergyAccountingRecords(prev => {
        const next = { ...prev, [record.id]: record };
        safeLocalStorageSetItem('cached_energyAccountingRecords', JSON.stringify(next));
        return next;
      });
      return { success: true, message: 'Demonstrativo de consumo salvo com sucesso!' };
    } catch (err: any) {
      console.error('Erro ao salvar demonstrativo de energia:', err);
      return { success: false, message: err?.message || 'Erro ao salvar demonstrativo' };
    }
  };

  const handleDeleteEnergyAccountingRecord = async (id: string) => {
    try {
      const recRef = child(energyAccountingRecordsRef, id);
      await remove(recRef);
      setEnergyAccountingRecords(prev => {
        const next = { ...prev };
        delete next[id];
        safeLocalStorageSetItem('cached_energyAccountingRecords', JSON.stringify(next));
        return next;
      });
      return { success: true, message: 'Demonstrativo excluído com sucesso!' };
    } catch (err: any) {
      console.error('Erro ao excluir demonstrativo de energia:', err);
      return { success: false, message: err?.message || 'Erro ao excluir demonstrativo' };
    }
  };

  const handleRegisterMaintenanceSchedule = async (schedule: Omit<MaintenanceSchedule, 'id'>) => {
    try {
      const newScheduleRef = push(maintenanceSchedulesRef);
      const newSchedule = { ...schedule, id: newScheduleRef.key as string };
      await set(newScheduleRef, newSchedule);
      toast.success('Agendamento de manutenção registrado com sucesso!');
      return { success: true, message: 'Agendamento registrado' };
    } catch (error) {
      console.error('Erro ao registrar agendamento:', error);
      toast.error('Erro ao registrar agendamento.');
      return { success: false, message: 'Erro ao registrar agendamento' };
    }
  };

  const handleUpdateMaintenanceSchedule = async (idOrSchedule: string | MaintenanceSchedule, updates?: Partial<MaintenanceSchedule>) => {
    try {
      if (typeof idOrSchedule === 'string') {
        const scheduleRef = child(maintenanceSchedulesRef, idOrSchedule);
        await update(scheduleRef, updates!);
      } else {
        const scheduleRef = child(maintenanceSchedulesRef, idOrSchedule.id);
        await set(scheduleRef, idOrSchedule);
      }
      toast.success('Agendamento atualizado com sucesso!');
      return { success: true, message: 'Agendamento atualizado' };
    } catch (error) {
      console.error('Erro ao atualizar agendamento:', error);
      toast.error('Erro ao atualizar agendamento.');
      return { success: false, message: 'Erro ao atualizar agendamento' };
    }
  };

  const handleDeleteMaintenanceSchedule = async (id: string) => {
    try {
      const scheduleRef = child(maintenanceSchedulesRef, id);
      await remove(scheduleRef);
      toast.success('Agendamento removido com sucesso!');
      return { success: true, message: 'Agendamento removido' };
    } catch (error) {
      console.error('Erro ao remover agendamento:', error);
      toast.error('Erro ao remover agendamento.');
      return { success: false, message: 'Erro ao remover agendamento' };
    }
  };

  const handleLogin = async (nameInput: string, passwordInput: string) => {
    const cleanName = (nameInput || '').trim().toUpperCase();
    const rawPass = (passwordInput || '').trim();

    if (cleanName === 'ORDEM DE SERVIÇO' && rawPass === 'serviço') {
      setUser({ name: 'ORDEM DE SERVIÇO', cpf: 'os-user', role: 'ordem_servico' });
      return true;
    }

    const numericPass = rawPass.replace(/\D/g, '');

    // ACESSO ESPECÍFICO: DANIELE GARCIA POSSIDONIO
    if (cleanName.includes('DANIELE') && numericPass === '33342143894') {
      setUser({ name: 'DANIELE GARCIA POSSIDONIO', cpf: numericPass, role: 'financeiro' });
      return true;
    }

    const adminCpfs = ['15210361870', '22121664866', '22743505826'];

    // ACESSO ESPECÍFICO: WALTER RODRIGUES JUNIOR
    if (['WALTER', 'RODRIGUES', 'JUNIOR'].some(n => cleanName.includes(n))) {
      const walterDbPass = (systemPasswords['WALTER RODRIGUES JUNIOR'] || '22121664866').trim().toLowerCase();
      if (numericPass === '22121664866' || rawPass.toLowerCase() === walterDbPass) {
        setUser({ name: 'WALTER RODRIGUES JUNIOR', cpf: '22121664866', role: 'financeiro' });
        return true;
      }
    }

    // ACESSO ESPECÍFICO: WILLIAN OLIVEIRA DOS SANTOS
    if (['WILLIAN', 'OLIVEIRA', 'SANTOS'].some(n => cleanName.includes(n))) {
      const willianDbPass = (systemPasswords['WILLIAN OLIVEIRA DOS SANTOS'] || '22743505826').trim().toLowerCase();
      if (numericPass === '22743505826' || rawPass.toLowerCase() === willianDbPass) {
        setUser({ name: 'WILLIAN OLIVEIRA DOS SANTOS', cpf: '22743505826', role: 'financeiro' });
        return true;
      }
    }

    if (['ADMINISTRADOR', 'ADM', 'WALTER', 'WILLIAN'].some(n => cleanName.includes(n))) {
      if (adminCpfs.includes(numericPass)) {
        let displayName = cleanName;
        if (numericPass === '22121664866') {
          displayName = 'WALTER RODRIGUES JUNIOR';
        } else if (numericPass === '22743505826') {
          displayName = 'WILLIAN OLIVEIRA DOS SANTOS';
        }
        const isFinanceAdmin = cleanName.includes('WALTER') || cleanName.includes('WILLIAN') || numericPass === '22121664866' || numericPass === '22743505826';
        setUser({ name: displayName, cpf: numericPass, role: isFinanceAdmin ? 'financeiro' : 'admin' });
        return true;
      }
    }

    if (cleanName === 'ALMOXARIFADO' || cleanName === 'ALMOX') {
      if (rawPass.toLowerCase() === (systemPasswords['ALMOXARIFADO'] || 'almoxarifado123').toLowerCase()) {
        setUser({ name: 'ALMOXARIFADO', cpf: 'almoxarifado123', role: 'almoxarifado' });
        return true;
      }
    }
    if (cleanName === 'ITESP' && rawPass.toLowerCase() === (systemPasswords['ITESP'] || 'taiuvaitesp2026').toLowerCase()) {
      setUser({ name: 'ITESP', cpf: 'taiuvaitesp2026', role: 'itesp' });
      return true;
    }
    if (cleanName === 'FINANCEIRO' && rawPass.toLowerCase() === (systemPasswords['FINANCEIRO'] || 'financeiro123').toLowerCase()) {
      setUser({ name: 'FINANCEIRO', cpf: 'financeiro123', role: 'financeiro' });
      return true;
    }
    if ((cleanName === 'CARDAPIO' || cleanName === 'CARDÁPIO') && rawPass.toLowerCase() === (systemPasswords['CARDAPIO'] || 'cardapio123').toLowerCase()) {
      setUser({ name: 'CARDAPIO', cpf: 'cardapio123', role: 'cardapio' });
      return true;
    }
    if (cleanName === 'SEGURANÇA EXTERNA' && rawPass === (systemPasswords['SEGURANÇA EXTERNA'] || 'externa2026')) {
      setUser({ name: 'SEGURANÇA EXTERNA', cpf: 'externa2026', role: 'subportaria' });
      return true;
    }
    if (cleanName === 'INFRAESTRUTURA' && rawPass === (systemPasswords['INFRAESTRUTURA'] || 'infra2026')) {
      setUser({ name: 'INFRAESTRUTURA', cpf: 'infra2026', role: 'infraestrutura' });
      return true;
    }
    if (cleanName === 'ORDEM DE SAIDA' && rawPass === (systemPasswords['ORDEM DE SAIDA'] || 'saida2026')) {
      setUser({ name: 'ORDEM DE SAIDA', cpf: 'saida2026', role: 'ordem_saida' });
      return true;
    }
    const julioPass = systemPasswords['SEÇÃO DE INFRAESTRUTURA E LOGÍSTICA'] || systemPasswords['JULIO CESAR NOGUEIRA'] || '431385464';
    if ((cleanName === 'SEÇÃO DE INFRAESTRUTURA E LOGÍSTICA' || cleanName === 'JULIO CESAR NOGUEIRA') && rawPass === julioPass) {
      setUser({ name: 'SEÇÃO DE INFRAESTRUTURA E LOGÍSTICA', cpf: '431385464', role: 'julio' });
      return true;
    }
    const matchProducerOrSupplier = (p: any) => {
      if (!p) return false;
      const pCpf = String(p.cpfCnpj || p.cpf || p.cnpj || '').replace(/\D/g, '');
      const pPass = String(p.password || p.senha || p.accessKey || '').trim().toLowerCase();
      const pName = String(p.name || '').trim().toUpperCase();

      if (numericPass && pCpf && pCpf === numericPass) return true;
      if (rawPass && pPass && pPass === rawPass.toLowerCase()) return true;
      if (cleanName && pName && (pName.includes(cleanName) || cleanName.includes(pName))) {
        if (numericPass && pCpf && pCpf === numericPass) return true;
        if (rawPass && pPass && pPass === rawPass.toLowerCase()) return true;
      }
      return false;
    };

    const allCandidateSuppliers = [
      ...ensureArray(perCapitaConfig.ppaisProducers),
      ...ensureArray(perCapitaConfig.pereciveisSuppliers),
      ...ensureArray(perCapitaConfig.pereciveisSuppliers1Q),
      ...ensureArray(perCapitaConfig.pereciveisSuppliers2Q),
      ...ensureArray(perCapitaConfig.pereciveisSuppliers3Q),
      ...ensureArray(perCapitaConfig.pereciveisSuppliers2027_1Q),
      ...ensureArray(perCapitaConfig.pereciveisSuppliers2027_2Q),
      ...ensureArray(perCapitaConfig.pereciveisSuppliers2027_3Q),
      ...ensureArray(perCapitaConfig.estocaveisSuppliers),
      ...ensureArray(perCapitaConfig.estocaveisSuppliers1Q),
      ...ensureArray(perCapitaConfig.estocaveisSuppliers2Q),
      ...ensureArray(perCapitaConfig.estocaveisSuppliers3Q),
      ...ensureArray(perCapitaConfig.estocaveisSuppliers2027_1Q),
      ...ensureArray(perCapitaConfig.estocaveisSuppliers2027_2Q),
      ...ensureArray(perCapitaConfig.estocaveisSuppliers2027_3Q),
      ...ensureArray(suppliers)
    ];

    const matchedSupplier = allCandidateSuppliers.find(matchProducerOrSupplier);
    if (matchedSupplier) {
      let role = 'supplier';
      const isPpais = ensureArray(perCapitaConfig.ppaisProducers).some(p => (p.cpfCnpj || p.cpf) === (matchedSupplier.cpfCnpj || matchedSupplier.cpf));
      const isPereciveis = [
        perCapitaConfig.pereciveisSuppliers,
        perCapitaConfig.pereciveisSuppliers1Q,
        perCapitaConfig.pereciveisSuppliers2Q,
        perCapitaConfig.pereciveisSuppliers3Q,
        perCapitaConfig.pereciveisSuppliers2027_1Q,
        perCapitaConfig.pereciveisSuppliers2027_2Q,
        perCapitaConfig.pereciveisSuppliers2027_3Q
      ].some(list => ensureArray(list).some(p => (p.cpfCnpj || p.cpf) === (matchedSupplier.cpfCnpj || matchedSupplier.cpf)));

      const isEstocaveis = [
        perCapitaConfig.estocaveisSuppliers,
        perCapitaConfig.estocaveisSuppliers1Q,
        perCapitaConfig.estocaveisSuppliers2Q,
        perCapitaConfig.estocaveisSuppliers3Q,
        perCapitaConfig.estocaveisSuppliers2027_1Q,
        perCapitaConfig.estocaveisSuppliers2027_2Q,
        perCapitaConfig.estocaveisSuppliers2027_3Q
      ].some(list => ensureArray(list).some(p => (p.cpfCnpj || p.cpf) === (matchedSupplier.cpfCnpj || matchedSupplier.cpf)));

      if (isPpais) role = 'producer';
      else if (isPereciveis) role = 'pereciveis_supplier';
      else if (isEstocaveis) role = 'estocaveis_supplier';

      setUser({ name: matchedSupplier.name, cpf: matchedSupplier.cpfCnpj || matchedSupplier.cpf || numericPass, role: role as any });
      return true;
    }

    if (!isSuppliersLoaded || !isPerCapitaConfigLoaded) {
      toast.info('Buscando dados no servidor...');
      try {
        const db = getDatabase(app);
        const [supSnap, perCapitaSnap] = await Promise.all([
          get(ref(db, 'suppliers')),
          get(ref(db, 'perCapitaConfig'))
        ]);
        
        let found = false;
        if (perCapitaSnap.exists()) {
          const config = perCapitaSnap.val() || {};
          const allDbSuppliers = [
            ...ensureArray(config.ppaisProducers),
            ...ensureArray(config.pereciveisSuppliers),
            ...ensureArray(config.pereciveisSuppliers1Q),
            ...ensureArray(config.pereciveisSuppliers2Q),
            ...ensureArray(config.pereciveisSuppliers3Q),
            ...ensureArray(config.pereciveisSuppliers2027_1Q),
            ...ensureArray(config.pereciveisSuppliers2027_2Q),
            ...ensureArray(config.pereciveisSuppliers2027_3Q),
            ...ensureArray(config.estocaveisSuppliers),
            ...ensureArray(config.estocaveisSuppliers1Q),
            ...ensureArray(config.estocaveisSuppliers2Q),
            ...ensureArray(config.estocaveisSuppliers3Q),
            ...ensureArray(config.estocaveisSuppliers2027_1Q),
            ...ensureArray(config.estocaveisSuppliers2027_2Q),
            ...ensureArray(config.estocaveisSuppliers2027_3Q),
            ...(supSnap.exists() ? Object.values(supSnap.val() || {}) : [])
          ];

          const dbMatched = allDbSuppliers.find(matchProducerOrSupplier);
          if (dbMatched) {
            let role = 'supplier';
            const isPpais = ensureArray(config.ppaisProducers).some(p => (p.cpfCnpj || p.cpf) === (dbMatched.cpfCnpj || dbMatched.cpf));
            const isPereciveis = [
              config.pereciveisSuppliers,
              config.pereciveisSuppliers1Q,
              config.pereciveisSuppliers2Q,
              config.pereciveisSuppliers3Q,
              config.pereciveisSuppliers2027_1Q,
              config.pereciveisSuppliers2027_2Q,
              config.pereciveisSuppliers2027_3Q
            ].some(list => ensureArray(list).some(p => (p.cpfCnpj || p.cpf) === (dbMatched.cpfCnpj || dbMatched.cpf)));

            const isEstocaveis = [
              config.estocaveisSuppliers,
              config.estocaveisSuppliers1Q,
              config.estocaveisSuppliers2Q,
              config.estocaveisSuppliers3Q,
              config.estocaveisSuppliers2027_1Q,
              config.estocaveisSuppliers2027_2Q,
              config.estocaveisSuppliers2027_3Q
            ].some(list => ensureArray(list).some(p => (p.cpfCnpj || p.cpf) === (dbMatched.cpfCnpj || dbMatched.cpf)));

            if (isPpais) role = 'producer';
            else if (isPereciveis) role = 'pereciveis_supplier';
            else if (isEstocaveis) role = 'estocaveis_supplier';

            setUser({ name: dbMatched.name, cpf: dbMatched.cpfCnpj || dbMatched.cpf || numericPass, role: role as any });
            found = true;
          }
        }
        
        if (found) return true;
      } catch (e) {
        console.error("Direct fetch failed", e);
      }
    }
    
    return false;
  };

  const handleRegisterServiceOrder = async (order: Omit<ServiceOrder, 'id'>) => {
    try {
      const newRef = push(serviceOrdersRef);
      const id = newRef.key || `so-${Date.now()}`;
      await set(newRef, { ...order, id, createdAt: order.createdAt || new Date().toISOString() });
      return { success: true, message: 'Ordem de serviço registrada com sucesso!' };
    } catch (e) {
      console.error('Erro ao registrar ordem de serviço:', e);
      return { success: false, message: 'Falha ao registrar ordem de serviço.' };
    }
  };

  const handleUpdateServiceOrder = async (order: ServiceOrder) => {
    try {
      await set(child(serviceOrdersRef, order.id), order);
      return { success: true, message: 'Ordem de serviço atualizada com sucesso!' };
    } catch (e) {
      console.error('Erro ao atualizar ordem de serviço:', e);
      return { success: false, message: 'Falha ao atualizar ordem de serviço.' };
    }
  };

  const handleDeleteServiceOrder = async (id: string) => {
    try {
      await remove(child(serviceOrdersRef, id));
      return { success: true, message: 'Ordem de serviço excluída com sucesso!' };
    } catch (e) {
      console.error('Erro ao excluir ordem de serviço:', e);
      return { success: false, message: 'Falha ao excluir ordem de serviço.' };
    }
  };

  const handleRestoreInfrastructureData = async () => {
    try {
      const officialOrders = Object.values(OFFICIAL_SERVICE_ORDERS);
      const officialSchedules = Object.values(OFFICIAL_MAINTENANCE_SCHEDULES);
      setServiceOrders(officialOrders);
      setMaintenanceSchedules(officialSchedules);
      safeLocalStorageSetItem('cached_serviceOrders', JSON.stringify(officialOrders));
      safeLocalStorageSetItem('cached_maintenanceSchedules', JSON.stringify(officialSchedules));
      if (serviceOrdersRef && maintenanceSchedulesRef) {
        await Promise.all([
          set(serviceOrdersRef, OFFICIAL_SERVICE_ORDERS),
          set(maintenanceSchedulesRef, OFFICIAL_MAINTENANCE_SCHEDULES)
        ]);
      }
      toast.success(`Gestão de Infraestrutura: ${officialOrders.length} Ordens de Serviço e ${officialSchedules.length} Cronogramas sincronizados!`);
      return { success: true, message: 'Dados sincronizados com sucesso' };
    } catch (e: any) {
      console.error('Erro ao restaurar infraestrutura:', e);
      toast.error('Erro ao conectar com servidor, dados mantidos localmente');
      return { success: false, message: e?.message || 'Erro ao sincronizar' };
    }
  };

  const handleLogout = () => setUser(null);

  const handleSavePublicInfo = async (info: Omit<PublicInfo, 'id'> & { id?: string }) => {
    try {
      const id = info.id || (publicInfoRef ? push(publicInfoRef).key : null) || `info-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
      if (!id) throw new Error('Falha ao gerar ID');
      const itemToSave: PublicInfo = {
        id,
        sector: (info.sector || 'GERAL').trim().toUpperCase(),
        title: (info.title || '').trim(),
        content: (info.content || '').trim(),
        imageUrl: info.imageUrl || '',
        updatedAt: info.updatedAt || new Date().toISOString(),
        date: info.date || new Date().toISOString().split('T')[0],
        isConfidential: Boolean(info.isConfidential)
      };
      
      // Update local state immediately (Optimistic update)
      setPublicInfo(prev => {
        const existingIdx = prev.findIndex(item => item.id === id);
        let updatedList: PublicInfo[];
        if (existingIdx >= 0) {
          updatedList = [...prev];
          updatedList[existingIdx] = itemToSave;
        } else {
          updatedList = [itemToSave, ...prev];
        }
        updatedList.sort((a, b) => new Date(b.updatedAt || b.date || 0).getTime() - new Date(a.updatedAt || a.date || 0).getTime());
        safeLocalStorageSetItem('cached_publicInfo', JSON.stringify(updatedList));
        return updatedList;
      });

      if (database && publicInfoRef) {
        try {
          const savePromise = set(child(publicInfoRef, id), itemToSave);
          const timeoutPromise = new Promise(resolve => setTimeout(resolve, 3000));
          await Promise.race([savePromise, timeoutPromise]);
        } catch (dbErr) {
          console.warn('Sincronização Firebase Realtime com timeout ou erro, salvo localmente:', dbErr);
        }
      }
      toast.success('Informação pública salva com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar informação pública:', error);
      toast.error('Erro ao salvar informação pública.');
    }
  };

  const handleDeletePublicInfo = async (id: string) => {
    try {
      setPublicInfo(prev => {
        const updatedList = prev.filter(item => item.id !== id);
        safeLocalStorageSetItem('cached_publicInfo', JSON.stringify(updatedList));
        return updatedList;
      });

      if (database && publicInfoRef) {
        try {
          const removePromise = remove(child(publicInfoRef, id));
          const timeoutPromise = new Promise(resolve => setTimeout(resolve, 3000));
          await Promise.race([removePromise, timeoutPromise]);
        } catch (dbErr) {
          console.warn('Remoção Firebase Realtime com timeout ou erro, removido localmente:', dbErr);
        }
      }
      toast.success('Informação pública removida com sucesso!');
    } catch (error) {
      console.error('Erro ao remover informação pública:', error);
      toast.error('Erro ao remover informação pública.');
    }
  };

  const handleRestoreFullBackup = async (fullData: any) => {
    try {
        await set(rootRef, fullData);
        return true;
    } catch (e) {
        console.error("Erro na restauração:", e);
        return false;
    }
  };

  const handleSyncPPAISToAgenda = async (overrideConfig?: PerCapitaConfig) => {
    const configToUse = overrideConfig || perCapitaConfig;
    const producers = ensureArray(configToUse?.ppaisProducers);
    const pereciveis = [
      ...ensureArray(configToUse?.pereciveisSuppliers),
      ...ensureArray(configToUse?.pereciveisSuppliers1Q),
      ...ensureArray(configToUse?.pereciveisSuppliers2Q),
      ...ensureArray(configToUse?.pereciveisSuppliers3Q),
      ...ensureArray(configToUse?.pereciveisSuppliers2027_1Q),
      ...ensureArray(configToUse?.pereciveisSuppliers2027_2Q),
      ...ensureArray(configToUse?.pereciveisSuppliers2027_3Q),
    ];
    const estocaveis = [
      ...ensureArray(configToUse?.estocaveisSuppliers),
      ...ensureArray(configToUse?.estocaveisSuppliers1Q),
      ...ensureArray(configToUse?.estocaveisSuppliers2Q),
      ...ensureArray(configToUse?.estocaveisSuppliers3Q),
      ...ensureArray(configToUse?.estocaveisSuppliers2027_1Q),
      ...ensureArray(configToUse?.estocaveisSuppliers2027_2Q),
      ...ensureArray(configToUse?.estocaveisSuppliers2027_3Q),
    ];
    const allPerCapita = [...producers, ...pereciveis, ...estocaveis].filter(Boolean);

    if (allPerCapita.length === 0) {
      return;
    }

    try {
      // Get all current suppliers to handle the "not registered" ones
      const suppliersSnapshot = await get(suppliersRef);
      const allSuppliers = suppliersSnapshot.val() || {};

      for (const entry of allPerCapita) {
        if (!entry) continue;
        const entryCpf = String(entry.cpfCnpj || entry.cpf || '').trim();
        if (!entryCpf) continue;

        // Calculate weeks for the entire year (Jan-Dec) to keep both contracts independent
        const uniqueNewWeeks = calculateAllowedWeeksFromSchedule(entry.monthlySchedule, 2026);

        const supplierRef = child(suppliersRef, entryCpf);
        const existingSupplier = allSuppliers[entryCpf] as Supplier | null;

        if (existingSupplier) {
          // Merge Q1 and Q2/Q3 data to keep them independent but accessible
          const q1Weeks = (existingSupplier.allowedWeeks || []).filter(w => w <= 18);
          const updatedWeeks = Array.from(new Set([...q1Weeks, ...uniqueNewWeeks])).sort((a, b) => a - b);
          
          // REMOVE contractItems sync to decouple PPAIS from main agenda
          // We only keep the Q1 items in the main list
          const q1Items = (existingSupplier.contractItems || []).filter(item => item.period !== '2_3_QUAD');

          await update(supplierRef, { 
            allowedWeeks: updatedWeeks,
            contractItems: q1Items,
            // Update initialValue to reflect only Q1 items in the main list
            initialValue: q1Items.reduce((acc, curr) => acc + (Number(curr.totalKg || 0) * Number(curr.valuePerKg || 0)), 0)
          });
        } else {
          // New entry - only sync weeks, no items in the main list
          const newSupplier: Supplier = {
            name: entry.name || '',
            cpf: entryCpf,
            initialValue: 0,
            contractItems: [], // Keep empty in main list
            deliveries: [],
            allowedWeeks: uniqueNewWeeks,
            address: entry.address || '',
            city: entry.city || '',
            processNumber: entry.processNumber || ''
          };
          await set(supplierRef, newSupplier);
        }
      }

      // Handle non-registered suppliers
      // "para os demais fornecedores que não possuem cadastro, deixar os campos de maio a dezembro com 0 no peso e 0 no valor."
      for (const cpf in allSuppliers) {
        if (!registeredCpfs.has(cpf)) {
          const supplier = allSuppliers[cpf] as Supplier;
          const supplierRef = child(suppliersRef, cpf);
          
          // Remove weeks that are no longer valid (e.g., if contract period changed)
          // For now, keep weeks that are > 18 if they were already there implicitly
          const updatedWeeks = (supplier.allowedWeeks || []);
          
          // Remove Q2/Q3 items and tag legacy items as Q1 only to ensure they don't show in Q2/Q3
          const updatedItems = (supplier.contractItems || [])
            .filter(item => item.period !== '2_3_QUAD')
            .map(item => ({
              ...item,
              period: (item.period || '1_QUAD') as '1_QUAD' | '2_3_QUAD'
            }));
          
          // Update if changed
          if (updatedWeeks.length !== (supplier.allowedWeeks || []).length || updatedItems.length !== (supplier.contractItems || []).length) {
             await update(supplierRef, {
               allowedWeeks: updatedWeeks,
               contractItems: updatedItems,
               initialValue: updatedItems.reduce((acc, curr) => acc + (Number(curr.totalKg || 0) * Number(curr.valuePerKg || 0)), 0)
             });
          }
        }
      }

      toast.success('Agenda sincronizada com sucesso!');
    } catch (error) {
      console.error('Erro ao sincronizar agenda:', error);
      toast.error('Erro ao sincronizar agenda.');
    }
  };

  const handleUpdatePerCapitaConfig = async (newConfig: Partial<PerCapitaConfig>) => {
    try {
      console.log('Tentando atualizar PerCapitaConfig...', newConfig);
      // Atualiza o estado em memória e localStorage imediatamente para resposta instantânea (0ms)
      setPerCapitaConfig(prev => {
        const merged = { ...prev, ...newConfig };
        safeLocalStorageSetItem('cached_perCapitaConfig', JSON.stringify(merged));
        return merged;
      });

      const updatePromises = Object.entries(newConfig).map(([key, value]) => {
        if (value !== undefined) {
          return set(child(perCapitaConfigRef, key), value);
        }
        return Promise.resolve();
      });
      await Promise.all(updatePromises);
      return { success: true };
    } catch (e) {
      console.error('Erro ao atualizar PerCapitaConfig:', e);
      return { 
        success: false, 
        message: e instanceof Error ? e.message : String(e) 
      };
    }
  };

  const handleRegisterSupplier = async (name: string, cpf: string, allowedWeeks: number[]) => {
    try {
      console.log('Tentando registrar fornecedor:', { name, cpf, allowedWeeks });
      const newSupplier: Supplier = {
        name,
        cpf,
        initialValue: 0,
        contractItems: [],
        deliveries: [],
        allowedWeeks
      };
      await set(child(suppliersRef, cpf), newSupplier);
      console.log('Fornecedor registrado com sucesso!');
    } catch (error) {
      console.error('Erro ao registrar fornecedor:', error);
      throw error;
    }
  };

  const handleUpdateSupplier = async (oldCpf: string, newName: string, newCpf: string, newAllowedWeeks: number[]) => {
    try {
      console.log('Tentando atualizar fornecedor:', { oldCpf, newName, newCpf, newAllowedWeeks });
      const supplierRef = child(suppliersRef, oldCpf);
      const existingSupplier = suppliers.find(s => s.cpf === oldCpf);

      await safeRunTransaction(supplierRef, (currentData: Supplier) => {
        if (currentData) {
          currentData.name = newName;
          currentData.cpf = newCpf;
          currentData.allowedWeeks = newAllowedWeeks;
          return sanitizeForFirebase(currentData);
        }
        return currentData;
      }, existingSupplier || null);

      if (oldCpf !== newCpf) {
        const snapshot = await get(child(suppliersRef, oldCpf));
        const oldData = snapshot.val();
        if (oldData) {
          await set(child(suppliersRef, newCpf), sanitizeForFirebase(oldData));
          await remove(child(suppliersRef, oldCpf));
        }
      }
      console.log('Fornecedor atualizado com sucesso!');
      return null;
    } catch (error) {
      console.error('Erro ao atualizar fornecedor:', error);
      return 'Erro ao atualizar fornecedor: ' + (error instanceof Error ? error.message : String(error));
    }
  };

  const handleUpdateSupplierObservations = async (cpf: string, observations: string) => {
    try {
      const supplierRef = child(suppliersRef, cpf);
      await update(supplierRef, { observations });
      return { success: true };
    } catch (error) {
      console.error('Erro ao atualizar observações do fornecedor:', error);
      return { success: false, message: String(error) };
    }
  };

  const handleScheduleDelivery = useCallback(async (supplierCpf: string, date: string, time: string, observations?: string) => {
    try {
      console.log('Agendando entrega:', { supplierCpf, date, time, observations });
      const cleanDigits = (s: any) => String(s || '').replace(/\D/g, '');
      const match = (a: any, b: any) => {
        const da = cleanDigits(a);
        const db = cleanDigits(b);
        if (!da || !db) return false;
        if (da === db) return true;
        if (da.length === 11 && db.length === 14 && db.startsWith(da)) return true;
        if (db.length === 11 && da.length === 14 && da.startsWith(db)) return true;
        const noZeroA = da.replace(/^0+/, '');
        const noZeroB = db.replace(/^0+/, '');
        if (noZeroA && noZeroB && noZeroA === noZeroB) return true;
        return false;
      };
      const targetCpf = supplierCpf;

      // Verify if there is already a delivery in the same week
      const dateParts = date.split('-');
      if (dateParts.length === 3) {
        const targetDateObj = new Date(parseInt(dateParts[0]), parseInt(dateParts[1]) - 1, parseInt(dateParts[2]));
        const _targetWeekNum = getWeekNumber(targetDateObj);

        // Get all existing deliveries for this CPF across both main suppliers list and perCapita lists
        let existingDeliveries: any[] = [];
        
        // 1. Standard supplier
        const mainSupplier = (suppliers || []).find(s => s && match(s.cpf, targetCpf));
        if (mainSupplier && mainSupplier.deliveries) {
          existingDeliveries = Array.isArray(mainSupplier.deliveries) 
            ? mainSupplier.deliveries 
            : Object.values(mainSupplier.deliveries);
        }

        // 2. Per Capita lists
        if (perCapitaConfig) {
          const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
          for (const listKey of lists) {
            const list = ensureArray(perCapitaConfig[listKey]);
            const p = list.find((item: any) => item && match(item.cpfCnpj || item.cpf, targetCpf));
            if (p && p.deliveries) {
              const pDeliveries = Array.isArray(p.deliveries) ? p.deliveries : Object.values(p.deliveries);
              existingDeliveries = [...existingDeliveries, ...pDeliveries];
            }
          }
        }

        // 3. Check if any delivery is on the exact same date and time
        const alreadyHasOnDateTime = existingDeliveries.some((d: any) => {
          if (!d || !d.date) return false;
          return d.date === date && d.time === time;
        });

        if (alreadyHasOnDateTime) {
          toast.error(`Agendamento bloqueado: Já existe uma entrega agendada para este fornecedor em ${date} às ${time}.`);
          return;
        }
      }

      let scheduleSuccess = false;
      const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];

      // 1. Try Per Capita FIRST to prioritize Per Capita mappings
      if (perCapitaConfig) {
        for (const listKey of lists) {
          const producers = ensureArray(perCapitaConfig[listKey]);
          const idx = producers.findIndex((p: any) => p && match(p.cpfCnpj || p.cpf, targetCpf));
          if (idx !== -1) {
            const deliveriesRef = child(perCapitaConfigRef, `${listKey}/${idx}/deliveries`);
            let isDuplicateTransaction = false;
            const newId = `manual-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
            const newDelivery = sanitizeForFirebase({
              id: newId,
              date: String(date || ''),
              time: String(time || ''),
              item: 'AGENDAMENTO PENDENTE',
              invoiceUploaded: false,
              observations: observations ? String(observations) : ''
            });

            await safeRunTransaction(deliveriesRef, (current) => {
              const list = ensureArray<any>(current)
                .filter(d => d && typeof d === 'object' && (d.date || d.id))
                .map(d => sanitizeForFirebase(d));
              const hasDuplicate = list.some(d => d && d.date === date && d.time === time);
              if (hasDuplicate) {
                isDuplicateTransaction = true;
                return current;
              }
              return sanitizeForFirebase([...list, newDelivery]);
            }, producers[idx]?.deliveries || []);
            
            if (isDuplicateTransaction) {
              toast.error(`Agendamento já existente para este fornecedor em ${date} às ${time}.`);
              return;
            }
            scheduleSuccess = true;
            break;
          }
        }
      }

      // 2. Try Main Suppliers
      if (!scheduleSuccess) {
        const mainSupplier = (suppliers || []).find(s => s && match(s.cpf, targetCpf));
        if (mainSupplier) {
          console.log('Found main supplier:', mainSupplier);
          const refId = mainSupplier.id || targetCpf;
          if (!refId) {
              throw new Error('Supplier ID not found');
          }
          const deliveriesRef = child(suppliersRef, `${refId}/deliveries`);
          let isDuplicateTransaction = false;
          const newId = `manual-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
          const newDelivery = sanitizeForFirebase({
            id: newId,
            date: String(date || ''),
            time: String(time || ''),
            item: 'AGENDAMENTO PENDENTE',
            invoiceUploaded: false,
            observations: observations ? String(observations) : ''
          });

          await safeRunTransaction(deliveriesRef, (current) => {
            const list = ensureArray<any>(current)
              .filter(d => d && typeof d === 'object' && (d.date || d.id))
              .map(d => sanitizeForFirebase(d));
            const hasDuplicate = list.some(d => d && d.date === date && d.time === time);
            if (hasDuplicate) {
              isDuplicateTransaction = true;
              return current;
            }
            return sanitizeForFirebase([...list, newDelivery]);
          }, mainSupplier?.deliveries || []);

          if (isDuplicateTransaction) {
            toast.error(`Agendamento já existente para este fornecedor em ${date} às ${time}.`);
            return;
          }
          scheduleSuccess = true;
        }
      }

      if (scheduleSuccess) {
        toast.success('Agendamento realizado com sucesso!');
        return;
      }

      toast.error('Fornecedor não encontrado para agendar.');
    } catch (error) {
      console.error('Erro ao agendar entrega:', error);
      toast.error(`Erro ao agendar entrega: ${error instanceof Error ? error.message : String(error)}`);
    }
  }, [suppliers, perCapitaConfig]);

  const handleUpdateInvoiceUrl = useCallback(async (supplierCpf: string, invoiceNumber: string, finalInvoiceUrl: string) => {
    try {
      const clean = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
      const targetCpf = clean(supplierCpf);
      const targetInv = clean(invoiceNumber);

      const fetchWithTimeout = async (dbRef: any) => {
          const fetchPromise = get(dbRef);
          const timeout = new Promise<any>((_, reject) => setTimeout(() => reject(new Error("Timeout ao ler banco de dados")), 30000));
          return Promise.race([fetchPromise, timeout]);
      };

      let anyUpdated = false;

      // 1. Check in PerCapita
      const snapshotPC = await fetchWithTimeout(perCapitaConfigRef);
      const currentPC = snapshotPC.val() as PerCapitaConfig;
      if (currentPC) {
        const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
        for (const lKey of lists) {
          const list = ensureArray(currentPC[lKey]);
          const idx = list.findIndex(p => clean(p.cpfCnpj || p.cpf) === targetCpf);
          if (idx !== -1) {
            const deliveries = ensureArray(list[idx].deliveries);
            let updatedAny = false;
            const updatedDeliveries = deliveries.map((d: any) => {
              if (clean(d.invoiceNumber) === targetInv) {
                updatedAny = true;
                return { ...d, invoiceUrl: finalInvoiceUrl };
              }
              return d;
            });
            if (updatedAny) {
              await update(child(perCapitaConfigRef, `${lKey}/${idx}`), { deliveries: updatedDeliveries });
              anyUpdated = true;
            }
          }
        }
      }

      // 2. Check in Main Suppliers
      const mainSupplier = (suppliers || []).find(s => s && clean(s.cpf) === targetCpf);
      if (mainSupplier) {
        const supRef = child(suppliersRef, mainSupplier.id || targetCpf);
        const snapshotSup = await fetchWithTimeout(supRef);
        const data = snapshotSup.val() as Supplier;
        if (data && data.deliveries) {
          let updatedAny = false;
          const deliveries = data.deliveries.map(d => {
            if (clean(d.invoiceNumber) === targetInv) {
              updatedAny = true;
              return { ...d, invoiceUrl: finalInvoiceUrl };
            }
            return d;
          });
          if (updatedAny) {
            await update(supRef, { deliveries });
            anyUpdated = true;
          }
        }
      }

      // 3. Check and update in warehouseLog
      const snapshotLog = await fetchWithTimeout(warehouseLogRef);
      const currentLog = snapshotLog.val();
      if (currentLog) {
        const logUpdates: Record<string, any> = {};
        let logUpdatedAny = false;
        Object.entries(currentLog).forEach(([key, record]: [string, any]) => {
          if (record && clean(record.supplierCpf) === targetCpf && clean(record.invoiceNumber || record.inboundInvoice || record.outboundInvoice) === targetInv) {
            logUpdates[`${key}/invoiceUrl`] = finalInvoiceUrl;
            logUpdatedAny = true;
          }
        });
        if (logUpdatedAny) {
          await update(warehouseLogRef, logUpdates);
          anyUpdated = true;
        }
      }

      if (anyUpdated) {
        return { success: true };
      }

      return { success: false, message: 'Dados do fornecedor não encontrados nos cadastros ou nenhuma entrega correspondente.' };
    } catch (e) {
      console.error("Error updating supplier invoice URL:", e);
      return { success: false, message: 'Erro interno ao atualizar nota.' };
    }
  }, [suppliers]);



  const handleMarkInvoiceAsOpened = useCallback(async (supplierCpf: string, invoiceNumber: string) => {
    try {
      const clean = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
      const targetCpf = clean(supplierCpf);
      const targetInv = clean(invoiceNumber);

      // 1. Try PerCapita
      await safeRunTransaction(perCapitaConfigRef, (currentData: PerCapitaConfig) => {
        if (currentData) {
          const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
          for (const lKey of lists) {
            const list = ensureArray(currentData[lKey]);
            const idx = list.findIndex(p => clean(p.cpfCnpj || p.cpf) === targetCpf);
            if (idx !== -1) {
              const deliveries = ensureArray(list[idx].deliveries);
              let changed = false;
              const updated = deliveries.map(d => {
                if (clean(d.invoiceNumber) === targetInv && !d.isOpened) {
                  changed = true;
                  return { ...d, isOpened: true };
                }
                return d;
              });
              if (changed) {
                list[idx].deliveries = sanitizeForFirebase(updated);
                return sanitizeForFirebase(currentData);
              }
            }
          }
        }
        return currentData;
      }, perCapitaConfig);

      // 2. Try Main Suppliers
      const mainSupplier = (suppliers || []).find(s => s && clean(s.cpf) === targetCpf);
      if (mainSupplier) {
        const supRef = child(suppliersRef, `${mainSupplier.id || targetCpf}/deliveries`);
        await safeRunTransaction(supRef, (currentDeliveries) => {
          const list = ensureArray<any>(currentDeliveries);
          let changed = false;
          const updated = list.map(d => {
            if (clean(d.invoiceNumber) === targetInv && !d.isOpened) {
              changed = true;
              return { ...d, isOpened: true };
            }
            return d;
          });
          if (changed) return sanitizeForFirebase(updated);
          return currentDeliveries;
        }, mainSupplier.deliveries || []);
      }

      return { success: true };
    } catch (e) {
      console.error("Error marking invoice as opened:", e);
      return { success: false, message: 'Erro ao marcar nota como aberta.' };
    }
  }, [suppliers, perCapitaConfig]);

  const handleDeleteDelivery = async (supplierCpf: string, deliveryId: string) => {
    try {
      const clean = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
      const match = (a: any, b: any) => {
        const ca = clean(a);
        const cb = clean(b);
        if (!ca || !cb) return false;
        return ca === cb || (ca.length === 11 && cb.length === 14 && cb.startsWith(ca)) || (cb.length === 11 && ca.length === 14 && ca.startsWith(cb));
      };
      const targetCpf = clean(supplierCpf);

      // 1. Clean up warehouseLog first if there's a matching entry
      const logSnapshot = await get(warehouseLogRef);
      const allLogs = logSnapshot.val() || {};
      const logKeysToDelete = Object.keys(allLogs).filter(key => {
          const entry = allLogs[key];
          return match(entry.supplierCpf, targetCpf) && (entry.deliveryId === deliveryId || entry.id === deliveryId);
      });

      if (logKeysToDelete.length > 0) {
          await Promise.all(logKeysToDelete.map(key => remove(child(warehouseLogRef, key))));
      }

      // 2. Try Per Capita FIRST
      const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
      for (const listKey of lists) {
        const list = ensureArray(perCapitaConfig[listKey]);
        const idx = list.findIndex((p: any) => p && match(p.cpfCnpj || p.cpf, targetCpf));
        if (idx !== -1) {
          const p = list[idx];
          const pDeliveries = Array.isArray(p.deliveries) ? p.deliveries : Object.values(p.deliveries || {});
          if (pDeliveries.some((d: any) => d && d.id === deliveryId)) {
            const deliveriesRef = child(perCapitaConfigRef, `${listKey}/${idx}/deliveries`);
            await safeRunTransaction(deliveriesRef, (current) => {
              const list = ensureArray<any>(current).filter(d => d && typeof d === 'object' && d.id !== deliveryId);
              return sanitizeForFirebase(list);
            }, pDeliveries);
            return { success: true };
          }
        }
      }

      // 3. Try Main Suppliers
      const mainSupplier = (suppliers || []).find(s => s && match(s.cpf, targetCpf));
      if (mainSupplier) {
        const mDeliveries = Array.isArray(mainSupplier.deliveries) ? mainSupplier.deliveries : Object.values(mainSupplier.deliveries || {});
        if (mDeliveries.some((d: any) => d && d.id === deliveryId)) {
          const deliveriesRef = child(suppliersRef, `${mainSupplier.id || targetCpf}/deliveries`);
          await safeRunTransaction(deliveriesRef, (current) => {
            const list = ensureArray<any>(current).filter(d => d && typeof d === 'object' && d.id !== deliveryId);
            return sanitizeForFirebase(list);
          }, mDeliveries);
          return { success: true };
        }
      }

      return { success: false, message: 'Lançamento não encontrado.' };
    } catch (e) {
      console.error("Error deleting delivery:", e);
      return { success: false, message: 'Erro ao excluir lançamento.' };
    }
  };

  const handleUpdateDelivery = async (supplierCpf: string, deliveryId: string, updates: Partial<Delivery>) => {
    try {
      const clean = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
      const match = (a: any, b: any) => {
        const ca = clean(a);
        const cb = clean(b);
        if (!ca || !cb) return false;
        return ca === cb || (ca.length === 11 && cb.length === 14 && cb.startsWith(ca)) || (cb.length === 11 && ca.length === 14 && ca.startsWith(cb));
      };
      const targetCpf = clean(supplierCpf);

      // 1. Try Per Capita FIRST
      const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
      for (const listKey of lists) {
        const list = ensureArray(perCapitaConfig[listKey]);
        const idx = list.findIndex((p: any) => p && match(p.cpfCnpj || p.cpf, targetCpf));
        if (idx !== -1) {
          const p = list[idx];
          const pDeliveries = Array.isArray(p.deliveries) ? p.deliveries : Object.values(p.deliveries || {});
          const hasMatch = pDeliveries.some((d: any, dIdx: number) => {
            if (!d) return false;
            const dId = d.id || `arr-idx-${dIdx}`;
            return dId === deliveryId || String(dIdx) === deliveryId;
          });
          if (hasMatch) {
            const deliveriesRef = child(perCapitaConfigRef, `${listKey}/${idx}/deliveries`);
            await safeRunTransaction(deliveriesRef, (current) => {
              const currentList = ensureArray<any>(current);
              const updated = currentList.map((d, dIdx) => {
                if (!d) return d;
                const dId = d.id || `arr-idx-${dIdx}`;
                if (dId === deliveryId || `arr-idx-${dIdx}` === deliveryId || String(dIdx) === deliveryId) {
                  return { ...d, ...updates, id: d.id || `arr-idx-${dIdx}` };
                }
                return d;
              });
              return sanitizeForFirebase(updated);
            }, pDeliveries);
            return { success: true };
          }
        }
      }

      // 2. Try Main Suppliers
      const mainSupplier = (suppliers || []).find(s => s && match(s.cpf, targetCpf));
      if (mainSupplier) {
        const mDeliveries = Array.isArray(mainSupplier.deliveries) ? mainSupplier.deliveries : Object.values(mainSupplier.deliveries || {});
        const hasMatch = mDeliveries.some((d: any, dIdx: number) => {
          if (!d) return false;
          const dId = d.id || `arr-idx-${dIdx}`;
          return dId === deliveryId || String(dIdx) === deliveryId;
        });
        if (hasMatch) {
          const supRef = child(suppliersRef, mainSupplier.id || targetCpf);
          const deliveriesRef = child(supRef, `deliveries`);
          await safeRunTransaction(deliveriesRef, (current) => {
            const currentList = ensureArray<any>(current);
            const updated = currentList.map((d, dIdx) => {
              if (!d) return d;
              const dId = d.id || `arr-idx-${dIdx}`;
              if (dId === deliveryId || `arr-idx-${dIdx}` === deliveryId || String(dIdx) === deliveryId) {
                return { ...d, ...updates, id: d.id || `arr-idx-${dIdx}` };
              }
              return d;
            });
            return sanitizeForFirebase(updated);
          }, mDeliveries);
          return { success: true };
        }
      }
      return { success: false, message: 'Lançamento não encontrado.' };
    } catch (e) {
      console.error("Error updating delivery:", e);
      return { success: false, message: 'Erro ao atualizar lançamento.' };
    }
  };

  const handleSaveInvoice = async (supplierCpf: string, deliveryIds: string[], invoiceNumber: string, invoiceUrl: string, updatedDeliveries: Delivery[], invoiceDate?: string): Promise<void> => {
    try {
      const clean = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
      const match = (a: any, b: any) => {
        const ca = clean(a);
        const cb = clean(b);
        if (!ca || !cb) return false;
        return ca === cb || (ca.length === 11 && cb.length === 14 && cb.startsWith(ca)) || (cb.length === 11 && ca.length === 14 && ca.startsWith(cb));
      };
      const targetCpf = clean(supplierCpf);

      const enrichedDeliveries = updatedDeliveries.map(d => ({
        ...d,
        invoiceNumber,
        invoiceUrl,
        invoiceDate: invoiceDate || d.invoiceDate || d.date || new Date().toISOString().split('T')[0],
        date: d.date || invoiceDate || new Date().toISOString().split('T')[0],
        invoiceUploaded: true,
        status: 'CONCLUÍDO',
        updatedAt: new Date().toISOString()
      }));

      // Find Main Supplier or Per Capita Info
      const mainSupplier = (suppliers || []).find(s => s && match(s.cpf, targetCpf));
      let pcSup = null;
      const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
      for (const listKey of lists) {
        const producers = ensureArray(perCapitaConfig[listKey]);
        const found = producers.find((p: any) => p && (match(p.cpfCnpj, targetCpf) || match(p.cpf, targetCpf)));
        if (found) {
          pcSup = found;
          break;
        }
      }

      let saveSuccess = false;

      // 1. Try Per Capita FIRST to prioritize Per Capita mappings
      for (const listKey of lists) {
        const producers = ensureArray(perCapitaConfig[listKey]);
        const idx = producers.findIndex((p: any) => p && (match(p.cpfCnpj, targetCpf) || match(p.cpf, targetCpf)));
        if (idx !== -1) {
          const deliveriesRef = child(perCapitaConfigRef, `${listKey}/${idx}/deliveries`);
          await safeRunTransaction(deliveriesRef, (current) => {
            const list = ensureArray<any>(current)
              .filter(d => d && typeof d === 'object')
              .map(d => sanitizeForFirebase(d));
            const otherDeliveries = list.filter(d => d && !deliveryIds.includes(d.id));
            return sanitizeForFirebase([...otherDeliveries, ...enrichedDeliveries]);
          }, producers[idx]?.deliveries || []);
          saveSuccess = true;
          break;
        }
      }

      // 2. Try Main Suppliers
      if (!saveSuccess && mainSupplier) {
        const deliveriesRef = child(suppliersRef, `${mainSupplier.id || targetCpf}/deliveries`);
        await safeRunTransaction(deliveriesRef, (current) => {
          const list = ensureArray<any>(current)
            .filter(d => d && typeof d === 'object')
            .map(d => sanitizeForFirebase(d));
          const otherDeliveries = list.filter(d => d && !deliveryIds.includes(d.id));
          return sanitizeForFirebase([...otherDeliveries, ...enrichedDeliveries]);
        }, mainSupplier?.deliveries || []);
        saveSuccess = true;
      }

      if (saveSuccess) {
        // 3. Synchronize with warehouseLog if there are matching entries
        if (database && navigator.onLine) {
          try {
            const logSnapshot = await get(warehouseLogRef);
            const allLogs = logSnapshot.val() || {};
            const targetInvoice = clean(invoiceNumber);
            const existingLogsForKey: Record<string, any> = {};
            
            Object.keys(allLogs).forEach(key => {
              const entry = allLogs[key];
              const entryInv = clean(entry.inboundInvoice || entry.outboundInvoice || entry.invoiceNumber || '');
              const entryCpf = clean(entry.supplierCpf || '');
              if (entryCpf === targetCpf && entryInv === targetInvoice) {
                existingLogsForKey[key] = entry;
              }
            });

            const logUpdates: any = {};
            const usedLogKeys = new Set<string>();

            for (const item of updatedDeliveries) {
              const itName = clean(item.item || item.itemName || '');
              const logKey = Object.keys(existingLogsForKey).length > 0 ? Object.keys(existingLogsForKey).find(k => {
                if (usedLogKeys.has(k)) return false;
                const logEntry = existingLogsForKey[k];
                const logName = clean(logEntry.itemName || logEntry.item || '');
                if (item.id && logEntry.id && item.id === logEntry.id) return true;
                if (item.id && logEntry.deliveryId && item.id === logEntry.deliveryId) return true;
                return itName === logName;
              }) : null;

              if (logKey) {
                usedLogKeys.add(logKey);
                logUpdates[`${logKey}/itemName`] = item.item || item.itemName;
                logUpdates[`${logKey}/item`] = item.item || item.itemName;
                logUpdates[`${logKey}/quantity`] = Number(item.kg) || 0;
                logUpdates[`${logKey}/kg`] = Number(item.kg) || 0;
                logUpdates[`${logKey}/value`] = Number(item.value) || 0;
              } else {
                const newRef = push(warehouseLogRef);
                const newId = newRef.key || `it-${Date.now()}`;
                logUpdates[newId] = {
                  id: newId,
                  type: 'entrada',
                  timestamp: new Date().toISOString(),
                  date: invoiceDate || new Date().toISOString().split('T')[0],
                  itemName: item.item || item.itemName,
                  supplierName: mainSupplier?.name || pcSup?.name || 'FORNECEDOR',
                  supplierCpf: supplierCpf,
                  invoiceNumber: invoiceNumber,
                  inboundInvoice: invoiceNumber,
                  quantity: Number(item.kg) || 0,
                  kg: Number(item.kg) || 0,
                  value: Number(item.value) || 0,
                  lotNumber: 'UNICO',
                  expirationDate: item.expirationDate || '',
                  barcode: item.barcode || ''
                };
              }
            }

            // Remove logs that are no longer present in the updated deliveries (only if we had existing logs)
            if (Object.keys(existingLogsForKey).length > 0) {
              Object.keys(existingLogsForKey).forEach(k => {
                if (!usedLogKeys.has(k)) {
                  logUpdates[k] = null;
                }
              });
            }

            if (Object.keys(logUpdates).length > 0) {
              await update(warehouseLogRef, logUpdates);
            }
          } catch (err) {
            console.warn("Error synchronizing warehouseLog:", err);
          }
        }

        toast.success('Nota Fiscal salva com sucesso!');
        return;
      }

      toast.error('Fornecedor não encontrado para salvar nota.');
    } catch (e) {
      console.error("Error saving invoice:", e);
      toast.error('Erro ao salvar nota fiscal.');
    }
  };

  const handleCancelDeliveries = useCallback(async (supplierCpf: string, deliveryIds: string[]) => {
    try {
      const cleanDigits = (s: any) => String(s || '').replace(/\D/g, '');
      const match = (a: any, b: any) => {
        const da = cleanDigits(a);
        const db = cleanDigits(b);
        if (!da || !db) return false;
        if (da === db) return true;
        if (da.length === 11 && db.length === 14 && db.startsWith(da)) return true;
        if (db.length === 11 && da.length === 14 && da.startsWith(db)) return true;
        const noZeroA = da.replace(/^0+/, '');
        const noZeroB = db.replace(/^0+/, '');
        if (noZeroA && noZeroB && noZeroA === noZeroB) return true;
        return false;
      };
      const targetCpf = supplierCpf;
      
      const updates: any = {};

      // 1. Delete from Per Capita
      const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
      for (const listKey of lists) {
        const producers = ensureArray(perCapitaConfig[listKey]);
        const idx = producers.findIndex((p: any) => p && match(p.cpfCnpj || p.cpf, targetCpf));
        if (idx !== -1) {
          const p = producers[idx];
          if (p && p.deliveries) {
            const rawDeliveries = ensureArray<any>(p.deliveries).filter(d => d && typeof d === 'object');
            const filtered = rawDeliveries.filter(d => d && !deliveryIds.includes(d.id));
            if (filtered.length !== rawDeliveries.length) {
              updates[`perCapitaConfig/${listKey}/${idx}/deliveries`] = sanitizeForFirebase(filtered);
            }
          }
        }
      }

      // 2. Delete from Main Suppliers
      const mainSupplier = (suppliers || []).find(s => s && match(s.cpf, targetCpf));
      if (mainSupplier && mainSupplier.deliveries) {
        const rawDeliveries = ensureArray<any>(mainSupplier.deliveries).filter(d => d && typeof d === 'object');
        const filtered = rawDeliveries.filter(d => d && !deliveryIds.includes(d.id));
        if (filtered.length !== rawDeliveries.length) {
          updates[`suppliers/${mainSupplier.id || targetCpf}/deliveries`] = sanitizeForFirebase(filtered);
        }
      }
      if (Object.keys(updates).length > 0) {
        await update(ref(database), updates);
        toast.success('Agendamentos excluídos.');
      } else {
        toast.error('Não foi possível encontrar os agendamentos para exclusão.');
      }
    } catch (error) {
      console.error('Erro ao cancelar entregas:', error);
      toast.error('Erro ao cancelar entregas.');
    }
  }, [suppliers, perCapitaConfig]);

  const handleUpdateInvoiceItems = async (supplierCpf: string, invoiceNumber: string, items: any[], barcode?: string, newInvoiceNumber?: string, newDate?: string, receiptTermNumber?: string, invoiceDate?: string, pd?: string, supplierNameHint?: string, ne?: string): Promise<{ success: boolean; message?: string }> => {
    try {
      console.log('handleUpdateInvoiceItems:', { supplierCpf, invoiceNumber, itemsCount: items.length });
      
      const clean = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
      const targetInvoice = clean(invoiceNumber);
      const targetCpf = clean(supplierCpf);

      let supplierName = supplierNameHint || '';
      const targetNameClean = clean(supplierName);
      
      let mainSup = null;
      let pcSup = null;

      const findSup = (s: any) => {
          if (!s) return false;
          const sCpf = clean(s.cpf || s.cpfCnpj);
          if (targetCpf && sCpf === targetCpf) return true;
          if (targetNameClean && clean(s.name) === targetNameClean) return true;
          return false;
      };

      mainSup = (suppliers || []).find(findSup);
      if (mainSup) {
          supplierName = mainSup.name;
      } else {
        const pcLists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
        for (const lKey of pcLists) {
          pcSup = ensureArray(perCapitaConfig ? perCapitaConfig[lKey] : []).find(findSup);
          if (pcSup) {
            supplierName = pcSup.name;
            break;
          }
        }
      }
      
      const updatedTargetNameClean = clean(supplierName);
      const logSnapshot = await get(warehouseLogRef);
      const allLogs = logSnapshot.val() || {};
      const logUpdates: any = {};
      
      const existingLogsForKey: Record<string, any> = {};
      Object.keys(allLogs).forEach(key => {
          const entry = allLogs[key];
          const entryInv = clean(entry.inboundInvoice || entry.outboundInvoice || entry.invoiceNumber || '');
          const entryCpf = clean(entry.supplierCpf || '');
          const entryName = clean(entry.supplierName || '');
          if ((entryCpf === targetCpf || (updatedTargetNameClean && entryName === updatedTargetNameClean)) && entryInv === targetInvoice) {
              existingLogsForKey[key] = entry;
          }
      });
      
      console.log('handleUpdateInvoiceItems existing logs:', Object.keys(existingLogsForKey).length, existingLogsForKey);

      const usedLogKeys = new Set<string>();
      for (const item of items) {
          const itName = clean(item.name || item.itemName || '');
          const logKey = Object.keys(existingLogsForKey).find(k => {
              if (usedLogKeys.has(k)) return false;
              const logEntry = existingLogsForKey[k];
              const logName = clean(logEntry.itemName || logEntry.item || '');
              if (item.id && logEntry.id && item.id === logEntry.id) return true;
              if (item.id && logEntry.deliveryId && item.id === logEntry.deliveryId) return true;
              return itName === logName;
          });

          if (logKey) {
              usedLogKeys.add(logKey);
              logUpdates[`${logKey}/inboundInvoice`] = newInvoiceNumber || invoiceNumber;
              logUpdates[`${logKey}/invoiceNumber`] = newInvoiceNumber || invoiceNumber;
              logUpdates[`${logKey}/itemName`] = item.name;
              logUpdates[`${logKey}/item`] = item.name;
              logUpdates[`${logKey}/quantity`] = Number(item.kg) || 0;
              logUpdates[`${logKey}/kg`] = Number(item.kg) || 0;
              logUpdates[`${logKey}/value`] = item.value !== undefined ? Number(item.value) : (existingLogsForKey[logKey].value || 0);
              logUpdates[`${logKey}/lotNumber`] = item.lotNumber || '';
              logUpdates[`${logKey}/expirationDate`] = item.expirationDate || '';
              logUpdates[`${logKey}/barcode`] = item.barcode || '';
              logUpdates[`${logKey}/pdNumber`] = pd ?? item.pd ?? '';
              logUpdates[`${logKey}/neNumber`] = ne ?? item.ne ?? '';
              logUpdates[`${logKey}/location`] = item.location || '';
              logUpdates[`${logKey}/date`] = newDate || existingLogsForKey[logKey].date || '';
          } else {
              const newRef = push(warehouseLogRef);
              const newId = newRef.key || `it-${Date.now()}-${crypto.randomUUID().substring(0, 8)}`;
              logUpdates[newId] = {
                  id: newId,
                  type: 'entrada',
                  timestamp: new Date().toISOString(),
                  date: newDate || new Date().toISOString().split('T')[0],
                  itemName: item.name,
                  supplierName: supplierName || 'FORNECEDOR EDITADO',
                  supplierCpf: supplierCpf,
                  invoiceNumber: newInvoiceNumber || invoiceNumber,
                  inboundInvoice: newInvoiceNumber || invoiceNumber,
                  quantity: Number(item.kg) || 0,
                  kg: Number(item.kg) || 0,
                  value: Number(item.value) || 0,
                  lotNumber: item.lotNumber || 'UNICO',
                  expirationDate: item.expirationDate || '',
                  barcode: item.barcode || '',
                  location: item.location || '',
                  pdNumber: pd ?? item.pd ?? '',
                  neNumber: ne ?? item.ne ?? ''
              };
          }
      }

      Object.keys(existingLogsForKey).forEach(k => {
          if (!usedLogKeys.has(k)) {
              logUpdates[k] = null;
          }
      });

      console.log('handleUpdateInvoiceItems applying logUpdates:', logUpdates);

      if (Object.keys(logUpdates).length > 0) {
          await update(warehouseLogRef, logUpdates);
      }

      const updateDeliveries = (list: any[]) => {
        const currentList = ensureArray<any>(list);
        const others = currentList.filter(d => d && clean(d.invoiceNumber) !== targetInvoice);
        const updated = items.map(it => {
          const original = currentList.find(d => d && clean(d.invoiceNumber) === targetInvoice && (it.id === d.id || (d.id && it.id === d.id) || clean(it.name) === clean(d.itemName || d.item)));
          return {
            id: it.id || original?.id || `del-${Date.now()}-${crypto.randomUUID().substring(0, 8)}`,
            ...original,
            invoiceNumber: newInvoiceNumber || invoiceNumber,
            date: newDate || original?.date || new Date().toISOString().split('T')[0],
            itemName: it.name,
            item: it.name,
            kg: Number(it.kg || 0),
            quantity: Number(it.kg || 0),
            value: Number(it.value || 0),
            lotNumber: it.lotNumber || '',
            expirationDate: it.expirationDate || '',
            barcode: it.barcode || barcode || '',
            location: it.location || '',
            receiptTermNumber: receiptTermNumber || original?.receiptTermNumber || '',
            invoiceDate: invoiceDate || original?.invoiceDate || '',
            pdNumber: pd ?? it.pd ?? original?.pdNumber ?? '',
            pd: pd ?? it.pd ?? original?.pd ?? '',
            neNumber: ne ?? it.ne ?? original?.neNumber ?? '',
            ne: ne ?? it.ne ?? original?.ne ?? ''
          };
        });
        return sanitizeForFirebase([...others, ...updated]);
      };

      if (!suppliers || suppliers.length === 0) {
        console.warn("Suppliers not loaded yet during update attempt.");
      }

      let supplierFound = false;

      // Update in Main Suppliers if found
      const mainSups = (suppliers || []).filter(findSup);
      for (const mSup of mainSups) {
        const supRef = child(suppliersRef, `${mSup.id || targetCpf}/deliveries`);
        await safeRunTransaction(supRef, (current) => updateDeliveries(current), mSup.deliveries || []);
        supplierFound = true;
      }

      // Update in Per Capita Config if found
      const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
      for (const lKey of lists) {
        const list = ensureArray<any>(perCapitaConfig ? perCapitaConfig[lKey] : []);
        // Find ALL matching indices in this list
        const indices = list.reduce((acc, s, i) => {
          if (findSup(s)) acc.push(i);
          return acc;
        }, [] as number[]);
        
        for (const idx of indices) {
          const dRef = child(perCapitaConfigRef, `${lKey}/${idx}/deliveries`);
          await safeRunTransaction(dRef, (current) => updateDeliveries(current), list[idx]?.deliveries || []);
          supplierFound = true;
        }
      }

      if (!supplierFound) {
        console.warn("Supplier not found in any list during invoice update:", { supplierCpf, targetCpf });
      }

      return { success: true };
    } catch (e) {
      console.error("Error in handleUpdateInvoiceItems:", e);
      const msg = e instanceof Error ? e.message : String(e);
      return { success: false, message: 'Erro ao atualizar itens da nota: ' + msg };
    }
  };

  const handleReopenInvoice = async (supplierCpf: string, invoiceNumber: string) => {
    const clean = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
    const targetCpf = clean(supplierCpf);
    const targetInvoice = clean(invoiceNumber);
    
    const mainSupplier = suppliers.find(s => clean(s.cpf) === targetCpf);
    if (mainSupplier) {
      const deliveriesRef = child(suppliersRef, `${mainSupplier.id || targetCpf}/deliveries`);
      await safeRunTransaction(deliveriesRef, (currentDeliveries) => {
        const deliveries = ensureArray<any>(currentDeliveries);
        const entriesForNf = deliveries.filter(d => clean(d.invoiceNumber) === targetInvoice);
        if (entriesForNf.length > 0) {
          const baseDate = entriesForNf[0].date;
          const baseTime = entriesForNf[0].time;
          const filtered = deliveries.filter(d => clean(d.invoiceNumber) !== targetInvoice);
          filtered.push({
            id: `reopen-${Date.now()}`,
            date: baseDate,
            time: baseTime,
            item: 'AGENDAMENTO PENDENTE',
            invoiceUploaded: false
          });
          return sanitizeForFirebase(filtered);
        }
        return currentDeliveries;
      }, mainSupplier.deliveries || []);
      return;
    }

    let listKey: 'ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers' | null = null;
    let producerIdx = -1;

    const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
    for (const lKey of lists) {
      const list = ensureArray<any>(perCapitaConfig[lKey]);
      const idx = list.findIndex((p: any) => clean(p.cpfCnpj || p.cpf) === targetCpf);
      if (idx !== -1) {
        listKey = lKey;
        producerIdx = idx;
        break;
      }
    }

    if (listKey && producerIdx !== -1) {
      const currentList = ensureArray<any>(perCapitaConfig[listKey]);
      const deliveriesRef = child(perCapitaConfigRef, `${listKey}/${producerIdx}/deliveries`);
      await safeRunTransaction(deliveriesRef, (currentDeliveries) => {
        const deliveries = ensureArray<any>(currentDeliveries);
        const entriesForNf = deliveries.filter((d: any) => clean(d.invoiceNumber) === targetInvoice);
        if (entriesForNf.length > 0) {
          const baseDate = entriesForNf[0].date;
          const baseTime = entriesForNf[0].time;
          const filtered = deliveries.filter((d: any) => clean(d.invoiceNumber) !== targetInvoice);
          filtered.push({
            id: `reopen-${Date.now()}`,
            date: baseDate,
            time: baseTime,
            item: 'AGENDAMENTO PENDENTE',
            invoiceUploaded: false
          });
          return sanitizeForFirebase(filtered);
        }
        return currentDeliveries;
      }, currentList[producerIdx]?.deliveries || []);
    }
  };

  const handleDeleteInvoice = async (supplierCpf: string, invoiceNumber: string, retries = 5) => {
    console.log('handleDeleteInvoice chamado:', supplierCpf, invoiceNumber);
    const clean = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
    const targetCpf = clean(supplierCpf);
    const targetInvoice = clean(invoiceNumber);

    for (let i = 0; i < retries; i++) {
      try {
        const _mainSupplier = suppliers.find(s => clean(s.cpf) === targetCpf);
        
        // --- Deletar também do log do almoxarifado ---
        const logSnapshot = await get(warehouseLogRef);
        const allLogs = logSnapshot.val() || {};
        const logKeysToDelete = Object.keys(allLogs).filter(key => {
            const entry = allLogs[key];
            const entryInv = clean(entry.inboundInvoice || entry.outboundInvoice || entry.invoiceNumber || 'S/N');
            const entryCpf = clean(entry.supplierCpf || '');
            
            const isTarget = entryCpf === targetCpf && entryInv === targetInvoice;
            
            if (isTarget && targetInvoice === 'SN') {
                if (clean(entry.item || entry.itemName) === 'AGENDAMENTO PENDENTE') return false;
            }
            return isTarget;
        });

        if (logKeysToDelete.length > 0) {
            console.log(`Deletando ${logKeysToDelete.length} itens do warehouseLog correspondentes à NF ${invoiceNumber}`);
            await Promise.all(logKeysToDelete.map(key => remove(child(warehouseLogRef, key))));
        }

        let deletedAny = false;

        const mainSups = suppliers.filter(s => clean(s.cpf) === targetCpf);
        for (const mSup of mainSups) {
          const deliveriesRef = child(suppliersRef, `${mSup.id || targetCpf}/deliveries`);
          console.log(`Iniciando transação MainSupplier (tentativa ${i + 1}):`, targetCpf);
          await safeRunTransaction(deliveriesRef, (currentDeliveries) => {
            const list = ensureArray<any>(currentDeliveries);
            const filtered = list.filter(d => {
              const dInv = clean(d.invoiceNumber || 'S/N');
              const isTargetInvoice = dInv === targetInvoice;
              
              if (isTargetInvoice && targetInvoice === 'SN') {
                  if (d.item === 'AGENDAMENTO PENDENTE') return true; 
              }
              return !isTargetInvoice;
            });
            return sanitizeForFirebase(filtered);
          }, mSup.deliveries || []);
          deletedAny = true;
          console.log('Transação de exclusão concluída para MainSupplier');
        }

        const lists: ('ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers')[] = ['ppaisProducers', 'pereciveisSuppliers', 'estocaveisSuppliers'];
        for (const lKey of lists) {
          const list = ensureArray<any>(perCapitaConfig[lKey]);
          const indices = list.reduce((acc, p, idx) => {
            if (clean((p as any).cpfCnpj || (p as any).cpf) === targetCpf) acc.push(idx);
            return acc;
          }, [] as number[]);

          for (const idx of indices) {
            const deliveriesRef = child(perCapitaConfigRef, `${lKey}/${idx}/deliveries`);
            await safeRunTransaction(deliveriesRef, (currentDeliveries) => {
              const currentList = ensureArray<any>(currentDeliveries);
              const filtered = currentList.filter(d => {
                const dInv = clean(d.invoiceNumber || 'S/N');
                const isTargetInvoice = dInv === targetInvoice;
                
                if (isTargetInvoice && targetInvoice === 'SN') {
                    if (d.item === 'AGENDAMENTO PENDENTE') return true; 
                }
                return !isTargetInvoice;
              });
              return sanitizeForFirebase(filtered);
            }, list[idx]?.deliveries || []);
            deletedAny = true;
            console.log('Transação de exclusão concluída para PerCapita indexada');
          }
        }
        
        console.log('Transação de exclusão concluída para fornecedores. Algo deletado?', deletedAny);
        return { success: true };
      } catch (error) {
        console.log('--- INÍCIO DO ERRO ---');
        console.log('Erro como string:', String(error));
        if (error instanceof Error) {
            console.log('Mensagem do erro:', error.message);
        }
        console.log('--- FIM DO ERRO ---');
        if (i === retries - 1) {
          return { success: false, message: 'Erro ao excluir nota fiscal após várias tentativas: ' + (error instanceof Error ? error.message : String(error)) };
        }
        // Espera um pouco antes de tentar novamente (backoff simples)
        await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
      }
    }
  };

  const handleManualInvoiceEntry = async (supplierCpf: string, date: string, invoiceNumber: string, items: { name: string; kg: number; value: number; lotNumber?: string; expirationDate?: string; barcode?: string }[], barcode?: string, receiptTermNumber?: string, invoiceDate?: string, pd?: string, type: 'entrada' | 'saída' = 'entrada', invoiceUrl?: string, ne?: string) => {
    let supplierName = '';
    const cleanStr = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
    const cleanEntryCpf = cleanStr(supplierCpf);

    const mainSupplier = (suppliers || []).find(s => s && cleanStr(s.cpf) === cleanEntryCpf);
    if (mainSupplier) {
      supplierName = mainSupplier.name;
    } else {
      const p = (perCapitaConfig.ppaisProducers || []).find(s => (cleanStr(s.cpfCnpj || s.cpf) === cleanEntryCpf)) || 
                (perCapitaConfig.pereciveisSuppliers || []).find(s => (cleanStr(s.cpfCnpj || s.cpf) === cleanEntryCpf)) ||
                (perCapitaConfig.estocaveisSuppliers || []).find(s => (cleanStr(s.cpfCnpj || s.cpf) === cleanEntryCpf));
      if (p) supplierName = p.name;
    }

    if (!supplierName) return { success: false, message: 'Fornecedor não encontrado.' };

    try {
      // 1. Registrar no log do almoxarifado primeiro
      const logEntries: { ref: any, entry: any, lotId: string }[] = items.map((item, idx) => {
        const newLogRef = push(warehouseLogRef);
        const lotId = `lot-manual-${Date.now()}-${idx}`;
        const entry: any = {
            id: newLogRef.key || `ent-man-${Date.now()}-${idx}`,
            type: type,
            timestamp: new Date().toISOString(),
            date: invoiceDate || date,
            itemName: item.name,
            supplierName: supplierName,
            supplierCpf: supplierCpf,
            lotNumber: item.lotNumber || 'UNICO',
            quantity: item.kg,
            value: item.value || 0,
            barcode: item.barcode || barcode || '',
            pdNumber: pd || '',
            neNumber: ne || '',
            lotId: lotId,
            deliveryId: ''
        };
        
        if (type === 'entrada') {
            entry.inboundInvoice = String(invoiceNumber || '').trim();
        } else {
            entry.outboundInvoice = String(invoiceNumber || '').trim();
        }
        if (item.expirationDate !== undefined) entry.expirationDate = item.expirationDate;

        return { ref: newLogRef, entry, lotId };
      });

      // Salva todos os logs
      await Promise.all(logEntries.map(le => set(le.ref, le.entry)));

      // 2. Sincronizar com as entregas do fornecedor
      const entryDate = invoiceDate || date;
      if (mainSupplier) {
        const supplierRef = child(suppliersRef, mainSupplier.cpf);
        await safeRunTransaction(supplierRef, (currentData: Supplier) => {
          if (!currentData) currentData = { ...mainSupplier };
          let deliveries = Array.isArray(currentData.deliveries) 
            ? [...currentData.deliveries] 
            : Object.values(currentData.deliveries || {});
          
          // Remover agendamento pendente do mesmo dia
          deliveries = deliveries.filter((d: any) => !(d.date === entryDate && d.item === 'AGENDAMENTO PENDENTE'));

          logEntries.forEach((le, idx) => {
            const item = items[idx];
            const newDelivery: any = {
              id: `manual-${Date.now()}-${idx}`,
              date: entryDate,
              time: '08:00',
              item: item.name,
              kg: item.kg,
              value: item.value,
              invoiceUploaded: true,
              invoiceNumber: String(invoiceNumber || '').trim(),
              barcode: item.barcode || barcode || '',
              type: type,
              status: 'CONCLUÍDO',
              lots: [{
                id: le.lotId,
                lotNumber: item.lotNumber || 'MANUAL',
                initialQuantity: item.kg,
                remainingQuantity: item.kg
              }]
            };

            if (invoiceDate !== undefined) newDelivery.invoiceDate = invoiceDate;
            if (receiptTermNumber !== undefined) newDelivery.receiptTermNumber = receiptTermNumber;
            if (pd !== undefined) newDelivery.pd = pd;
            if (ne !== undefined) newDelivery.ne = ne;
            if (invoiceUrl !== undefined) newDelivery.invoiceUrl = invoiceUrl;
            if (item.expirationDate !== undefined) newDelivery.lots[0].expirationDate = item.expirationDate;

            deliveries.push(newDelivery);
          });
          currentData.deliveries = deliveries;
          return currentData;
        }, mainSupplier);
      } else {
        await safeRunTransaction(perCapitaConfigRef, (currentData: PerCapitaConfig) => {
          if (!currentData) currentData = { ...perCapitaConfig };
            const findAndAdd = (list: any[] | undefined) => {
              const s = list?.find(p => (cleanStr(p.cpfCnpj || p.cpf) === cleanEntryCpf));
              if (s) {
                let deliveries = Array.isArray(s.deliveries)
                  ? [...s.deliveries]
                  : Object.values(s.deliveries || {});
                
                // Remover agendamento pendente do mesmo dia
                deliveries = deliveries.filter((d: any) => !(d.date === entryDate && d.item === 'AGENDAMENTO PENDENTE'));

                logEntries.forEach((le, idx) => {
                  const item = items[idx];
                  const newDelivery: any = {
                    id: `manual-${Date.now()}-${idx}`,
                    date: entryDate,
                    time: '08:00',
                    item: item.name,
                    kg: item.kg,
                    value: item.value,
                    invoiceUploaded: true,
                    invoiceNumber: String(invoiceNumber || '').trim(),
                    barcode: item.barcode || barcode || '',
                    status: 'CONCLUÍDO',
                    lots: [{
                      id: le.lotId,
                      lotNumber: item.lotNumber || 'MANUAL',
                      initialQuantity: item.kg,
                      remainingQuantity: item.kg
                    }]
                  };

                  if (invoiceDate !== undefined) newDelivery.invoiceDate = invoiceDate;
                  if (receiptTermNumber !== undefined) newDelivery.receiptTermNumber = receiptTermNumber;
                  if (pd !== undefined) newDelivery.pd = pd;
                  if (ne !== undefined) newDelivery.ne = ne;
                  if (invoiceUrl !== undefined) newDelivery.invoiceUrl = invoiceUrl;
                  if (item.expirationDate !== undefined) newDelivery.lots[0].expirationDate = item.expirationDate;

                  deliveries.push(newDelivery);
                });
                s.deliveries = deliveries;
                return true;
              }
              return false;
            };
            if (!findAndAdd(currentData.ppaisProducers)) {
              if (!findAndAdd(currentData.pereciveisSuppliers)) {
                 findAndAdd(currentData.estocaveisSuppliers);
              }
            }
          return currentData;
        }, perCapitaConfig);
      }

      return { success: true };
    } catch (e) {
      console.error("Erro no lançamento manual:", e);
      return { success: false, message: 'Falha no lançamento manual.' };
    }
  };

  // --- FIM GERENCIAMENTO NOTAS ---

  const handleUpdateContractForItem = async (itemName: string, assignments: any[]) => {
    try {
      console.log('Tentando atualizar contratos para o item:', itemName, 'Assignments:', assignments);
      
      const cleanStr = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
      
      // Identificar fornecedores que PRECISAM ser atualizados no cadastro geral:
      const suppliersToUpdate = suppliers.filter(s => {
        const isAssigned = assignments.some(a => cleanStr(a.supplierCpf) === cleanStr(s.cpf));
        const hasItem = (s.contractItems || []).some(ci => ci.name === itemName);
        return isAssigned || hasItem;
      });

      console.log('Total de fornecedores afetados no cadastro geral:', suppliersToUpdate.length);
      
      let count = 0;
      for (const supplier of suppliersToUpdate) {
        count++;
        const assignment = assignments.find(a => cleanStr(a.supplierCpf) === cleanStr(supplier.cpf));
        const supplierRef = child(suppliersRef, supplier.id || supplier.cpf);
        
        console.log(`Processando fornecedor ${count}/${suppliersToUpdate.length}: ${supplier.name} (${supplier.id || supplier.cpf})`);
        
        await safeRunTransaction(supplierRef, (data: Supplier) => {
          if (!data) data = { ...supplier };
          
          const otherItems = (data.contractItems || []).filter(ci => ci.name !== itemName);
          
          if (assignment) {
            otherItems.push({
              name: itemName,
              totalKg: assignment.totalKg,
              valuePerKg: assignment.valuePerKg,
              unit: assignment.unit || 'kg-1',
              category: assignment.category || 'OUTROS',
              comprasCode: assignment.comprasCode || '',
              becCode: assignment.becCode || '',
              commitmentNumber: assignment.commitmentNumber || '',
              commitmentValue: assignment.commitmentValue || 0,
              monthlyWeight: assignment.monthlyWeight || 0,
              monthlyValue: assignment.monthlyValue || 0,
              period: '2_3_QUAD'
            });
          }
          
          data.contractItems = otherItems;
          data.initialValue = otherItems.reduce((acc, curr) => acc + (Number(curr.totalKg || 0) * Number(curr.valuePerKg || 0)), 0);
          
          return data;
        }, supplier, 3000);
      }

      // --- Sincronizar com perCapitaConfig em uma única transação limpa ---
      console.log('Iniciando sincronização do perCapitaConfig...');
      await safeRunTransaction(perCapitaConfigRef, (current: any) => {
        if (!current) current = { ...perCapitaConfig };

        const updatedPpais = Array.isArray(current.ppaisProducers) ? [...current.ppaisProducers] : Object.values(current.ppaisProducers || {});
        const updatedPereciveis = Array.isArray(current.pereciveisSuppliers) ? [...current.pereciveisSuppliers] : Object.values(current.pereciveisSuppliers || {});
        const updatedEstocaveis = Array.isArray(current.estocaveisSuppliers) ? [...current.estocaveisSuppliers] : Object.values(current.estocaveisSuppliers || {});

        const cleanNormalize = (n: string) => String(n || '').trim().toUpperCase().replace(/\s+/g, ' ');
        const normalizedItemName = cleanNormalize(itemName);

        const removeContractItem = (list: any[]) => {
          return list.map(p => {
            const contractItems = (p.contractItems || []).filter((ci: any) => cleanNormalize(ci.name) !== normalizedItemName);
            return { ...p, contractItems };
          });
        };

        const tempPpais = removeContractItem(updatedPpais);
        const tempPereciveis = removeContractItem(updatedPereciveis);
        const tempEstocaveis = removeContractItem(updatedEstocaveis);

        for (const a of assignments) {
          const supplierCpf = cleanStr(a.supplierCpf);
          const fullSupplier = suppliers.find(s => cleanStr(s.cpf) === supplierCpf);
          const sName = a.supplierName || (fullSupplier ? fullSupplier.name : 'FORNECEDOR');

          const newContractItem = {
            name: itemName,
            totalKg: a.totalKg,
            valuePerKg: a.valuePerKg,
            unit: a.unit || 'kg-1',
            category: a.category || 'OUTROS',
            comprasCode: a.comprasCode || '',
            becCode: a.becCode || '',
            commitmentNumber: a.commitmentNumber || '',
            commitmentValue: a.commitmentValue || 0,
            monthlyWeight: a.monthlyWeight || 0,
            monthlyValue: a.monthlyValue || 0,
            period: '2_3_QUAD'
          };

          if (a.category === 'PPAIS') {
            const idx = tempPpais.findIndex(p => cleanStr(p.cpfCnpj || p.cpf) === supplierCpf);
            if (idx !== -1) {
              tempPpais[idx].contractItems.push(newContractItem);
            } else {
              tempPpais.push({
                ...(fullSupplier || {}),
                name: sName,
                cpf: a.supplierCpf,
                cpfCnpj: a.supplierCpf,
                contractItems: [newContractItem],
                deliveries: []
              });
            }
          } else if (a.category === 'PERECÍVEIS') {
            const idx = tempPereciveis.findIndex(p => cleanStr(p.cpfCnpj || p.cpf) === supplierCpf);
            if (idx !== -1) {
              tempPereciveis[idx].contractItems.push(newContractItem);
            } else {
              tempPereciveis.push({
                ...(fullSupplier || {}),
                name: sName,
                cpf: a.supplierCpf,
                cpfCnpj: a.supplierCpf,
                contractItems: [newContractItem],
                deliveries: []
              });
            }
          } else if (a.category === 'ESTOCÁVEIS') {
            const idx = tempEstocaveis.findIndex(p => cleanStr(p.cpfCnpj || p.cpf) === supplierCpf);
            if (idx !== -1) {
              tempEstocaveis[idx].contractItems.push(newContractItem);
            } else {
              tempEstocaveis.push({
                ...(fullSupplier || {}),
                name: sName,
                cpf: a.supplierCpf,
                cpfCnpj: a.supplierCpf,
                contractItems: [newContractItem],
                deliveries: []
              });
            }
          }
        }

        return {
          ...current,
          ppaisProducers: tempPpais,
          pereciveisSuppliers: tempPereciveis,
          pereciveisSuppliers2Q: tempPereciveis,
          estocaveisSuppliers: tempEstocaveis,
          estocaveisSuppliers2Q: tempEstocaveis
        };
      }, perCapitaConfig, 3000);

      // --- Sincronizar com o item de aquisição correspondente ---
      const cleanNormalize = (n: string) => String(n || '').trim().toUpperCase().replace(/\s+/g, ' ');
      const normalizedItem = cleanNormalize(itemName);
      const matchedItem = acquisitionItems.find(i => 
        cleanNormalize(i.name) === normalizedItem || 
        cleanNormalize(i.contractItemName || '') === normalizedItem
      );

      if (matchedItem) {
        const totalKg = assignments.reduce((sum, a) => sum + parseFloat(String(a.totalKg || '0').replace(',', '.')), 0);
        const totalValue = assignments.reduce((sum, a) => {
            const kg = parseFloat(String(a.totalKg || '0').replace(',', '.'));
            const price = parseFloat(String(a.valuePerKg || '0').replace(',', '.'));
            const commitment = parseFloat(String(a.commitmentValue || '0').replace(',', '.'));
            const val = (commitment > 0) ? commitment : (kg * price);
            return sum + val;
        }, 0);
        const weightedAvg = totalKg > 0 ? totalValue / totalKg : 0;

        const firstA = assignments[0];
        const updatedItem = {
          ...matchedItem,
          unitValue: weightedAvg,
          ...(firstA ? {
            comprasCode: firstA.comprasCode !== undefined ? firstA.comprasCode : matchedItem.comprasCode,
            becCode: firstA.becCode !== undefined ? firstA.becCode : matchedItem.becCode,
            category: firstA.category || matchedItem.category
          } : {})
        };
        await set(child(acquisitionItemsRef, matchedItem.id), updatedItem);
      }
      
      return { success: true, message: 'Contratos atualizados' };
    } catch (error) {
      console.error('Erro ao atualizar contratos:', error);
      return { success: false, message: 'Falha ao atualizar contratos: ' + (error instanceof Error ? error.message : String(error)) };
    }
  };

  const handleUpdateAcquisitionItem = async (item: AcquisitionItem) => {
    try {
      // 1. Sanitizar o item para garantir tipos e eliminar qualquer valor undefined (que trava ou gera erro no Firebase)
      const sanitizedItem: AcquisitionItem = {
        id: String(item.id || `acq-${Date.now()}`),
        name: String(item.name || '').trim().toUpperCase(),
        nickname: String(item.nickname || '').trim().toUpperCase(),
        contractItemName: String(item.contractItemName || '').trim(),
        comprasCode: String(item.comprasCode || '').trim(),
        becCode: String(item.becCode || '').trim(),
        expenseNature: String(item.expenseNature || '').trim(),
        unit: String(item.unit || 'un').trim(),
        acquiredQuantity: Number(item.acquiredQuantity) || 0,
        stockBalance: Number(item.stockBalance) || 0,
        unitValue: Number(item.unitValue) || 0,
        unitValue23: Number(item.unitValue23) || 0,
        contractAddendum: Number(item.contractAddendum) || 0,
        commitmentNumber: String(item.commitmentNumber || '').trim(),
        category: String(item.category || '').trim(),
        year: item.year ? Number(item.year) : 2026,
        quadrimestre: (item.quadrimestre as any) || '2Q'
      };

      const oldItem = acquisitionItems.find(i => i.id === sanitizedItem.id) || null;

      // 2. Atualização otimista imediata no estado local e cache (resposta em 0ms no navegador)
      setAcquisitionItems(prev => {
        const existingIdx = prev.findIndex(i => i.id === sanitizedItem.id);
        let updatedList: AcquisitionItem[];
        if (existingIdx >= 0) {
          updatedList = [...prev];
          updatedList[existingIdx] = sanitizedItem;
        } else {
          updatedList = [sanitizedItem, ...prev];
        }
        safeLocalStorageSetItem('cached_acquisitionItems', JSON.stringify(updatedList));
        return updatedList;
      });

      // 3. Sincronização segura com o Firebase (com proteção de timeout para nunca travar o app)
      if (database && acquisitionItemsRef) {
        try {
          const itemRef = child(acquisitionItemsRef, sanitizedItem.id);
          const savePromise = set(itemRef, sanitizedItem);
          const timeoutPromise = new Promise(resolve => setTimeout(resolve, 3000));
          await Promise.race([savePromise, timeoutPromise]);
        } catch (dbErr) {
          console.warn("Firebase set acquisitionItem com timeout ou offline, mantido localmente:", dbErr);
        }
      }

      // 4. Se o nome mudou, atualizar fornecedores correspondentes
      if (oldItem && oldItem.name !== sanitizedItem.name) {
        try {
          for (const supplier of suppliers) {
            if (supplier.contractItems && supplier.cpf) {
              const updatedItems = supplier.contractItems.map(ci => 
                ci.name === oldItem.name ? { ...ci, name: sanitizedItem.name } : ci
              );
              if (JSON.stringify(updatedItems) !== JSON.stringify(supplier.contractItems)) {
                if (suppliersRef) {
                  update(child(suppliersRef, supplier.cpf), { contractItems: updatedItems }).catch(e => console.warn(e));
                }
              }
            }
          }

          const updateSupplierList = (list: any[]) => ensureArray(list).map(p => ({
            ...p,
            contractItems: (p.contractItems || []).map((ci: any) => ci.name === oldItem.name ? { ...ci, name: sanitizedItem.name } : ci)
          }));

          if (perCapitaConfigRef) {
            update(perCapitaConfigRef, { 
              ppaisProducers: updateSupplierList(perCapitaConfig.ppaisProducers || []),
              pereciveisSuppliers: updateSupplierList(perCapitaConfig.pereciveisSuppliers || []),
              pereciveisSuppliers1Q: updateSupplierList(perCapitaConfig.pereciveisSuppliers1Q || []),
              pereciveisSuppliers2Q: updateSupplierList(perCapitaConfig.pereciveisSuppliers2Q || []),
              pereciveisSuppliers3Q: updateSupplierList(perCapitaConfig.pereciveisSuppliers3Q || []),
              pereciveisSuppliers2027_1Q: updateSupplierList(perCapitaConfig.pereciveisSuppliers2027_1Q || []),
              pereciveisSuppliers2027_2Q: updateSupplierList(perCapitaConfig.pereciveisSuppliers2027_2Q || []),
              pereciveisSuppliers2027_3Q: updateSupplierList(perCapitaConfig.pereciveisSuppliers2027_3Q || []),
              estocaveisSuppliers: updateSupplierList(perCapitaConfig.estocaveisSuppliers || []),
              estocaveisSuppliers1Q: updateSupplierList(perCapitaConfig.estocaveisSuppliers1Q || []),
              estocaveisSuppliers2Q: updateSupplierList(perCapitaConfig.estocaveisSuppliers2Q || []),
              estocaveisSuppliers3Q: updateSupplierList(perCapitaConfig.estocaveisSuppliers3Q || []),
              estocaveisSuppliers2027_1Q: updateSupplierList(perCapitaConfig.estocaveisSuppliers2027_1Q || []),
              estocaveisSuppliers2027_2Q: updateSupplierList(perCapitaConfig.estocaveisSuppliers2027_2Q || []),
              estocaveisSuppliers2027_3Q: updateSupplierList(perCapitaConfig.estocaveisSuppliers2027_3Q || []),
            }).catch(e => console.warn(e));
          }
        } catch (linkErr) {
          console.warn("Erro secundário ao atualizar nomes vinculados nos fornecedores:", linkErr);
        }
      }
      return { success: true, message: 'Item atualizado com sucesso' };
    } catch (e) {
      console.error('Erro em handleUpdateAcquisitionItem:', e);
      return { success: false, message: 'Erro ao atualizar item' };
    }
  };

  const handleDeleteAcquisitionItem = async (id: string) => {
    try {
      const item = acquisitionItems.find(i => i.id === id) || null;

      if (database && acquisitionItemsRef) {
        try {
          const itemRef = child(acquisitionItemsRef, id);
          await remove(itemRef);
          await set(itemRef, null);
        } catch (dbErr) {
          console.error("Erro ao remover item do Firebase:", dbErr);
          return { success: false, message: 'Erro ao excluir item do banco de dados' };
        }
      }

      // Atualização otimista imediata no estado local e cache após confirmação do DB
      setAcquisitionItems(prev => {
        const updatedList = prev.filter(i => i.id !== id);
        safeLocalStorageSetItem('cached_acquisitionItems', JSON.stringify(updatedList));
        return updatedList;
      });

      if (item) {
        try {
          for (const supplier of suppliers) {
            if (supplier.contractItems && supplier.cpf) {
              const updatedItems = supplier.contractItems.filter(ci => ci.name !== item.name);
              if (updatedItems.length !== supplier.contractItems.length) {
                if (suppliersRef) {
                  update(child(suppliersRef, supplier.cpf), { contractItems: updatedItems }).catch(e => console.warn(e));
                }
              }
            }
          }

          const filterSupplierList = (list: any[]) => ensureArray(list).map(p => ({
            ...p,
            contractItems: (p.contractItems || []).filter((ci: any) => ci.name !== item.name)
          }));

          if (perCapitaConfigRef) {
            update(perCapitaConfigRef, { 
              ppaisProducers: filterSupplierList(perCapitaConfig.ppaisProducers || []),
              pereciveisSuppliers: filterSupplierList(perCapitaConfig.pereciveisSuppliers || []),
              pereciveisSuppliers1Q: filterSupplierList(perCapitaConfig.pereciveisSuppliers1Q || []),
              pereciveisSuppliers2Q: filterSupplierList(perCapitaConfig.pereciveisSuppliers2Q || []),
              pereciveisSuppliers3Q: filterSupplierList(perCapitaConfig.pereciveisSuppliers3Q || []),
              pereciveisSuppliers2027_1Q: filterSupplierList(perCapitaConfig.pereciveisSuppliers2027_1Q || []),
              pereciveisSuppliers2027_2Q: filterSupplierList(perCapitaConfig.pereciveisSuppliers2027_2Q || []),
              pereciveisSuppliers2027_3Q: filterSupplierList(perCapitaConfig.pereciveisSuppliers2027_3Q || []),
              estocaveisSuppliers: filterSupplierList(perCapitaConfig.estocaveisSuppliers || []),
              estocaveisSuppliers1Q: filterSupplierList(perCapitaConfig.estocaveisSuppliers1Q || []),
              estocaveisSuppliers2Q: filterSupplierList(perCapitaConfig.estocaveisSuppliers2027_2Q || []),
              estocaveisSuppliers3Q: filterSupplierList(perCapitaConfig.estocaveisSuppliers3Q || []),
              estocaveisSuppliers2027_1Q: filterSupplierList(perCapitaConfig.estocaveisSuppliers2027_1Q || []),
              estocaveisSuppliers2027_2Q: filterSupplierList(perCapitaConfig.estocaveisSuppliers2027_2Q || []),
              estocaveisSuppliers2027_3Q: filterSupplierList(perCapitaConfig.estocaveisSuppliers2027_3Q || []),
            }).catch(e => console.warn(e));
          }
        } catch (unlinkErr) {
          console.warn("Erro secundário ao remover itens vinculados dos fornecedores:", unlinkErr);
        }
      }

      return { success: true, message: 'Item excluído com sucesso' };
    } catch (e) {
      console.error('Erro em handleDeleteAcquisitionItem:', e);
      return { success: false, message: 'Erro ao excluir item' };
    }
  };

  const handleUpdateStandardMenu = async (m: any) => {
    setStandardMenu(m);
    safeLocalStorageSetItem('cached_standardMenu', JSON.stringify(m));
    if (database && navigator.onLine) {
      try {
        await set(standardMenuRef, m);
      } catch (err) {
        console.warn("Could not save standard menu to database, offline cache kept:", err);
      }
    }
  };

  const handleUpdateDailyMenu = async (m: any) => {
    setDailyMenus(m);
    safeLocalStorageSetItem('cached_dailyMenus', JSON.stringify(m));
    if (database && navigator.onLine) {
      try {
        await set(dailyMenusRef, m);
      } catch (err) {
        console.warn("Could not save daily menu to database, offline cache kept:", err);
      }
    }
  };

  const handleRegisterWarehouseEntry = async (payload: any) => {
    console.log("Iniciando registro de entrada:", payload.itemName);
    try {
        const newRef = push(warehouseLogRef);
        
        let finalInvoiceUrl = payload.invoiceUrl || '';
        if (finalInvoiceUrl && (finalInvoiceUrl.startsWith('data:application/pdf') || finalInvoiceUrl.startsWith('data:pdf/') || (finalInvoiceUrl.startsWith('data:') && finalInvoiceUrl.includes('base64')))) {
            console.log("Detectado possível PDF/Arquivo base64, iniciando upload para Storage...");
            try {
                const invoiceId = `inv_entry_NF${String(payload.invoiceNumber || 'S-N').replace(/[^\w-]/g, '_')}_${Date.now()}_${crypto.randomUUID().substring(0, 4)}.pdf`;
                
                const parts = finalInvoiceUrl.split(',');
                if (parts.length > 1) {
                    const byteString = atob(parts[1]);
                    const mimeString = parts[0].includes(':') ? parts[0].split(':')[1].split(';')[0] : 'application/pdf';
                    const ab = new ArrayBuffer(byteString.length);
                    const ia = new Uint8Array(ab);
                    for (let i = 0; i < byteString.length; i++) {
                      ia[i] = byteString.charCodeAt(i);
                    }
                    const blob = new Blob([ab], { type: mimeString });
                    
                    console.log("Blob criado, tamanho:", blob.size, "Enviando para storage via resumable...");
                    
                    const uploadPromise = async () => {
                        const bucket = 'gestao-ppais.firebasestorage.app';
                        
                        const res = await fetch('/api/proxy-storage-upload', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ bucket, path: `invoices/${invoiceId}`, base64: finalInvoiceUrl, contentType: mimeString })
                        });
                        
                        const text = await res.text();
                        let data;
                        try {
                            data = JSON.parse(text);
                        } catch (e: any) {
                            throw new Error(`Erro no servidor (${res.status}): Resposta inválida. O arquivo pode ser muito grande ou a internet oscilou.`, { cause: e });
                        }
                        
                        if (!data.success) {
                            throw new Error(data.error || 'Erro no servidor ao enviar arquivo');
                        }
                        return data.url;
                    };

                    const timeoutPromise = new Promise<never>((_, reject) => 
                        setTimeout(() => {
                            reject(new Error("Timeout no upload do PDF (180s)"));
                        }, 180000)
                    );
                    
                    finalInvoiceUrl = await Promise.race([uploadPromise(), timeoutPromise]);
                    console.log("Upload concluído com sucesso:", finalInvoiceUrl);
                }
            } catch (storageError) {
                console.error("Storage upload failed for entry attachment:", storageError);
                if (finalInvoiceUrl.length > 500000) {
                    console.warn("PDF muito grande para o RTDB (>500KB), removendo anexo para permitir salvamento.");
                    finalInvoiceUrl = '';
                } else {
                    console.log("Mantendo anexo em base64 no RTDB (menor que 500KB)");
                }
            }
        }

        const cleanStr = (s: any) => String(s || '').trim().replace(/^0+/, '').replace(/[.\-/]/g, '').toUpperCase();
        const cleanPayloadCpf = cleanStr(payload.supplierCpf);

        // Find supplier in both main list and perCapitaConfig
        const ppaisProducer = (perCapitaConfig.ppaisProducers || []).find(p => (cleanStr(p.cpfCnpj || p.cpf) === cleanPayloadCpf));
        const pereciveisSupplier = (perCapitaConfig.pereciveisSuppliers || []).find(p => (cleanStr(p.cpfCnpj || p.cpf) === cleanPayloadCpf));
        const estocavelSupplier = (perCapitaConfig.estocaveisSuppliers || []).find(p => (cleanStr(p.cpfCnpj || p.cpf) === cleanPayloadCpf));
        const mainSupplier = (suppliers || []).find(s => cleanStr(s.cpf) === cleanPayloadCpf);
        
        const supplier = mainSupplier || ppaisProducer || pereciveisSupplier || estocavelSupplier;

        const lotId = `lot-${Date.now()}`;
        const entryDate = payload.invoiceDate || payload.date || new Date().toISOString().split('T')[0];
        const entry: any = {
            id: newRef.key || `ent-${Date.now()}`,
            type: 'entrada',
            timestamp: new Date().toISOString(),
            date: entryDate,
            itemName: payload.itemName,
            supplierName: supplier?.name || 'Desconhecido',
            supplierCpf: payload.supplierCpf,
            lotNumber: payload.lotNumber || 'UNICO',
            quantity: Number(payload.quantity || 0),
            value: Number(payload.value || 0),
            barcode: payload.barcode || '',
            pdNumber: payload.pdNumber || '',
            lotId: lotId,
            deliveryId: '',
            invoiceUrl: finalInvoiceUrl
        };
        if (payload.invoiceNumber !== undefined) {
            entry.inboundInvoice = String(payload.invoiceNumber || '').trim();
        } else if (payload.inboundInvoice !== undefined) {
            entry.inboundInvoice = String(payload.inboundInvoice || '').trim();
        }
        if (payload.expirationDate !== undefined) entry.expirationDate = payload.expirationDate;

        await set(newRef, entry);

        // Sincronizar com as entregas do fornecedor para aparecer na Consulta de Notas Fiscais
        if (supplier) {
            const newDelivery = {
                id: `sync-${Date.now()}`,
                date: entryDate,
                time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
                item: payload.itemName,
                kg: Number(payload.quantity || 0),
                value: Number(payload.value || 0),
                invoiceUploaded: true, // Se está registrando a entrada com NF, ela está "carregada" no sistema
                invoiceNumber: String(payload.invoiceNumber || '').trim(),
                barcode: payload.barcode || '',
                invoiceUrl: finalInvoiceUrl || '',
                pd: payload.pdNumber || '',
                status: 'CONCLUÍDO',
                lots: [{
                    id: lotId,
                    lotNumber: payload.lotNumber || 'UNICO',
                    initialQuantity: Number(payload.quantity || 0),
                    remainingQuantity: Number(payload.quantity || 0),
                    expirationDate: payload.expirationDate || ''
                }]
            };

            if (mainSupplier) {
                const deliveriesRef = child(suppliersRef, `${mainSupplier.cpf}/deliveries`);
                await safeRunTransaction(deliveriesRef, (currentDeliveries) => {
                    let deliveries = Array.isArray(currentDeliveries) 
                        ? [...currentDeliveries] 
                        : (currentDeliveries ? Object.values(currentDeliveries) : []);
                    
                    // Remover agendamento pendente do mesmo dia
                    deliveries = deliveries.filter((d: any) => !(d.date === entryDate && d.item === 'AGENDAMENTO PENDENTE'));
                    
                    deliveries.push(newDelivery as any);
                    return deliveries;
                }, mainSupplier.deliveries || []);
            } else {
                // Determine which list and index the producer belongs to
                let listKey: string | null = null;
                let producerIdx = -1;

                const ppList = perCapitaConfig.ppaisProducers || [];
                producerIdx = ppList.findIndex(p => (cleanStr(p.cpfCnpj || p.cpf) === cleanPayloadCpf));
                if (producerIdx !== -1) {
                    listKey = 'ppaisProducers';
                } else {
                    const perecList = perCapitaConfig.pereciveisSuppliers || [];
                    producerIdx = perecList.findIndex(p => (cleanStr(p.cpfCnpj || p.cpf) === cleanPayloadCpf));
                    if (producerIdx !== -1) {
                        listKey = 'pereciveisSuppliers';
                    } else {
                        const estocList = perCapitaConfig.estocaveisSuppliers || [];
                        producerIdx = estocList.findIndex(p => (cleanStr(p.cpfCnpj || p.cpf) === cleanPayloadCpf));
                        if (producerIdx !== -1) listKey = 'estocaveisSuppliers';
                    }
                }

                if (listKey && producerIdx !== -1) {
                    // Update only the specific producer's deliveries to avoid locking the entire config
                    const producerDeliveriesRef = child(perCapitaConfigRef, `${listKey}/${producerIdx}/deliveries`);
                    await safeRunTransaction(producerDeliveriesRef, (currentDeliveries) => {
                        let deliveries = Array.isArray(currentDeliveries) 
                            ? [...currentDeliveries] 
                            : (currentDeliveries ? Object.values(currentDeliveries) : []);
                        
                        // Remover agendamento pendente do mesmo dia
                        deliveries = deliveries.filter((d: any) => !(d.date === entryDate && d.item === 'AGENDAMENTO PENDENTE'));
                        
                        deliveries.push(newDelivery);
                        return deliveries;
                    }, []);
                }
            }
        }

        return { success: true, message: 'Entrada registrada', invoiceUrl: finalInvoiceUrl };
    } catch (e) {
        console.error('Erro ao registrar entrada (tentando modo offline):', e);
        
        const offlineEntry = {
            ...payload,
            id: `off-ent-${Date.now()}`,
            timestamp: new Date().toISOString(),
            date: payload.invoiceDate || new Date().toISOString().split('T')[0],
            isOffline: true,
            type: 'entrada'
        };

        try {
            const currentOffline = JSON.parse(localStorage.getItem('offline_warehouse_entries') || '[]');
            currentOffline.push(offlineEntry);
            const saved = safeLocalStorageSetItem('offline_warehouse_entries', JSON.stringify(currentOffline));
            if (!saved) {
                return { success: false, message: 'Erro ao salvar offline: Limite de armazenamento local excedido.' };
            }
            return { success: true, message: 'Registrado offline com sucesso! Use o Módulo de Sincronização via Pendrive.' };
        } catch (storageError) {
            return { success: false, message: 'Erro ao salvar offline: ' + (storageError instanceof Error ? storageError.message : String(storageError)) };
        }
    }
  };

  const handleRegisterWarehouseWithdrawal = async (payload: any) => {
    console.log("Iniciando registro de saída:", payload.itemName, "Quantidade:", payload.quantity);
    try {
        const newRef = push(warehouseLogRef);
        
        // Find supplier in both lists
        const ppaisProducer = perCapitaConfig.ppaisProducers?.find(p => (p.cpfCnpj === payload.supplierCpf || p.cpf === payload.supplierCpf));
        const pereciveisSupplier = perCapitaConfig.pereciveisSuppliers?.find(p => (p.cpfCnpj === payload.supplierCpf || p.cpf === payload.supplierCpf));
        const estocavelSupplier = perCapitaConfig.estocaveisSuppliers?.find(p => (p.cpfCnpj === payload.supplierCpf || p.cpf === payload.supplierCpf));
        const mainSupplier = suppliers.find(s => s.cpf === payload.supplierCpf);
        
        const supplier = mainSupplier || ppaisProducer || pereciveisSupplier || estocavelSupplier;
        
        // --- Atualiza o saldo no lote do fornecedor ---
        if (supplier) {
            let updatedLotQty = 0;
            let transactionCommitted = false;

            if (mainSupplier) {
                console.log("Atualizando fornecedor principal via transação...");
                const deliveriesPath = `${mainSupplier.cpf}/deliveries`;
                const deliveriesRef = child(suppliersRef, deliveriesPath);
                
                const transactionResult = await safeRunTransaction(deliveriesRef, (currentDeliveries) => {
                    const deliveries = Array.isArray(currentDeliveries) ? currentDeliveries : (currentDeliveries ? Object.values(currentDeliveries) : []);
                    let found = false;
                    const updatedDeliveries = deliveries.map(d => {
                        if (d.item === payload.itemName && String(d.invoiceNumber) === String(payload.inboundInvoice)) {
                            if (d.lots) {
                                const lotIndex = d.lots.findIndex((l: any) => l.lotNumber === payload.lotNumber);
                                if (lotIndex !== -1) {
                                    updatedLotQty = (d.lots[lotIndex].remainingQuantity || 0) - payload.quantity;
                                    d.lots[lotIndex].remainingQuantity = updatedLotQty;
                                    found = true;
                                }
                            }
                        }
                        return d;
                    });
                    
                    if (found) return sanitizeForFirebase(updatedDeliveries);
                    return currentDeliveries;
                }, mainSupplier.deliveries || []);
                transactionCommitted = transactionResult.committed;
            } else {
                console.log("Atualizando produtor PerCapita via transação específica...");
                // Determine which list and index the producer belongs to
                let listKey: 'ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers' | null = null;
                let producerIdx = -1;

                if (perCapitaConfig.ppaisProducers) {
                    producerIdx = perCapitaConfig.ppaisProducers.findIndex(p => (p.cpfCnpj === payload.supplierCpf || p.cpf === payload.supplierCpf));
                    if (producerIdx !== -1) listKey = 'ppaisProducers';
                }
                if (listKey === null && perCapitaConfig.pereciveisSuppliers) {
                    producerIdx = perCapitaConfig.pereciveisSuppliers.findIndex(p => (p.cpfCnpj === payload.supplierCpf || p.cpf === payload.supplierCpf));
                    if (producerIdx !== -1) listKey = 'pereciveisSuppliers';
                }
                if (listKey === null && perCapitaConfig.estocaveisSuppliers) {
                    producerIdx = perCapitaConfig.estocaveisSuppliers.findIndex(p => (p.cpfCnpj === payload.supplierCpf || p.cpf === payload.supplierCpf));
                    if (producerIdx !== -1) listKey = 'estocaveisSuppliers';
                }

                if (listKey && producerIdx !== -1) {
                    const currentList = ensureArray<any>(perCapitaConfig[listKey]);
                    const deliveriesRef = child(perCapitaConfigRef, `${listKey}/${producerIdx}/deliveries`);
                    const transactionResult = await safeRunTransaction(deliveriesRef, (currentDeliveries) => {
                        const deliveries = Array.isArray(currentDeliveries) ? currentDeliveries : (currentDeliveries ? Object.values(currentDeliveries) : []);
                        let found = false;
                        const updatedDeliveries = deliveries.map(d => {
                            if (d.item === payload.itemName && String(d.invoiceNumber) === String(payload.inboundInvoice)) {
                                if (d.lots) {
                                    const lotIndex = d.lots.findIndex((l: any) => l.lotNumber === payload.lotNumber);
                                    if (lotIndex !== -1) {
                                        updatedLotQty = (d.lots[lotIndex].remainingQuantity || 0) - payload.quantity;
                                        d.lots[lotIndex].remainingQuantity = updatedLotQty;
                                        found = true;
                                    }
                                }
                            }
                            return d;
                        });
                        if (found) return sanitizeForFirebase(updatedDeliveries);
                        return currentDeliveries;
                    }, currentList[producerIdx]?.deliveries || []);
                    transactionCommitted = transactionResult.committed;
                }
            }
            
            if (!transactionCommitted) {
                console.warn("Transação de baixa falhou ou foi abortada.");
                return { success: false, message: 'Falha ao processar a baixa no estoque. Verifique se o lote e item estão corretos.' };
            }
            payload.remainingQuantity = updatedLotQty;
        }

        const exit: any = {
            id: newRef.key || `sai-${Date.now()}`,
            type: 'saída',
            timestamp: new Date().toISOString(),
            date: payload.date || new Date().toISOString().split('T')[0],
            itemName: payload.itemName,
            supplierName: supplier?.name || 'Desconhecido',
            lotNumber: payload.lotNumber || 'SAIDA_AVULSA',
            quantity: payload.quantity,
            barcode: payload.barcode || '',
            lotId: '',
            deliveryId: ''
        };
        if (payload.inboundInvoice !== undefined) exit.inboundInvoice = payload.inboundInvoice;
        if (payload.outboundInvoice !== undefined) {
            exit.outboundInvoice = payload.outboundInvoice;
        } else if (payload.invoiceNumber !== undefined) {
            exit.outboundInvoice = payload.invoiceNumber;
        }
        if (payload.expirationDate !== undefined) exit.expirationDate = payload.expirationDate;

        await set(newRef, sanitizeForFirebase(exit));
        console.log("Saída registrada com sucesso no log.");
        return { success: true, message: 'Saída registrada' };
    } catch (e) {
        console.error('Erro ao registrar saída (tentando modo offline):', e);
        // ... (rest of offline logic)

        const offlineWithdrawal = {
            ...payload,
            id: `off-sai-${Date.now()}`,
            timestamp: new Date().toISOString(),
            date: payload.date || new Date().toISOString().split('T')[0],
            isOffline: true,
            type: 'saída'
        };

        try {
            const currentOffline = JSON.parse(localStorage.getItem('offline_warehouse_entries') || '[]');
            currentOffline.push(offlineWithdrawal);
            const saved = safeLocalStorageSetItem('offline_warehouse_entries', JSON.stringify(currentOffline));
            if (!saved) {
                return { success: false, message: 'Erro ao salvar offline: Limite de armazenamento local excedido.' };
            }
            return { success: true, message: 'Registrado offline com sucesso! Use o Módulo de Sincronização via Pendrive.' };
        } catch (storageError) {
             return { success: false, message: 'Erro ao registrar offline: ' + (storageError instanceof Error ? storageError.message : String(storageError)) };
        }
    }
  };

  const handleResetWarehouseExits = async () => {
    try {
      const snapshot = await get(warehouseLogRef);
      const data = snapshot.val();
      if (data) {
        const updates: any = {};
        Object.entries(data).forEach(([key, value]: [string, any]) => {
          if (value.type === 'saída') {
            updates[key] = null;
          }
        });
        await update(warehouseLogRef, updates);
      }
      return { success: true, message: 'Registros de saída zerados com sucesso.' };
    } catch (e: any) {
      return { success: false, message: 'Falha ao zerar registros de saída.', detail: e.message };
    }
  };

  const handleDeleteWarehouseEntry = async (l: WarehouseMovement) => {
      // Se for saída, devolve a quantidade para o saldo do lote
      if (l.type === 'saída' || l.type === 'saida') {
        const mainSupplier = suppliers.find(s => s.cpf === l.supplierCpf);
        const ppaisProducer = perCapitaConfig.ppaisProducers?.find(p => p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf);
        const pereciveisSupplier = perCapitaConfig.pereciveisSuppliers?.find(p => p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf);
        const estocavelSupplier = perCapitaConfig.estocaveisSuppliers?.find(p => p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf);
          
        if (mainSupplier) {
            const deliveriesRef = child(suppliersRef, `${mainSupplier.cpf}/deliveries`);
            await safeRunTransaction(deliveriesRef, (currentDeliveries) => {
                if (currentDeliveries) {
                    const deliveries = Array.isArray(currentDeliveries) ? currentDeliveries : Object.values(currentDeliveries);
                    let found = false;
                    const updatedDeliveries = deliveries.map(d => {
                        if (d.item === l.itemName && String(d.invoiceNumber) === String(l.inboundInvoice || l.invoiceNumber || '')) {
                            if (d.lots) {
                                const lotIndex = d.lots.findIndex((lotItem: any) => lotItem.lotNumber === l.lotNumber);
                                if (lotIndex !== -1) {
                                    d.lots[lotIndex].remainingQuantity = (d.lots[lotIndex].remainingQuantity || 0) + l.quantity;
                                    found = true;
                                }
                            }
                        }
                        return d;
                    });
                    if (found) return sanitizeForFirebase(updatedDeliveries);
                }
                return currentDeliveries;
            }, mainSupplier.deliveries || []);
        } else if (ppaisProducer || pereciveisSupplier || estocavelSupplier) {
            let listKey: 'ppaisProducers' | 'pereciveisSuppliers' | 'estocaveisSuppliers' | null = null;
            let producerIdx = -1;

            if (perCapitaConfig.ppaisProducers) {
                producerIdx = perCapitaConfig.ppaisProducers.findIndex(p => p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf);
                if (producerIdx !== -1) listKey = 'ppaisProducers';
            }
            if (listKey === null && perCapitaConfig.pereciveisSuppliers) {
                producerIdx = perCapitaConfig.pereciveisSuppliers.findIndex(p => p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf);
                if (producerIdx !== -1) listKey = 'pereciveisSuppliers';
            }
            if (listKey === null && perCapitaConfig.estocaveisSuppliers) {
                producerIdx = perCapitaConfig.estocaveisSuppliers.findIndex(p => p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf);
                if (producerIdx !== -1) listKey = 'estocaveisSuppliers';
            }

            if (listKey && producerIdx !== -1) {
                const currentList = ensureArray<any>(perCapitaConfig[listKey]);
                const deliveriesRef = child(perCapitaConfigRef, `${listKey}/${producerIdx}/deliveries`);
                await safeRunTransaction(deliveriesRef, (currentDeliveries) => {
                    if (currentDeliveries) {
                        const deliveries = Array.isArray(currentDeliveries) ? currentDeliveries : Object.values(currentDeliveries);
                        let found = false;
                        const updatedDeliveries = deliveries.map(d => {
                            if (d.item === l.itemName && String(d.invoiceNumber) === String(l.inboundInvoice || l.invoiceNumber || '')) {
                                if (d.lots) {
                                    const lotIndex = d.lots.findIndex((lotItem: any) => lotItem.lotNumber === l.lotNumber);
                                    if (lotIndex !== -1) {
                                        d.lots[lotIndex].remainingQuantity = (d.lots[lotIndex].remainingQuantity || 0) + l.quantity;
                                        found = true;
                                    }
                                }
                            }
                            return d;
                        });
                        if (found) return sanitizeForFirebase(updatedDeliveries);
                    }
                    return currentDeliveries;
                }, currentList[producerIdx]?.deliveries || []);
            }
        }
      } else if (l.type === 'entrada') {
          // Se for entrada, remove a entrega correspondente do fornecedor
          const mainSupplier = suppliers.find(s => s.cpf === l.supplierCpf);
          const ppaisProducer = perCapitaConfig.ppaisProducers?.find(p => p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf);
          const pereciveisSupplier = perCapitaConfig.pereciveisSuppliers?.find(p => p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf);
          const estocavelSupplier = perCapitaConfig.estocaveisSuppliers?.find(p => p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf);

          if (mainSupplier) {
              const sRef = child(suppliersRef, mainSupplier.cpf);
              await safeRunTransaction(sRef, (currentData: Supplier) => {
                  if (currentData && currentData.deliveries) {
                      currentData.deliveries = currentData.deliveries.filter(d => 
                          !(d.item === l.itemName && String(d.invoiceNumber) === String(l.inboundInvoice || l.invoiceNumber || '') && d.barcode === l.barcode)
                      );
                      return sanitizeForFirebase(currentData);
                  }
                  return currentData;
              }, mainSupplier);
          } else if (ppaisProducer || pereciveisSupplier || estocavelSupplier) {
              const targetSupplier = (ppaisProducer || pereciveisSupplier || estocavelSupplier)!;
              const targetCpf = targetSupplier.cpfCnpj || targetSupplier.cpf;
              await safeRunTransaction(perCapitaConfigRef, (currentData: PerCapitaConfig) => {
                  if (currentData) {
                      const updateInList = (list: any[] | undefined) => {
                          if (!list) return false;
                          const s = list.find(p => (p.cpfCnpj === targetCpf || p.cpf === targetCpf));
                          if (s && s.deliveries) {
                              s.deliveries = s.deliveries.filter((d: any) => 
                                  !(d.item === l.itemName && String(d.invoiceNumber) === String(l.inboundInvoice || l.invoiceNumber || '') && d.barcode === l.barcode)
                              );
                              return true;
                          }
                          return false;
                      };
                      if (updateInList(currentData.ppaisProducers) || 
                          updateInList(currentData.pereciveisSuppliers) || 
                          updateInList(currentData.estocaveisSuppliers)) {
                          return sanitizeForFirebase(currentData);
                      }
                  }
                  return currentData;
              }, perCapitaConfig);
          }
      }
      await remove(child(warehouseLogRef, l.id));
      return { success: true, message: 'Excluído e saldo atualizado' };
  };

  const handleUpdateWarehouseEntry = async (l: WarehouseMovement) => {
      await set(child(warehouseLogRef, l.id), sanitizeForFirebase(l));
      
      // --- Sincronizar com as entregas do fornecedor ---
      if (l.type === 'entrada') {
          const mainSupplier = suppliers.find(s => s.cpf === l.supplierCpf);
          if (mainSupplier) {
              const sRef = child(suppliersRef, mainSupplier.cpf);
              await safeRunTransaction(sRef, (currentData: Supplier) => {
                  if (currentData && currentData.deliveries) {
                      currentData.deliveries = currentData.deliveries.map(d => {
                          if (String(d.invoiceNumber) === String(l.inboundInvoice) && d.item === l.itemName && d.barcode === l.barcode) {
                              return {
                                  ...d,
                                  kg: l.quantity,
                                  value: l.value,
                                  lots: d.lots?.map(lot => lot.id === (l as any).lotId ? { ...lot, initialQuantity: l.quantity, lotNumber: l.lotNumber } : lot) || []
                              };
                          }
                          return d;
                      });
                      return sanitizeForFirebase(currentData);
                  }
                  return currentData;
              }, mainSupplier);
          } else {
              await safeRunTransaction(perCapitaConfigRef, (currentData: PerCapitaConfig) => {
                  if (currentData) {
                      const updateList = (list: any[] | undefined) => {
                          const s = list?.find(p => (p.cpfCnpj === l.supplierCpf || p.cpf === l.supplierCpf));
                          if (s && s.deliveries) {
                              s.deliveries = s.deliveries.map((d: any) => {
                                  if (String(d.invoiceNumber) === String(l.inboundInvoice) && d.item === l.itemName && d.barcode === l.barcode) {
                                      return {
                                          ...d,
                                          kg: l.quantity,
                                          value: l.value,
                                          lots: d.lots?.map((lot: any) => lot.id === (l as any).lotId ? { ...lot, initialQuantity: l.quantity, lotNumber: l.lotNumber } : lot) || []
                                      };
                                  }
                                  return d;
                              });
                              return true;
                          }
                          return false;
                      };
                      if (updateList(currentData.ppaisProducers) || updateList(currentData.pereciveisSuppliers) || updateList(currentData.estocaveisSuppliers)) {
                          return sanitizeForFirebase(currentData);
                      }
                  }
                  return currentData;
              }, perCapitaConfig);
          }
      }

      return { success: true, message: 'Atualizado' };
  };

  const combinedSuppliers = React.useMemo(() => {
    return getCombinedSuppliers(suppliers, perCapitaConfig);
  }, [suppliers, perCapitaConfig]);

  const renderContent = () => {
    console.log("renderContent called, hasError:", hasError, "user:", user);
    if (hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-zinc-950 p-4">
          <div className="bg-white/5 backdrop-blur-2xl p-10 rounded-[2.5rem] border border-white/10 shadow-2xl text-center max-w-md">
            <div className="bg-indigo-500/10 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 border border-indigo-500/20">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tight mb-4">Erro de Transmissão</h2>
            <p className="text-slate-400 text-sm font-medium leading-relaxed mb-8">
              Ocorreu um erro ao carregar o seu perfil. Isso pode ser causado por oscilação na rede ou inconsistência nos dados de cache.
            </p>
            <div className="bg-black/20 p-4 rounded-2xl mb-8 border border-white/5">
              <p className="text-[10px] font-mono text-slate-500 break-all">{errorDetails || 'Error code: 0x882'}</p>
            </div>
            <button 
              onClick={() => {
                localStorage.clear();
                window.location.reload();
              }} 
              className="w-full bg-indigo-600 text-white font-black py-4 px-8 rounded-2xl text-xs uppercase tracking-widest hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-900/40"
            >
              Recarregar Sistema
            </button>
          </div>
        </div>
      );
    }

    try {
      if (!user) {
        const isLoadingEssential = !isPasswordsLoaded || !isSuppliersLoaded || !isPerCapitaConfigLoaded;
        return <LoginScreen onLogin={handleLogin} publicInfoList={publicInfo} isLoading={isLoadingEssential} />;
      }

    if (user.role === 'admin') {
      return (
        <AdminDashboard 
          user={user}
          suppliers={combinedSuppliers} 
          onRegister={handleRegisterSupplier}
          onSyncPPAISToAgenda={handleSyncPPAISToAgenda}
          onUpdateSupplier={handleUpdateSupplier}
          onUpdateSupplierObservations={handleUpdateSupplierObservations}
          onDeleteDelivery={handleDeleteDelivery}
          onUpdateDelivery={handleUpdateDelivery}
          onSaveInvoice={handleSaveInvoice}
          onLogout={handleLogout}
          warehouseLog={warehouseLog}
          perCapitaConfig={perCapitaConfig}
          onUpdatePerCapitaConfig={handleUpdatePerCapitaConfig}
          cleaningLogs={cleaningLogs}
          onRegisterCleaningLog={async (l) => {
              const r = push(cleaningLogsRef);
              await set(r, { ...l, id: r.key });
              return { success: true, message: 'Ok' };
          }}
          onDeleteCleaningLog={async (id) => remove(child(cleaningLogsRef, id))}
          epiLogs={epiLogs}
          onRegisterEpi={async (l) => {
              const r = push(epiLogsRef);
              await set(r, { ...l, id: r.key });
              return { success: true, message: 'Ok' };
          }}
          onDeleteEpi={async (id) => remove(child(epiLogsRef, id))}
          financialRecords={financialRecords}
          onSaveFinancialRecord={async (rec) => {
              const id = rec.id || push(financialRecordsRef).key;
              await set(child(financialRecordsRef, id!), { ...rec, id });
              return { success: true };
          }}
          onDeleteFinancialRecord={async (id) => remove(child(financialRecordsRef, id))}
          thirdPartyEntries={thirdPartyEntries}
          onRegisterThirdPartyEntry={async (l) => {
              const r = push(thirdPartyEntriesRef);
              await set(r, { ...l, id: r.key });
              return { success: true, message: 'Ok' };
          }}
          onUpdateThirdPartyEntry={async (log) => {
              await set(child(thirdPartyEntriesRef, log.id), log);
              return { success: true, message: 'Atualizado' };
          }}
          onDeleteThirdPartyEntry={async (id) => remove(child(thirdPartyEntriesRef, id))}
          vehicleExitOrders={vehicleExitOrders}
          onRegisterVehicleExitOrder={async (order) => {
              const r = push(vehicleExitOrdersRef);
              await set(r, { ...order, id: r.key });
              return { success: true, message: 'Ordem de Saída registrada com sucesso!' };
          }}
          onUpdateVehicleExitOrder={async (order) => {
              await set(child(vehicleExitOrdersRef, order.id), order);
              return { success: true, message: 'Ordem de Saída atualizada com sucesso!' };
          }}
          onDeleteVehicleExitOrder={async (id) => {
              console.log("Deleting vehicle exit order (AdminDashboard) with ID:", id);
              await remove(child(vehicleExitOrdersRef, id));
              return { success: true, message: 'Ordem de saída excluída com sucesso!' };
          }}
          vehicleAssets={vehicleAssets}
          onRegisterVehicleAsset={async (asset) => {
              const r = push(vehicleAssetsRef);
              await set(r, { ...asset, id: r.key });
              return { success: true, message: 'Veículo registrado' };
          }}
          onUpdateVehicleAsset={async (asset) => {
              await set(child(vehicleAssetsRef, asset.id), asset);
              return { success: true, message: 'Veículo atualizado' };
          }}
          onDeleteVehicleAsset={async (id) => remove(child(vehicleAssetsRef, id))}
          driverAssets={driverAssets}
          onRegisterDriverAsset={async (asset) => {
              const r = push(driverAssetsRef);
              await set(r, { ...asset, id: r.key });
              return { success: true, message: 'Motorista/Acompanhante registrado' };
          }}
          onUpdateDriverAsset={async (asset) => {
              await set(child(driverAssetsRef, asset.id), asset);
              return { success: true, message: 'Motorista/Acompanhante atualizado' };
          }}
          onDeleteDriverAsset={async (id) => remove(child(driverAssetsRef, id))}
          onCancelDeliveries={handleCancelDeliveries}
          onUpdateContractForItem={handleUpdateContractForItem}
          onUpdateAcquisitionItem={handleUpdateAcquisitionItem}
          onDeleteAcquisitionItem={handleDeleteAcquisitionItem}
          acquisitionItems={acquisitionItems}
          directorPerCapita={directorPerCapita}
          directorWithdrawals={directorWithdrawals}
          onRegisterDirectorWithdrawal={async (log) => {
               const newRef = push(directorWithdrawalsRef);
               await set(newRef, { ...log, id: newRef.key });
               return { success: true, message: 'Ok' };
          }}
          onDeleteDirectorWithdrawal={async (id) => {
            if (id.startsWith('pedido_') && directorPerCapita) {
              const paths = [
                ['chefeDep', 'history'],
                ['chefeDep', 'limpezaHistory'],
                ['chefeSeg', 'history'],
                ['chefeSeg', 'limpezaHistory'],
              ];
              for (const [dep, hKey] of paths) {
                if (directorPerCapita[dep] && directorPerCapita[dep][hKey] && directorPerCapita[dep][hKey][id]) {
                  await remove(child(directorPerCapitaRef, `${dep}/${hKey}/${id}`));
                  return;
                }
              }
            }
            await remove(child(directorWithdrawalsRef, id));
          }}
          standardMenu={standardMenu}
          dailyMenus={dailyMenus}
          serviceOrders={serviceOrders}
          maintenanceSchedules={maintenanceSchedules}
          onUpdateServiceOrder={handleUpdateServiceOrder}
          onDeleteServiceOrder={handleDeleteServiceOrder}
          onRegisterMaintenanceSchedule={async (schedule) => {
            const r = push(maintenanceSchedulesRef);
            await set(r, { ...schedule, id: r.key });
            return { success: true, message: 'Agendamento registrado' };
          }}
          onUpdateMaintenanceSchedule={handleUpdateMaintenanceSchedule}
          onDeleteMaintenanceSchedule={handleDeleteMaintenanceSchedule}
          onRestoreInfrastructureData={handleRestoreInfrastructureData}
          vehicleInspections={vehicleInspections}
          onRegisterVehicleInspection={async (inspection) => {
            const r = push(vehicleInspectionsRef);
            await set(r, { ...inspection, id: r.key });
            return { success: true, message: 'Inspeção registrada' };
          }}
          onUpdateVehicleInspection={async (inspection) => {
            await set(child(vehicleInspectionsRef, inspection.id), inspection);
            return { success: true, message: 'Inspeção atualizada' };
          }}
          onDeleteVehicleInspection={async (id) => remove(child(vehicleInspectionsRef, id))}
          onUpdateStandardMenu={handleUpdateStandardMenu}
          onUpdateDailyMenu={handleUpdateDailyMenu}
          onRegisterEntry={handleRegisterWarehouseEntry}
          onRegisterWithdrawal={handleRegisterWarehouseWithdrawal}
          onReopenInvoice={handleReopenInvoice}
          onDeleteInvoice={async (supplierCpf, invoiceNumber) => {
            await handleDeleteInvoice(supplierCpf, invoiceNumber);
          }}
          onUpdateInvoiceItems={handleUpdateInvoiceItems}
          onUpdateInvoiceUrl={handleUpdateInvoiceUrl}
          onManualInvoiceEntry={handleManualInvoiceEntry}
          onMarkInvoiceAsOpened={handleMarkInvoiceAsOpened}
          onDeleteWarehouseEntry={handleDeleteWarehouseEntry}
          onUpdateWarehouseEntry={handleUpdateWarehouseEntry}
          onPersistSuppliers={() => {}}
          onRestoreData={async () => true}
          onRestoreFullBackup={handleRestoreFullBackup}
          onResetData={async () => { await set(rootRef, null); }}
          registrationStatus={null}
          onClearRegistrationStatus={() => {}}
          validationRoles={validationRoles}
          systemPasswords={systemPasswords}
          onUpdateSystemPassword={async (key, pass) => {
            await set(child(systemPasswordsRef, key), pass);
          }}
          publicInfo={publicInfo}
          onSavePublicInfo={handleSavePublicInfo}
          onDeletePublicInfo={handleDeletePublicInfo}
          energyAccountingRecords={energyAccountingRecords}
          onSaveEnergyAccountingRecord={handleSaveEnergyAccountingRecord}
          onDeleteEnergyAccountingRecord={handleDeleteEnergyAccountingRecord}
        />
      );
    }

    if (user.role === 'financeiro') {
      return <FinanceDashboard 
               records={financialRecords} 
               onLogout={handleLogout} 
               user={user}
               standardMenu={standardMenu}
               dailyMenus={dailyMenus}
               suppliers={combinedSuppliers}
               thirdPartyEntries={thirdPartyEntries}
               vehicleExitOrders={vehicleExitOrders}
               vehicleAssets={vehicleAssets}
               driverAssets={driverAssets}
               validationRoles={validationRoles}
               directorPerCapita={directorPerCapita}
               onUpdateDirectorPerCapita={handleUpdateDirectorPerCapita}
               warehouseLog={warehouseLog}
               perCapitaConfig={perCapitaConfig}
               epiLogs={epiLogs}
               acquisitionItems={acquisitionItems}
               cleaningLogs={cleaningLogs || []}
               onRegisterCleaningLog={async (l) => {
                   const r = push(cleaningLogsRef);
                   await set(r, { ...l, id: r.key });
                   return { success: true, message: 'Ok' };
               }}
               onDeleteCleaningLog={async (id) => remove(child(cleaningLogsRef, id))}
               temperatureLogs={temperatureLogs || []}
               onRegisterTemperatureLog={async (l) => {
                   const r = push(temperatureLogsRef);
                   await set(r, { ...l, id: r.key });
                   return { success: true, message: 'Ok' };
               }}
               onDeleteTemperatureLog={async (id) => remove(child(temperatureLogsRef, id))}
               onUpdatePerCapitaConfig={handleUpdatePerCapitaConfig}
               onUpdateContractForItem={handleUpdateContractForItem}
               onUpdateAcquisitionItem={handleUpdateAcquisitionItem}
               onDeleteAcquisitionItem={handleDeleteAcquisitionItem}
               onUpdateSupplierObservations={handleUpdateSupplierObservations}
               onSyncPPAISToAgenda={handleSyncPPAISToAgenda}
               onSaveInvoice={handleSaveInvoice}
               onDeleteDelivery={handleDeleteDelivery}
               onUpdateDailyMenu={handleUpdateDailyMenu}
               marmitaWeightLogs={marmitaWeightLogs || []}
               onRegisterMarmitaWeightLog={async (l) => {
                   const r = push(marmitaWeightLogsRef);
                   await set(r, { ...l, id: r.key });
                   return { success: true, message: 'Ok' };
               }}
               onDeleteMarmitaWeightLog={async (id) => remove(child(marmitaWeightLogsRef, id))}
               serviceOrders={serviceOrders}
               onRegisterServiceOrder={handleRegisterServiceOrder}
               onUpdateServiceOrder={handleUpdateServiceOrder}
               onDeleteServiceOrder={handleDeleteServiceOrder}
               maintenanceSchedules={maintenanceSchedules}
               onRegisterMaintenanceSchedule={handleRegisterMaintenanceSchedule}
               onUpdateMaintenanceSchedule={handleUpdateMaintenanceSchedule}
               onDeleteMaintenanceSchedule={handleDeleteMaintenanceSchedule}
             />;
    }

    if (user.role === 'cardapio') {
      return <MenuDashboard standardMenu={standardMenu || {}} dailyMenus={dailyMenus || {}} suppliers={combinedSuppliers || []} onLogout={handleLogout} />;
    }

    if (user.role === 'almoxarifado') {
      return <AlmoxarifadoDashboard 
               currentUser={user}
               suppliers={combinedSuppliers || []} 
               warehouseLog={warehouseLog || []} 
               onLogout={handleLogout} 
               publicInfoList={publicInfo || []}
               onRegisterEntry={handleRegisterWarehouseEntry} 
               onRegisterWithdrawal={handleRegisterWarehouseWithdrawal} 
               onResetExits={handleResetWarehouseExits}
               onReopenInvoice={handleReopenInvoice}
               onUpdateInvoiceItems={handleUpdateInvoiceItems}
               onUpdateInvoiceUrl={handleUpdateInvoiceUrl}
               onManualInvoiceEntry={handleManualInvoiceEntry}
               onMarkInvoiceAsOpened={handleMarkInvoiceAsOpened}
               onDeleteWarehouseEntry={handleDeleteWarehouseEntry}
               onUpdateWarehouseEntry={handleUpdateWarehouseEntry}
               onDeleteInvoice={handleDeleteInvoice}
               onDeleteDelivery={handleDeleteDelivery}
               onUpdateDelivery={handleUpdateDelivery}
               onSaveInvoice={handleSaveInvoice}
               thirdPartyEntries={thirdPartyEntries || []}
               perCapitaConfig={perCapitaConfig || {}}
               acquisitionItems={acquisitionItems || []}
               onRegisterThirdPartyEntry={async (l) => {
                   const r = push(thirdPartyEntriesRef);
                   await set(r, { ...l, id: r.key });
                   return { success: true, message: 'Ok' };
               }}
               onUpdateThirdPartyEntry={async (log) => {
                   await set(child(thirdPartyEntriesRef, log.id), log);
                   return { success: true, message: 'Atualizado' };
               }}
               onDeleteThirdPartyEntry={async (id) => remove(child(thirdPartyEntriesRef, id))}
               vehicleExitOrders={vehicleExitOrders}
               onRegisterVehicleExitOrder={async (order) => {
                   const r = push(vehicleExitOrdersRef);
                   const id = r.key || `order-${Date.now()}`;
                   await set(r, { ...order, id });
                   return { success: true, message: 'Ok', id };
               }}
               onUpdateVehicleExitOrder={async (order) => {
                   await set(child(vehicleExitOrdersRef, order.id), order);
                   return { success: true, message: 'Atualizado' };
               }}
               onDeleteVehicleExitOrder={undefined}
               vehicleAssets={vehicleAssets}
               onRegisterVehicleAsset={async (asset) => {
                   const r = push(vehicleAssetsRef);
                   await set(r, { ...asset, id: r.key });
                   return { success: true, message: 'Veículo registrado' };
               }}
               onUpdateVehicleAsset={async (asset) => {
                   await set(child(vehicleAssetsRef, asset.id), asset);
                   return { success: true, message: 'Veículo atualizado' };
               }}
               onDeleteVehicleAsset={async (id) => remove(child(vehicleAssetsRef, id))}
               driverAssets={driverAssets}
               onRegisterDriverAsset={async (asset) => {
                   const r = push(driverAssetsRef);
                   await set(r, { ...asset, id: r.key });
                   return { success: true, message: 'Motorista/Acompanhante registrado' };
               }}
               onUpdateDriverAsset={async (asset) => {
                   await set(child(driverAssetsRef, asset.id), asset);
                   return { success: true, message: 'Motorista/Acompanhante atualizado' };
               }}
               onDeleteDriverAsset={async (id) => remove(child(driverAssetsRef, id))}
               validationRoles={validationRoles}
               standardMenu={standardMenu}
               dailyMenus={dailyMenus}
               onUpdateStandardMenu={handleUpdateStandardMenu}
               onUpdateDailyMenu={handleUpdateDailyMenu}
               directorPerCapita={directorPerCapita}
               onUpdateDirectorPerCapita={handleUpdateDirectorPerCapita}
               cleaningLogs={cleaningLogs || []}
               segregationLogs={segregationLogs || []}
               onRegisterSegregationLog={async (l) => {
                   const r = push(segregationLogsRef);
                   await set(r, { ...l, id: r.key });
                   return { success: true, message: 'Item segregado registrado com sucesso' };
               }}
               onUpdateSegregationLog={async (log) => {
                   await set(child(segregationLogsRef, log.id), log);
                   return { success: true, message: 'Item segregado atualizado com sucesso' };
               }}
               onDeleteSegregationLog={async (id) => remove(child(segregationLogsRef, id))}
               financialRecords={financialRecords || []}
               onRegisterCleaningLog={async (l) => {
                   const r = push(cleaningLogsRef);
                   await set(r, { ...l, id: r.key });
                   return { success: true, message: 'Ok' };
               }}
               onDeleteCleaningLog={async (id) => remove(child(cleaningLogsRef, id))}
               temperatureLogs={temperatureLogs || []}
               onRegisterTemperatureLog={async (l) => {
                   const r = push(temperatureLogsRef);
                   await set(r, { ...l, id: r.key });
                   return { success: true, message: 'Ok' };
               }}
               onDeleteTemperatureLog={async (id) => remove(child(temperatureLogsRef, id))}
               marmitaWeightLogs={marmitaWeightLogs || []}
               onRegisterMarmitaWeightLog={async (l) => {
                   const r = push(marmitaWeightLogsRef);
                   await set(r, { ...l, id: r.key });
                   return { success: true, message: 'Ok' };
               }}
               onDeleteMarmitaWeightLog={async (id) => remove(child(marmitaWeightLogsRef, id))}
               serviceOrders={serviceOrders}
               onRegisterServiceOrder={handleRegisterServiceOrder}
               onUpdateServiceOrder={handleUpdateServiceOrder}
               onDeleteServiceOrder={handleDeleteServiceOrder}
               maintenanceSchedules={maintenanceSchedules}
               onRegisterMaintenanceSchedule={handleRegisterMaintenanceSchedule}
               onUpdateMaintenanceSchedule={handleUpdateMaintenanceSchedule}
               onDeleteMaintenanceSchedule={handleDeleteMaintenanceSchedule}
               onRestoreInfrastructureData={handleRestoreInfrastructureData}
             />;
    }

    if (user.role === 'julio') {
      return (
        <JulioDashboard
          vehicleExitOrders={vehicleExitOrders}
          vehicleInspections={vehicleInspections}
          driverAssets={driverAssets}
          vehicleAssets={vehicleAssets}
          validationRoles={validationRoles}
          serviceOrders={serviceOrders}
          maintenanceSchedules={maintenanceSchedules}
          onUpdateServiceOrder={handleUpdateServiceOrder}
          onDeleteServiceOrder={handleDeleteServiceOrder}
          onRegisterMaintenanceSchedule={handleRegisterMaintenanceSchedule}
          onUpdateMaintenanceSchedule={handleUpdateMaintenanceSchedule}
          onDeleteMaintenanceSchedule={handleDeleteMaintenanceSchedule}
          onLogout={handleLogout}
          onRegisterVehicleExitOrder={async (order) => {
            const r = push(vehicleExitOrdersRef);
            await set(r, { ...order, id: r.key });
            return { success: true, message: 'Ordem de saída registrada' };
          }}
          onUpdateVehicleExitOrder={async (order) => {
            await set(child(vehicleExitOrdersRef, order.id), order);
            return { success: true, message: 'Ordem de saída atualizada' };
          }}
          onDeleteVehicleExitOrder={async (id) => {
            console.log("Deleting vehicle exit order (JulioDashboard) with ID:", id);
            await remove(child(vehicleExitOrdersRef, id));
            return { success: true, message: 'Ordem de saída excluída' };
          }}
          onRegisterDriverAsset={async (s) => {
            const r = push(driverAssetsRef);
            await set(r, { ...s, id: r.key });
            return { success: true, message: 'Servidor registrado' };
          }}
          onUpdateDriverAsset={async (s) => {
            await set(child(driverAssetsRef, s.id), s);
            return { success: true, message: 'Servidor atualizado' };
          }}
          onDeleteDriverAsset={async (id) => {
            await remove(child(driverAssetsRef, id));
            return { success: true, message: 'Servidor excluído' };
          }}
          onRegisterVehicleAsset={async (v) => {
            const r = push(vehicleAssetsRef);
            await set(r, { ...v, id: r.key });
            return { success: true, message: 'Veículo registrado' };
          }}
          onUpdateVehicleAsset={async (v) => {
            await set(child(vehicleAssetsRef, v.id), v);
            return { success: true, message: 'Veículo atualizado' };
          }}
          onDeleteVehicleAsset={async (id) => {
            await remove(child(vehicleAssetsRef, id));
            return { success: true, message: 'Veículo excluído' };
          }}
          onRegisterValidationRole={async (vr) => {
            const r = push(validationRolesRef);
            await set(r, { ...vr, id: r.key });
            return { success: true, message: 'Cargo de validação registrado' };
          }}
          onUpdateValidationRole={async (vr) => {
            await set(child(validationRolesRef, vr.id), vr);
            return { success: true, message: 'Cargo de validação atualizado' };
          }}
          onDeleteValidationRole={async (id) => {
            await remove(child(validationRolesRef, id));
            return { success: true, message: 'Cargo excluído' };
          }}
          onRegisterVehicleInspection={async (inspection) => {
            const r = push(vehicleInspectionsRef);
            await set(r, { ...inspection, id: r.key });
            return { success: true, message: 'Inspeção registrada' };
          }}
          onUpdateVehicleInspection={async (inspection) => {
            await set(child(vehicleInspectionsRef, inspection.id), inspection);
            return { success: true, message: 'Inspeção atualizada' };
          }}
          onDeleteVehicleInspection={async (id) => {
            await remove(child(vehicleInspectionsRef, id));
            return { success: true, message: 'Inspeção excluída' };
          }}
        />
      );
    }

    if (user.role === 'itesp') {
      return <ItespDashboard suppliers={combinedSuppliers} warehouseLog={warehouseLog} perCapitaConfig={perCapitaConfig} onLogout={handleLogout} />;
    }

    if (user.role === 'subportaria') {
      return (
        <SubportariaDashboard 
          suppliers={combinedSuppliers} 
          perCapitaConfig={perCapitaConfig}
          thirdPartyEntries={thirdPartyEntries}
          onUpdateDelivery={handleUpdateDelivery}
          maintenanceSchedules={maintenanceSchedules}
          serviceOrders={serviceOrders}
          publicInfoList={publicInfo}
          onUpdateMaintenanceSchedule={async (id, updates) => {
            return await handleUpdateMaintenanceSchedule(id, updates);
          }}
          onUpdateThirdPartyEntry={async (log) => {
            await set(child(thirdPartyEntriesRef, log.id), log);
            return { success: true, message: 'Atualizado' };
          }}
          onLogout={handleLogout} 
          vehicleExitOrders={vehicleExitOrders}
          vehicleAssets={vehicleAssets}
          driverAssets={driverAssets}
          validationRoles={validationRoles}
          onRegisterVehicleExitOrder={async (order) => {
            const r = push(vehicleExitOrdersRef);
            const id = r.key || `order-${Date.now()}`;
            await set(r, { ...order, id });
            return { success: true, message: 'Ordem de saída registrada', id };
          }}
          onUpdateVehicleExitOrder={async (order) => {
            await set(child(vehicleExitOrdersRef, order.id), order);
            return { success: true, message: 'Atualizado' };
          }}
          onDeleteVehicleExitOrder={async (id) => {
            await remove(child(vehicleExitOrdersRef, id));
            return { success: true, message: 'Ordem de Saída excluída' };
          }}
          onRegisterVehicleAsset={async (v) => {
            const r = push(vehicleAssetsRef);
            await set(r, { ...v, id: r.key });
            return { success: true, message: 'Veículo registrado' };
          }}
          onUpdateVehicleAsset={async (v) => {
            await set(child(vehicleAssetsRef, v.id), v);
            return { success: true, message: 'Atualizado' };
          }}
          onDeleteVehicleAsset={async (id) => {
            await remove(child(vehicleAssetsRef, id));
            return { success: true, message: 'Veículo excluído' };
          }}
          onRegisterDriverAsset={async (d) => {
            const r = push(driverAssetsRef);
            await set(r, { ...d, id: r.key });
            return { success: true, message: 'Motorista registrado' };
          }}
          onUpdateDriverAsset={async (d) => {
            await set(child(driverAssetsRef, d.id), d);
            return { success: true, message: 'Atualizado' };
          }}
          onDeleteDriverAsset={async (id) => {
            await remove(child(driverAssetsRef, id));
            return { success: true, message: 'Motorista excluído' };
          }}
          onDeleteThirdPartyEntry={async (id) => {
            await remove(child(thirdPartyEntriesRef, id));
            return { success: true, message: 'Excluído' };
          }}
          systemPasswords={systemPasswords}
          onUpdateSystemPassword={async (key: string, value: string) => {
            await update(systemPasswordsRef, { [key]: value });
          }}
        />
      );
    }

    if (user.role === 'ordem_servico') {
      return (
        <ServiceOrderDashboard
          serviceOrders={serviceOrders}
          maintenanceSchedules={maintenanceSchedules}
          onRegisterServiceOrder={handleRegisterServiceOrder}
          onLogout={handleLogout}
          onRestoreInfrastructureData={handleRestoreInfrastructureData}
        />
      );
    }

    if (user.role === 'infraestrutura' || user.role === 'ordem_saida') {
      return (
        <VehicleOrderDashboard 
          orders={vehicleExitOrders}
          vehicleAssets={vehicleAssets}
          driverAssets={driverAssets}
          validationRoles={validationRoles}
          serviceOrders={serviceOrders}
          maintenanceSchedules={maintenanceSchedules}
          vehicleInspections={vehicleInspections}
          warehouseLog={warehouseLog || []}
          suppliers={combinedSuppliers || []}
          perCapitaConfig={perCapitaConfig || {}}
          energyAccountingRecords={energyAccountingRecords}
          onSaveEnergyAccountingRecord={handleSaveEnergyAccountingRecord}
          onDeleteEnergyAccountingRecord={handleDeleteEnergyAccountingRecord}
          onUpdateServiceOrder={handleUpdateServiceOrder}
          onDeleteServiceOrder={handleDeleteServiceOrder}
          onRegisterMaintenanceSchedule={handleRegisterMaintenanceSchedule}
          onUpdateMaintenanceSchedule={handleUpdateMaintenanceSchedule}
          onDeleteMaintenanceSchedule={handleDeleteMaintenanceSchedule}
          onRestoreInfrastructureData={handleRestoreInfrastructureData}
          onRegister={async (order) => {
            const r = push(vehicleExitOrdersRef);
            const id = r.key || `order-${Date.now()}`;
            await set(r, { ...order, id });
            return { success: true, message: 'Ok', id };
          }}
          onUpdate={async (order) => {
            await set(child(vehicleExitOrdersRef, order.id), order);
            return { success: true, message: 'Atualizado' };
          }}
          onDelete={async (id) => {
            await remove(child(vehicleExitOrdersRef, id));
            return { success: true, message: 'Ordem excluída' };
          }}
          onRegisterVehicleAsset={async (v) => {
            const r = push(vehicleAssetsRef);
            await set(r, { ...v, id: r.key });
            return { success: true, message: 'Ok' };
          }}
          onUpdateVehicleAsset={async (v) => {
            await set(child(vehicleAssetsRef, v.id), v);
            return { success: true, message: 'Atualizado' };
          }}
          onDeleteVehicleAsset={async (id) => {
            await remove(child(vehicleAssetsRef, id));
            return { success: true, message: 'Veículo excluído' };
          }}
          onRegisterDriverAsset={async (d) => {
            const r = push(driverAssetsRef);
            await set(r, { ...d, id: r.key });
            return { success: true, message: 'Ok' };
          }}
          onUpdateDriverAsset={async (d) => {
            await set(child(driverAssetsRef, d.id), d);
            return { success: true, message: 'Atualizado' };
          }}
          onDeleteDriverAsset={async (id) => {
            await remove(child(driverAssetsRef, id));
            return { success: true, message: 'Servidor excluído' };
          }}
          onRegisterVehicleInspection={async (inspection) => {
            const r = push(vehicleInspectionsRef);
            await set(r, { ...inspection, id: r.key });
            return { success: true, message: 'Inspeção registrada' };
          }}
          onUpdateVehicleInspection={async (inspection) => {
            await set(child(vehicleInspectionsRef, inspection.id), inspection);
            return { success: true, message: 'Inspeção atualizada' };
          }}
          onDeleteVehicleInspection={async (id) => {
            await remove(child(vehicleInspectionsRef, id));
            return { success: true, message: 'Inspeção excluída' };
          }}
          onValidateOrder={async (orderId, validatedBy, validationRole) => {
            const timestamp = new Date().toISOString();
            await update(child(vehicleExitOrdersRef, orderId), {
              validatedBy,
              validationRole,
              validationTimestamp: timestamp
            });
            return { success: true, message: 'Ordem validada' };
          }}
          onLogout={handleLogout}
          role={user.role}
        />
      );
    }

    if (['producer', 'supplier', 'pereciveis_supplier', 'estocaveis_supplier', 'supplier_estocavel'].includes(user.role)) {
      const cleanDigits = (s: any) => String(s || '').replace(/\D/g, '');
      const matchCpf = (a: any, b: any) => {
        const da = cleanDigits(a);
        const db = cleanDigits(b);
        if (!da || !db) return false;
        if (da === db) return true;
        if (da.length === 11 && db.length === 14 && db.startsWith(da)) return true;
        if (db.length === 11 && da.length === 14 && da.startsWith(db)) return true;
        const noZeroA = da.replace(/^0+/, '');
        const noZeroB = db.replace(/^0+/, '');
        if (noZeroA && noZeroB && noZeroA === noZeroB) return true;
        return false;
      };

      const ppaisList = ensureArray<any>(perCapitaConfig?.ppaisProducers);
      const pereciveisList = ensureArray<any>(perCapitaConfig?.pereciveisSuppliers);
      const estocaveisList = ensureArray<any>(perCapitaConfig?.estocaveisSuppliers);
      const allPC = [...ppaisList, ...pereciveisList, ...estocaveisList];

      const perCapitaEntry = allPC.find((p: any) => p && matchCpf(p.cpfCnpj || p.cpf, user.cpf));
      const existingSupplier = (suppliers || []).find(s => s && matchCpf(s.cpf, user.cpf));

      const isRegisteredForNextPeriod = !!perCapitaEntry || !!existingSupplier;
      const currentMonth = new Date().getMonth();
      const isMayOrLater = currentMonth >= 4; // 0-indexed, 4 is May

      if (isMayOrLater && !isRegisteredForNextPeriod && user.role === 'supplier') {
        return (
          <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
            <div className="bg-white p-8 rounded-3xl shadow-xl border border-red-100 text-center max-w-md">
              <div className="bg-red-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
              </div>
              <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight mb-2">Contrato Finalizado</h2>
              <p className="text-gray-500 text-sm font-medium">Seu contrato foi finalizado em Abril de 2026. Esta aba foi desativada conforme o novo planejamento.</p>
              <button onClick={handleLogout} className="mt-6 bg-red-600 text-white font-black py-3 px-8 rounded-xl text-[10px] uppercase tracking-widest hover:bg-red-700 transition-all">Sair do Sistema</button>
            </div>
          </div>
        );
      }

      const primaryObj: any = perCapitaEntry || existingSupplier;

      if (primaryObj) {
        const pCpf = (primaryObj as any).cpfCnpj || (primaryObj as any).cpf || user.cpf || '';
        
        // Combine allowed weeks from all sources without stripping weeks > 18
        const sDirectWeeks = ensureArray<number>(existingSupplier?.allowedWeeks);
        const pcDirectWeeks = ensureArray<number>(perCapitaEntry?.allowedWeeks);
        const sScheduleWeeks = existingSupplier?.monthlySchedule ? calculateAllowedWeeksFromSchedule(existingSupplier.monthlySchedule, 2026) : [];
        const pcScheduleWeeks = perCapitaEntry?.monthlySchedule ? calculateAllowedWeeksFromSchedule(perCapitaEntry.monthlySchedule, 2026) : [];

        const finalWeeks = Array.from(new Set([...sDirectWeeks, ...pcDirectWeeks, ...sScheduleWeeks, ...pcScheduleWeeks]))
          .map(Number)
          .filter(w => !isNaN(w) && w > 0)
          .sort((a, b) => a - b);

        const pDeliveriesRaw = ensureArray<any>(perCapitaEntry?.deliveries);
        const extDeliveriesRaw = ensureArray<any>(existingSupplier?.deliveries);

        const safeParseNum = (val: any) => {
            if (typeof val === 'number') return val;
            const str = String(val || '0').replace(',', '.');
            const parsed = parseFloat(str);
            return isNaN(parsed) ? 0 : parsed;
        };

        const contractItems = ensureArray<any>(perCapitaEntry?.contractItems || existingSupplier?.contractItems || primaryObj.contractItems);

        const mappedSupplier: Supplier = {
          ...primaryObj,
          name: primaryObj.name || existingSupplier?.name || perCapitaEntry?.name || 'Produtor / Fornecedor',
          cpf: pCpf,
          initialValue: contractItems.reduce((acc: number, curr: any) => acc + (safeParseNum(curr.totalKg) * safeParseNum(curr.valuePerKg)), 0),
          contractItems: contractItems,
          deliveries: Array.from(new Map<string, any>([...pDeliveriesRaw, ...extDeliveriesRaw].filter(d => d && (d.id || d.date)).map(d => [String(d.id || `${d.date}_${d.time}`), d])).values()),
          allowedWeeks: finalWeeks,
          address: primaryObj.address || existingSupplier?.address || perCapitaEntry?.address || '',
          city: primaryObj.city || existingSupplier?.city || perCapitaEntry?.city || '',
          processNumber: primaryObj.processNumber || existingSupplier?.processNumber || perCapitaEntry?.processNumber || ''
        };

        return (
          <Dashboard 
            supplier={mappedSupplier} 
            type={(user.role === 'producer' || (primaryObj as any).type === 'PRODUTOR') ? 'PRODUTOR' : 'FORNECEDOR'}
            isRegisteredForNextPeriod={isRegisteredForNextPeriod}
            onUpdateInvoiceUrl={handleUpdateInvoiceUrl}
            onLogout={handleLogout} 
            onScheduleDelivery={handleScheduleDelivery}
            onCancelDeliveries={handleCancelDeliveries}
            onSaveInvoice={handleSaveInvoice}
            emailModalData={null}
            onCloseEmailModal={() => {}}
          />
        );
      }
    } else {
      // Role not recognized or not handled above
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-100">
          <div className="text-center">
            <h2 className="text-xl font-bold mb-4">Módulo Indisponível</h2>
            <button onClick={handleLogout} className="bg-zinc-900 text-white px-6 py-2 rounded-lg">Voltar ao Login</button>
          </div>
        </div>
      );
    }

    const currentMonth = new Date().getMonth();
    const isMayOrLater = currentMonth >= 4;

    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
        <div className="bg-white p-8 rounded-3xl shadow-xl border border-zinc-200 text-center max-w-md">
          <div className="bg-zinc-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
          </div>
          <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight mb-2">
            {isMayOrLater ? 'Acesso Encerrado' : 'Usuário não encontrado'}
          </h2>
          <p className="text-gray-500 text-sm font-medium">
            {isMayOrLater 
              ? 'Seu contrato foi finalizado em Abril de 2026 ou você não está na lista de cadastro vigente para o novo período.' 
              : 'Não foi possível localizar seu cadastro ou você não possui permissões para acessar esta área.'}
          </p>
          <button onClick={handleLogout} className="mt-6 bg-zinc-900 text-white font-black py-3 px-8 rounded-xl text-[10px] uppercase tracking-widest hover:bg-black transition-all">Voltar ao Início</button>
        </div>
      </div>
    );
    } catch (e: any) {
      console.error("RenderContent error:", e);
      if (!hasError) {
        setHasError(true);
        setErrorDetails(e?.message || String(e));
      }
      const errorDisplay = (
        <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
          <div className="bg-white p-8 rounded-3xl shadow-xl border border-red-200 text-center max-w-md">
            <div className="bg-red-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
            </div>
            <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight mb-2">Erro Inesperado</h2>
            <p className="text-gray-500 text-sm font-medium mb-4">Não foi possível processar a sua solicitação. Por favor, tente recarregar.</p>
            <button 
              onClick={() => { setHasError(false); window.location.reload(); }} 
              className="bg-zinc-900 text-white font-black py-3 px-8 rounded-xl text-[10px] uppercase tracking-widest hover:bg-black transition-all"
            >
              Recarregar Sistema
            </button>
          </div>
        </div>
      );

      return errorDisplay;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <Toaster position="top-right" richColors />
      {user && (
        <InfobarTicker 
          items={publicInfo.filter(info => !info.isConfidential)} 
          variant="light"
          label="Comunicados:"
        />
      )}
      <div className="flex-1 overflow-auto">
        {(() => {
          try {
            return renderContent();
          } catch (e: any) {
            console.error("Render error caught:", e);
            if (!hasError) {
              setHasError(true);
              setErrorDetails(e?.message || String(e));
            }
            return null;
          }
        })()}
      </div>
    </div>
  );
};

export default App;
