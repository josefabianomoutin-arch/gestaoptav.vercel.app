
import React, { useState, useMemo, useRef } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import type { Supplier, Delivery, WarehouseMovement, PerCapitaConfig, CleaningLog, DirectorPerCapitaLog, StandardMenu, DailyMenus, FinancialRecord, ThirdPartyEntryLog, AcquisitionItem, VehicleExitOrder, VehicleAsset, DriverAsset, UserRole, ServiceOrder, VehicleInspection, MaintenanceSchedule, PublicInfo, EpiLog } from '../types';
import AdminAnalytics from './AdminAnalytics';
import AdminContractItems from './AdminContractItems';
import EditSupplierModal from './EditSupplierModal';
import AdminScheduleView from './AdminScheduleView';
import AdminInvoices from './AdminInvoices';
import AdminPerCapita from './AdminPerCapita';
import AdminCleaningLog from './AdminCleaningLog';
import AdminGraphs from './AdminGraphs';
import AdminStandardMenu from './AdminStandardMenu';
import AdminFinancialManager from './AdminFinancialManager';
import AdminThirdPartyEntry from './AdminThirdPartyEntry';
import AdminVehicleExitOrder from './AdminVehicleExitOrder';
import AdminServiceOrder from './AdminServiceOrder';
import AdminPublicInfo from './AdminPublicInfo';
import ConfirmModal from './ConfirmModal';
import WeekSelector from './WeekSelector';
import WarehouseMovementForm from './WarehouseMovementForm';
import AdminDirectorPerCapita from './AdminDirectorPerCapita';
import AdminEPIControl from './AdminEPIControl';
import AdminTaiuvaEnergyAccounting from './AdminTaiuvaEnergyAccounting';
import { AdminServidorInternoModal } from './AdminServidorInternoModal';
import { PoliciaPenalLogo } from './PoliciaPenalLogo';
import { Server, Download, HardDrive } from 'lucide-react';
import { EnergyAccountingRecord } from '../types';

type AdminTab = 'info' | 'register' | 'contracts' | 'finance' | 'analytics' | 'graphs' | 'schedule' | 'invoices' | 'perCapita' | 'cleaning' | 'vehicleExitOrder' | 'thirdPartyEntry' | 'directorPerCapita' | 'menu' | 'almoxarifado' | 'serviceOrder' | 'publicInfo' | 'epiControl' | 'energyAccounting';

interface AdminDashboardProps {
  user: { name: string; cpf: string; role: UserRole };
  energyAccountingRecords?: Record<string, EnergyAccountingRecord>;
  onSaveEnergyAccountingRecord?: (record: EnergyAccountingRecord) => Promise<{ success: boolean; message: string }>;
  onDeleteEnergyAccountingRecord?: (id: string) => Promise<{ success: boolean; message: string }>;
  onRegister: (name: string, cpf: string, allowedWeeks: number[]) => Promise<void>;
  onPersistSuppliers: (suppliersToPersist: Supplier[]) => void;
  onUpdateSupplier: (oldCpf: string, newName: string, newCpf: string, newAllowedWeeks: number[]) => Promise<string | null>;
  onSyncPPAISToAgenda: () => Promise<void>;
  onLogout: () => void;
  suppliers: Supplier[];
  warehouseLog: WarehouseMovement[];
  cleaningLogs: CleaningLog[];
  directorWithdrawals: DirectorPerCapitaLog[];
  directorPerCapita?: any;
  onResetData: () => void;
  onRestoreData: (backupSuppliers: Supplier[]) => Promise<boolean>;
  onRestoreFullBackup: (fullData: any) => Promise<boolean>;
  registrationStatus: { success: boolean; message: string } | null;
  onClearRegistrationStatus: () => void;
  onReopenInvoice: (supplierCpf: string, invoiceNumber: string) => Promise<void>;
  onDeleteInvoice: (supplierCpf: string, invoiceNumber: string) => Promise<void>;
  onUpdateInvoiceItems: (supplierCpf: string, invoiceNumber: string, items: { name: string; kg: number; value: number; lotNumber?: string; expirationDate?: string }[], barcode?: string, newInvoiceNumber?: string, newDate?: string, receiptTermNumber?: string, invoiceDate?: string, pd?: string, supplierNameHint?: string) => Promise<{ success: boolean; message?: string }>;
  onUpdateInvoiceUrl: (supplierCpf: string, invoiceNumber: string, invoiceUrl: string) => Promise<{ success: boolean; message?: string }>;
  onMarkInvoiceAsOpened: (supplierCpf: string, invoiceNumber: string) => Promise<{ success: boolean }>;
  onManualInvoiceEntry: (supplierCpf: string, date: string, invoiceNumber: string, items: { name: string; kg: number; value: number; lotNumber?: string; expirationDate?: string }[], barcode?: string, receiptTermNumber?: string, invoiceDate?: string, pd?: string, type?: 'entrada' | 'saída') => Promise<{ success: boolean; message?: string }>;
  perCapitaConfig: PerCapitaConfig;
  onUpdatePerCapitaConfig: (config: Partial<PerCapitaConfig>) => Promise<{ success: boolean; message?: string }>;
  onDeleteWarehouseEntry: (logEntry: WarehouseMovement) => Promise<{ success: boolean; message: string }>;
  onDeleteDelivery: (supplierCpf: string, deliveryId: string) => Promise<{ success: boolean }>;
  onUpdateDelivery?: (supplierCpf: string, deliveryId: string, updates: Partial<Delivery>) => Promise<{ success: boolean; message?: string }>;
  onUpdateWarehouseEntry: (updatedEntry: WarehouseMovement) => Promise<{ success: boolean; message: string }>;
  onRegisterEntry: (payload: any) => Promise<{ success: boolean; message: string; invoiceUrl?: string }>;
  onRegisterWithdrawal: (payload: any) => Promise<{ success: boolean; message: string }>;
  onUpdateContractForItem: (itemName: string, assignments: { supplierCpf: string, totalKg: number, valuePerKg: number, unit?: string, category?: string, comprasCode?: string, becCode?: string, commitmentNumber?: string, commitmentValue?: number }[]) => Promise<{ success: boolean, message: string }>;
  onUpdateAcquisitionItem: (item: AcquisitionItem) => Promise<{ success: boolean; message: string }>;
  onDeleteAcquisitionItem: (id: string) => Promise<{ success: boolean; message: string }>;
  acquisitionItems: AcquisitionItem[];
  onRegisterCleaningLog: (log: Omit<CleaningLog, 'id'>) => Promise<{ success: boolean; message: string }>;
  onDeleteCleaningLog: (id: string) => Promise<void | { success: boolean; message: string }>;
  epiLogs: EpiLog[];
  onRegisterEpi: (log: Omit<EpiLog, 'id'>) => Promise<{ success: boolean; message: string }>;
  onDeleteEpi: (id: string) => Promise<any>;
  onRegisterDirectorWithdrawal: (log: Omit<DirectorPerCapitaLog, 'id'>) => Promise<{ success: boolean; message: string }>;
  onDeleteDirectorWithdrawal: (id: string) => Promise<void | { success: boolean; message: string }>;
  standardMenu: StandardMenu;
  dailyMenus: DailyMenus;
  onUpdateStandardMenu: (menu: StandardMenu) => Promise<void | { success: boolean; message: string }>;
  onUpdateDailyMenu: (menus: DailyMenus) => Promise<void | { success: boolean; message: string }>;
  onCancelDeliveries: (supplierCpf: string, deliveryIds: string[]) => void;
  financialRecords: FinancialRecord[];
  onSaveFinancialRecord: (record: Omit<FinancialRecord, 'id'> & { id?: string }) => Promise<{ success: boolean; message?: string }>;
  onDeleteFinancialRecord: (id: string) => Promise<void | { success: boolean; message: string }>;
  thirdPartyEntries: ThirdPartyEntryLog[];
  onRegisterThirdPartyEntry: (log: Omit<ThirdPartyEntryLog, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateThirdPartyEntry: (log: ThirdPartyEntryLog) => Promise<{ success: boolean; message: string }>;
  onDeleteThirdPartyEntry: (id: string) => Promise<void | { success: boolean; message: string }>;
  vehicleExitOrders: VehicleExitOrder[];
  onRegisterVehicleExitOrder: (order: Omit<VehicleExitOrder, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateVehicleExitOrder: (order: VehicleExitOrder) => Promise<{ success: boolean; message: string }>;
  onDeleteVehicleExitOrder?: (id: string) => Promise<void | { success: boolean; message: string }>;
  vehicleAssets: VehicleAsset[];
  onRegisterVehicleAsset: (asset: Omit<VehicleAsset, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateVehicleAsset: (asset: VehicleAsset) => Promise<{ success: boolean; message: string }>;
  onDeleteVehicleAsset: (id: string) => Promise<void | { success: boolean; message: string }>;
  driverAssets: DriverAsset[];
  onRegisterDriverAsset: (asset: Omit<DriverAsset, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateDriverAsset: (asset: DriverAsset) => Promise<{ success: boolean; message: string }>;
  onDeleteDriverAsset: (id: string) => Promise<void | { success: boolean; message: string }>;
  vehicleInspections: VehicleInspection[];
  onRegisterVehicleInspection: (inspection: Omit<VehicleInspection, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateVehicleInspection: (inspection: VehicleInspection) => Promise<{ success: boolean; message: string }>;
  onDeleteVehicleInspection: (id: string) => Promise<void | { success: boolean; message: string }>;
  serviceOrders: ServiceOrder[];
  maintenanceSchedules: MaintenanceSchedule[];
  onUpdateServiceOrder: (order: ServiceOrder) => Promise<{ success: boolean; message: string }>;
  onDeleteServiceOrder: (id: string) => Promise<{ success: boolean; message: string }>;
  onRegisterMaintenanceSchedule: (schedule: Omit<MaintenanceSchedule, 'id'>) => Promise<{ success: boolean; message: string }>;
  onUpdateMaintenanceSchedule: (idOrSchedule: string | MaintenanceSchedule, updates?: Partial<MaintenanceSchedule>) => Promise<{ success: boolean; message: string }>;
  onDeleteMaintenanceSchedule: (id: string) => Promise<{ success: boolean; message: string }>;
  onRestoreInfrastructureData?: () => Promise<{ success: boolean; message: string }>;
  validationRoles: any[];
  onUpdateSupplierObservations?: (cpf: string, observations: string) => Promise<{ success: boolean; message?: string }>;
  systemPasswords: Record<string, string>;
  onUpdateSystemPassword: (key: string, pass: string) => Promise<void>;
  publicInfo: PublicInfo[];
  onSavePublicInfo: (info: Omit<PublicInfo, 'id'> & { id?: string }) => Promise<void>;
  onDeletePublicInfo: (id: string) => Promise<void>;
  onSaveInvoice?: (supplierCpf: string, deliveryIds: string[], invoiceNumber: string, invoiceUrl: string, updatedDeliveries: Delivery[], invoiceDate?: string) => Promise<any>;
}

const formatCurrency = (value: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

const AdminDashboard: React.FC<AdminDashboardProps> = (props) => {
  console.log("AdminDashboard mounted with props:", props);
  const { 
    suppliers = [], 
    onLogout, 
    onResetData, 
    onRestoreFullBackup, 
    perCapitaConfig = {}, 
    warehouseLog = [], 
    financialRecords = [], 
    cleaningLogs = [], 
    thirdPartyEntries = [], 
    vehicleExitOrders = [],
    vehicleAssets = [],
    driverAssets = [],
    directorWithdrawals = [], 
    standardMenu, 
    dailyMenus, 
    acquisitionItems = [],
    onUpdateContractForItem,
    onDeleteDriverAsset,
    vehicleInspections = [],
    onRegisterVehicleInspection,
    onUpdateVehicleInspection,
    onDeleteVehicleInspection,
    serviceOrders = [],
    maintenanceSchedules = [],
    onUpdateServiceOrder,
    onDeleteServiceOrder,
    onRegisterMaintenanceSchedule,
    onUpdateMaintenanceSchedule,
    onDeleteMaintenanceSchedule,
    validationRoles = [],
    systemPasswords = {},
    onUpdateSystemPassword,
    onSaveFinancialRecord,
    onDeleteFinancialRecord,
    onRegisterThirdPartyEntry,
    onUpdateThirdPartyEntry,
    onDeleteThirdPartyEntry,
    onRegisterVehicleExitOrder,
    onUpdateVehicleExitOrder,
    onDeleteVehicleExitOrder,
    onRegisterVehicleAsset,
    onUpdateVehicleAsset,
    onDeleteVehicleAsset,
    onRegisterDriverAsset,
    onUpdateDriverAsset,
    onCancelDeliveries,
    onManualInvoiceEntry,
    onUpdatePerCapitaConfig,
    onMarkInvoiceAsOpened,
    onUpdateInvoiceUrl,
    onUpdateInvoiceItems,
    onDeleteInvoice,
    onReopenInvoice,
    onSaveInvoice,
    epiLogs = [],
    onRegisterEpi,
    onDeleteEpi
  } = props;
  const [activeTab, setActiveTab] = useState<AdminTab>('directorPerCapita');
  const [supplierSubTab, setSupplierSubTab] = useState<'list' | 'new'>('list'); 
  const [supplierSearch, setSupplierSearch] = useState('');
  const [regName, setRegName] = useState('');
  const [regCpf, setRegCpf] = useState('');
  const [regWeeks, setRegWeeks] = useState<number[]>([]);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);
  const [editingPasswordKey, setEditingPasswordKey] = useState<string | null>(null);
  const [newPasswordValue, setNewPasswordValue] = useState('');

  const systemAccesses = [
      { key: 'ALMOXARIFADO', name: 'Almoxarifado', default: 'almoxarifado123' },
      { key: 'ITESP', name: 'ITESP', default: 'taiuvaitesp2026' },
      { key: 'FINANCEIRO', name: 'Financeiro', default: 'financeiro123' },
      { key: 'CARDAPIO', name: 'Cardápio', default: 'cardapio123' },
      { key: 'SEGURANÇA EXTERNA', name: 'Segurança Externa', default: 'externa2026' },
      { key: 'INFRAESTRUTURA', name: 'Infraestrutura', default: 'infra2026' },
      { key: 'ORDEM DE SAIDA', name: 'Ordem de Saída', default: 'saida2026' },
      { key: 'SEÇÃO DE INFRAESTRUTURA E LOGÍSTICA', name: 'Seção de Infraestrutura e Logística', default: '431385464' },
      { key: 'WALTER RODRIGUES JUNIOR', name: 'Diretor Walter Rodrigues Junior', default: '22121664866' },
      { key: 'WILLIAN OLIVEIRA DOS SANTOS', name: 'Diretor Willian Oliveira dos santos', default: '22743505826' },
  ];
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showServerModal, setShowServerModal] = useState(false);
  const backupInputRef = useRef<HTMLInputElement>(null);
  
  const [confirmConfig, setConfirmConfig] = useState<{
      isOpen: boolean;
      title: string;
      message: string;
      onConfirm: () => void;
      variant?: 'danger' | 'warning' | 'info';
  }>({
      isOpen: false,
      title: '',
      message: '',
      onConfirm: () => {},
  });

  const visibleTabs = useMemo(() => {
    const tabs: { id: AdminTab; name: string; icon: React.ReactElement }[] = [
      { id: 'register', name: 'Fornecedores', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M8 9a3 3 0 100-6 3 3 0 000 6zM8 11a6 6 0 016 6H2a6 6 0 016-6zM16 11a1 1 0 10-2 0v1h-1a1 1 0 100 2h1v1a1 1 0 102 0v-1h1a1 1 0 100-2h-1v-1z" /></svg> },
      { id: 'directorPerCapita', name: 'Retirada Diretores', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" /></svg> },
      { id: 'perCapita', name: 'Per Capita', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" /></svg> },
      { id: 'contracts', name: 'Gestão/Item', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 000-2H9z" /><path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clipRule="evenodd" /></svg> },
      { id: 'finance', name: 'Financeiro', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" /><path d="M11 3.5v3a1 1 0 001 1h3m-6 4H7v2h3v-2zm0 3H7v2h3v-2z" /></svg> },
      { id: 'schedule', name: 'Agenda', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a1 1 0 00-1-1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" /></svg> },
      { id: 'invoices', name: 'Notas Fiscais', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a2 2 0 00-2 2v8a2 2 0 002 2h6a2 2 0 002-2V6.414A2 2 0 0016.414 5L14 2.586A2 2 0 0012.586 2H9z" /><path d="M3 8a2 2 0 012-2v10h8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z" /></svg> },
      { id: 'cleaning', name: 'Limpeza', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm0 10a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zM12 2a1 1 0 01.967.744L14.146 7.2 17.5 9.134a1 1 0 010 1.732l-3.354 1.935-1.18 4.455a1 1 0 01-1.933 0L9.854 12.8 6.5 10.866a1 1 0 010-1.732l3.354-1.935 1.18-4.455A1 1 0 0112 2z" clipRule="evenodd" /></svg> },
      { id: 'serviceOrder', name: 'Infraestrutura', icon: <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg> },
      { id: 'energyAccounting', name: 'Energia Taiúva', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg> },
      { id: 'vehicleExitOrder', name: 'Ordem Saída', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" /><path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1V5a1 1 0 00-1-1H3zM14 7a1 1 0 00-1 1v4.5h2V8a1 1 0 00-1-1z" /><path d="M16 13l3.35 2.235a.75.75 0 01.15 1.065l-.5.75a.75.75 0 01-1.065.15L16 15.5V13z" /></svg> },
      { id: 'thirdPartyEntry', name: 'Terceiros', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" /></svg> },
      { id: 'menu', name: 'Cardápio', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" /><path d="M11 3.5v3a1 1 0 001 1h3m-6 4H7v2h3v-2zm0 3H7v2h3v-2z" /></svg> },
      { id: 'publicInfo', name: 'Portal Público', icon: <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg> },
      { id: 'analytics', name: 'Auditoria Analítica', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" /></svg> },
      { id: 'graphs', name: 'Gráficos', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z" /><path d="M12 2.252A8.001 8.001 0 0117.748 8H12V2.252z" /></svg> },
      { id: 'info', name: 'Sistema', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M2 5a2 2 0 012-2h12a2 2 0 012 2v2a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm14 1a1 1 0 11-2 0 1 1 0 012 0zM2 13a2 2 0 012-2h12a2 2 0 012 2v2a2 2 0 01-2 2H4a2 2 0 01-2-2v-2zm14 1a1 1 0 11-2 0 1 1 0 012 0z" clipRule="evenodd" /></svg> },
      { id: 'almoxarifado', name: 'Almoxarifado', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M5 8a1 1 0 011-1h1V6a1 1 0 012 0v1h2V6a1 1 0 112 0v1h1a1 1 0 110 2H6a1 1 0 01-1-1zm1 4a1 1 0 100 2h8a1 1 0 100-2H6z" /></svg> },
      { id: 'epiControl', name: 'Controle de EPIs', icon: <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M2.166 4.9c0-.496.225-.96.613-1.272C4.16 2.501 6.543 2 10 2s5.84 1.5 7.22 2.628c.389.313.614.776.614 1.272v4.205c0 5.013-3.693 7.82-7.397 8.823a1.498 1.498 0 01-.874 0C5.859 18.062 2.166 15.255 2.166 10.24V4.9z" clipRule="evenodd" /></svg> },
    ];
    return tabs;
  }, []);

  const filteredSuppliers = useMemo(() => {
    return suppliers.filter(s => (s.name || '').toLowerCase().includes(supplierSearch.toLowerCase()));
  }, [suppliers, supplierSearch]);

  const handleExportFullBackup = () => {
    const fullBackup = {
      suppliers: suppliers.reduce((acc, s) => ({ ...acc, [s.cpf]: s }), {}),
      warehouseLog: warehouseLog.reduce((acc, l) => ({ ...acc, [l.id]: l }), {}),
      perCapitaConfig,
      cleaningLogs: cleaningLogs.reduce((acc, l) => ({ ...acc, [l.id]: l }), {}),
      thirdPartyEntries: thirdPartyEntries.reduce((acc, l) => ({ ...acc, [l.id]: l }), {}),
      directorWithdrawals: directorWithdrawals.reduce((acc, l) => ({ ...acc, [l.id]: l }), {}),
      standardMenu,
      dailyMenus,
      financialRecords: financialRecords.reduce((acc, r) => ({ ...acc, [r.id]: r }), {}),
      systemPasswords: systemPasswords,
      validationRoles: validationRoles.reduce((acc: any, r: any) => ({ ...acc, [r.id]: r }), {}),
      vehicleExitOrders: vehicleExitOrders.reduce((acc: any, r: any) => ({ ...acc, [r.id]: r }), {}),
      vehicleAssets: vehicleAssets.reduce((acc: any, r: any) => ({ ...acc, [r.id]: r }), {}),
      driverAssets: driverAssets.reduce((acc: any, r: any) => ({ ...acc, [r.id]: r }), {}),
      acquisitionItems: acquisitionItems.reduce((acc: any, r: any) => ({ ...acc, [r.id]: r }), {})
    };
    const blob = new Blob([JSON.stringify(fullBackup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `BACKUP_FINANCAS_COMPLETO_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  const renderContent = () => {
    console.log("AdminDashboard renderContent - activeTab:", activeTab);
    console.log("AdminDashboard suppliers.length:", props.suppliers?.length);
    console.log("AdminDashboard filteredSuppliers.length:", filteredSuppliers?.length);
    
    switch (activeTab) {
      case 'register':
        return (
          <div className="space-y-6 max-w-6xl mx-auto animate-fade-in p-2 md:p-0 pb-16">
            <div className="md:hidden flex bg-white p-1 rounded-2xl shadow-md mb-4 border border-indigo-100">
                <button onClick={() => setSupplierSubTab('list')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${supplierSubTab === 'list' ? 'bg-indigo-600 text-white shadow-lg' : 'text-indigo-400'}`}>Lista Ativos</button>
                <button onClick={() => setSupplierSubTab('new')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${supplierSubTab === 'new' ? 'bg-indigo-600 text-white shadow-lg' : 'text-indigo-400'}`}>Novo Registro</button>
            </div>

            {(supplierSubTab === 'new' || !window.matchMedia("(max-width: 768px)").matches) && (
                <div className="bg-white p-6 md:p-8 rounded-[2rem] shadow-xl border-t-8 border-indigo-900">
                    <h2 className="text-xl md:text-2xl font-black text-gray-800 mb-6 uppercase tracking-tight italic">Novo Fornecedor</h2>
                    <form className="grid grid-cols-1 md:grid-cols-2 gap-4" onSubmit={async (e) => { e.preventDefault(); await props.onRegister(regName, regCpf, regWeeks); setRegName(''); setRegCpf(''); setRegWeeks([]); setSupplierSubTab('list'); }}>
                        <div className="space-y-1">
                        <label className="text-[10px] font-black text-gray-400 uppercase ml-1">Nome Completo</label>
                        <input type="text" placeholder="JOÃO DA SILVA" value={regName} onChange={e => setRegName(e.target.value.toUpperCase())} className="w-full h-14 px-4 border-2 border-gray-100 rounded-2xl focus:ring-2 focus:ring-indigo-400 outline-none font-bold text-sm" required />
                        </div>
                        <div className="space-y-1">
                        <label className="text-[10px] font-black text-gray-400 uppercase ml-1">CPF ou CNPJ</label>
                        <input type="text" placeholder="Apenas números" value={regCpf} onChange={e => setRegCpf(e.target.value.replace(/\D/g, ''))} className="w-full h-14 px-4 border-2 border-gray-100 rounded-2xl font-mono focus:ring-2 focus:ring-indigo-400 outline-none text-sm" required />
                        </div>
                        <div className="md:col-span-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase mb-3 block ml-1">Semanas de Entrega</label>
                        <div className="bg-gray-50 rounded-2xl p-2 md:p-4 border-2 border-gray-100">
                            <WeekSelector selectedWeeks={regWeeks} onWeekToggle={(w) => setRegWeeks(prev => prev.includes(w) ? prev.filter(x => x !== w) : [...prev, w])} />
                        </div>
                        </div>
                        <button type="submit" className="md:col-span-2 bg-indigo-950 hover:bg-black text-white font-black h-16 rounded-2xl shadow-lg active:scale-95 uppercase tracking-widest text-xs md:text-sm transition-all mt-2">Registrar Fornecedor</button>
                    </form>
                </div>
            )}
            
            {(supplierSubTab === 'list' || !window.matchMedia("(max-width: 768px)").matches) && (
                <div className="bg-white p-4 md:p-8 rounded-[2rem] shadow-xl">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 border-b pb-6">
                        <h2 className="text-xl md:text-2xl font-black text-gray-800 uppercase tracking-tight italic">Habilitados <span className="text-indigo-600">({filteredSuppliers.length})</span></h2>
                        <div className="relative w-full md:w-80">
                            <input type="text" placeholder="Filtrar produtor..." value={supplierSearch} onChange={e => setSupplierSearch(e.target.value)} className="w-full border-2 border-gray-50 h-14 px-4 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-indigo-400 font-bold bg-gray-50" />
                            <svg className="h-5 w-5 absolute right-4 top-1/2 -translate-y-1/2 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                        </div>
                    </div>

                    <div className="block md:hidden space-y-4">
                        {filteredSuppliers.map(s => (
                        <div key={s.cpf} className="bg-slate-50 p-5 rounded-3xl border-2 border-white shadow-sm flex flex-col gap-3">
                            <div className="flex justify-between items-start">
                                <div className="flex-1 pr-4">
                                    <p className="font-black text-gray-800 uppercase text-sm leading-tight break-words">{s.name}</p>
                                    <p className="text-[10px] font-mono text-gray-400 mt-1">ID: {s.cpf}</p>
                                </div>
                                <span className="bg-green-100 text-green-700 text-[10px] font-black px-2 py-1 rounded-lg whitespace-nowrap">{formatCurrency(s.initialValue)}</span>
                            </div>
                            <div className="flex flex-wrap gap-1 border-t border-gray-200 pt-3">
                                {s.allowedWeeks?.length > 0 ? s.allowedWeeks.sort((a,b)=>a-b).map(w => (
                                    <span key={w} className="bg-indigo-600 text-white text-[9px] font-black px-2 py-0.5 rounded-md">S{w}</span>
                                )) : <span className="text-[9px] font-black text-green-600 uppercase">Calendário Livre</span>}
                            </div>
                            <button onClick={() => setEditingSupplier(s)} className="w-full mt-2 bg-white border-2 border-indigo-50 text-indigo-600 font-black h-12 rounded-xl text-[10px] uppercase shadow-sm active:bg-indigo-50">Editar Cadastro</button>
                        </div>
                        ))}
                    </div>

                    <div className="hidden md:block overflow-x-auto">
                        <table className="w-full text-sm">
                        <thead>
                            <tr className="text-gray-400 uppercase text-[10px] font-black tracking-widest border-b">
                            <th className="p-4 text-left">Fornecedor</th>
                            <th className="p-4 text-center">Semanas</th>
                            <th className="p-4 text-right">Contratado</th>
                            <th className="p-4 text-center">Ações</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                            {filteredSuppliers.map(s => (
                            <tr key={s.cpf} className="hover:bg-gray-50 transition-colors group">
                                <td className="p-4">
                                    <p className="font-black text-gray-800 uppercase text-xs">{s.name}</p>
                                    <p className="text-[10px] font-mono text-gray-400">{s.cpf}</p>
                                </td>
                                <td className="p-4 text-center">
                                    <div className="flex flex-wrap justify-center gap-1">
                                        {s.allowedWeeks?.length > 0 ? s.allowedWeeks.sort((a,b)=>a-b).slice(0,6).map(w => <span key={w} className="bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded text-[9px] font-black">S{w}</span>) : <span className="text-[10px] text-green-600 font-black uppercase">Livre</span>}
                                    </div>
                                </td>
                                <td className="p-4 text-right font-black text-green-700">{formatCurrency(s.initialValue)}</td>
                                <td className="p-4 text-center">
                                <button onClick={() => setEditingSupplier(s)} className="bg-indigo-100 text-indigo-600 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded-xl font-black text-[10px] uppercase transition-all shadow-sm">Editar</button>
                                </td>
                            </tr>
                            ))}
                        </tbody>
                        </table>
                    </div>
                </div>
            )}
          </div>
        );
      case 'contracts': return <AdminContractItems suppliers={suppliers} warehouseLog={warehouseLog} onUpdateContractForItem={onUpdateContractForItem} acquisitionItems={acquisitionItems} />;
      case 'finance': return <AdminFinancialManager records={financialRecords} onSave={onSaveFinancialRecord} onDelete={onDeleteFinancialRecord} />;
      case 'invoices': 
        return (
          <div className="space-y-8 max-w-7xl mx-auto animate-fade-in">
            <WarehouseMovementForm 
              suppliers={suppliers} 
              warehouseLog={warehouseLog} 
              onRegisterEntry={props.onRegisterEntry}
              onRegisterWithdrawal={props.onRegisterWithdrawal}
              initialMode="entrada"
              perCapitaConfig={perCapitaConfig}
              acquisitionItems={acquisitionItems}
            />
            <div className="border-t border-gray-100 pt-8">
              <AdminInvoices 
                suppliers={suppliers} 
                warehouseLog={warehouseLog} 
                onReopenInvoice={onReopenInvoice} 
                onDeleteInvoice={onDeleteInvoice} 
                onUpdateInvoiceItems={onUpdateInvoiceItems} 
                onUpdateInvoiceUrl={onUpdateInvoiceUrl} 
                onManualInvoiceEntry={onManualInvoiceEntry} 
                onMarkInvoiceAsOpened={onMarkInvoiceAsOpened} 
                perCapitaConfig={perCapitaConfig}
                mode="warehouse_entry"
                acquisitionItems={acquisitionItems}
              />
            </div>
          </div>
        );
      case 'schedule': return <AdminScheduleView suppliers={suppliers} thirdPartyEntries={thirdPartyEntries} onCancelDeliveries={onCancelDeliveries} onDeleteThirdPartyEntry={onDeleteThirdPartyEntry} perCapitaConfig={perCapitaConfig} onDeleteDelivery={props.onDeleteDelivery} onUpdateDelivery={props.onUpdateDelivery} onSaveInvoice={onSaveInvoice} onRegisterThirdPartyEntry={onRegisterThirdPartyEntry} onUpdateThirdPartyEntry={onUpdateThirdPartyEntry} />;
      case 'directorPerCapita': return <AdminDirectorPerCapita suppliers={suppliers} logs={props.directorWithdrawals} directorPerCapita={props.directorPerCapita} warehouseLog={warehouseLog} onRegister={props.onRegisterDirectorWithdrawal} onDelete={async (id) => { await props.onDeleteDirectorWithdrawal(id); }} />;
      case 'perCapita': return <AdminPerCapita suppliers={suppliers} warehouseLog={warehouseLog} perCapitaConfig={perCapitaConfig} onUpdatePerCapitaConfig={onUpdatePerCapitaConfig} onUpdateContractForItem={onUpdateContractForItem} onUpdateAcquisitionItem={props.onUpdateAcquisitionItem} onDeleteAcquisitionItem={props.onDeleteAcquisitionItem} acquisitionItems={acquisitionItems} onUpdateSupplierObservations={props.onUpdateSupplierObservations} onSyncPPAISToAgenda={props.onSyncPPAISToAgenda} onSaveInvoice={onSaveInvoice} onDeleteDelivery={props.onDeleteDelivery} />;
      case 'cleaning': return <AdminCleaningLog logs={cleaningLogs} financialRecords={financialRecords} onRegister={props.onRegisterCleaningLog} onDelete={props.onDeleteCleaningLog} />;
      case 'thirdPartyEntry': return <AdminThirdPartyEntry logs={thirdPartyEntries} onRegister={onRegisterThirdPartyEntry} onUpdate={onUpdateThirdPartyEntry} onDelete={onDeleteThirdPartyEntry} />;
      case 'vehicleExitOrder': return <AdminVehicleExitOrder 
          orders={vehicleExitOrders} 
          onRegister={onRegisterVehicleExitOrder} 
          onUpdate={onUpdateVehicleExitOrder} 
          onDelete={onDeleteVehicleExitOrder}
          vehicleAssets={vehicleAssets}
          onRegisterVehicleAsset={onRegisterVehicleAsset}
          onUpdateVehicleAsset={onUpdateVehicleAsset}
          onDeleteVehicleAsset={onDeleteVehicleAsset}
          driverAssets={driverAssets}
          onRegisterDriverAsset={onRegisterDriverAsset}
          onUpdateDriverAsset={onUpdateDriverAsset}
          onDeleteDriverAsset={onDeleteDriverAsset}
          validationRoles={validationRoles}
          inspections={vehicleInspections}
          onRegisterInspection={onRegisterVehicleInspection}
          onUpdateInspection={onUpdateVehicleInspection}
          onDeleteInspection={onDeleteVehicleInspection}
          userRole={props.user.role}
          allowDelete={true}
      />;
      case 'serviceOrder': return <AdminServiceOrder
          orders={serviceOrders || []}
          onUpdate={onUpdateServiceOrder}
          onDelete={onDeleteServiceOrder}
          maintenanceSchedules={maintenanceSchedules || []}
          onRegisterMaintenanceSchedule={onRegisterMaintenanceSchedule}
          onUpdateMaintenanceSchedule={onUpdateMaintenanceSchedule}
          onDeleteMaintenanceSchedule={onDeleteMaintenanceSchedule}
          onRestoreInfrastructureData={props.onRestoreInfrastructureData}
          systemPasswords={systemPasswords}
      />;
      case 'energyAccounting': return <AdminTaiuvaEnergyAccounting
          records={props.energyAccountingRecords}
          onSaveRecord={props.onSaveEnergyAccountingRecord}
          onDeleteRecord={props.onDeleteEnergyAccountingRecord}
          userRole={props.user.role}
          onNavigateToDeductionMap={() => setActiveTab('invoices')}
          onNavigateToEstoque={() => setActiveTab('invoices')}
      />;
      case 'analytics': return <AdminAnalytics suppliers={suppliers} warehouseLog={warehouseLog} perCapitaConfig={perCapitaConfig} />;
      case 'graphs': return <AdminGraphs 
          suppliers={suppliers} 
          warehouseLog={warehouseLog}
          cleaningLogs={cleaningLogs}
          financialRecords={financialRecords}
          vehicleExitOrders={vehicleExitOrders}
          thirdPartyEntries={thirdPartyEntries}
          directorWithdrawals={directorWithdrawals}
          perCapitaConfig={perCapitaConfig}
          acquisitionItems={acquisitionItems}
      />;
      case 'menu': return <AdminStandardMenu suppliers={suppliers} template={props.standardMenu} dailyMenus={props.dailyMenus} onUpdateDailyMenus={props.onUpdateDailyMenu} inmateCount={perCapitaConfig.inmateCount || 0} />;
      case 'publicInfo': return <AdminPublicInfo infoList={props.publicInfo} onSave={props.onSavePublicInfo} onDelete={props.onDeletePublicInfo} />;
      case 'almoxarifado': return <WarehouseMovementForm suppliers={suppliers} warehouseLog={warehouseLog} onRegisterEntry={props.onRegisterEntry} onRegisterWithdrawal={props.onRegisterWithdrawal} perCapitaConfig={perCapitaConfig} />;
      case 'epiControl': return <AdminEPIControl logs={epiLogs} acquisitionItems={acquisitionItems} onRegister={onRegisterEpi} onDelete={onDeleteEpi} />;
      case 'info': 
        return (
            <div className="max-w-4xl mx-auto space-y-6 animate-fade-in p-4 md:p-0 pb-16">
                <div className="bg-white p-6 md:p-8 rounded-[2rem] shadow-xl border-t-8 border-indigo-900">
                    <h2 className="text-2xl md:text-3xl font-black text-indigo-950 uppercase tracking-tighter mb-6">Configurações de Sistema</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-indigo-50 p-6 rounded-3xl border-2 border-indigo-100 flex flex-col justify-between">
                            <div>
                                <h3 className="text-lg font-black text-indigo-800 uppercase mb-2">Exportar Backup</h3>
                                <p className="text-xs text-indigo-600/70 mb-6 font-medium leading-relaxed">Baixa todos os dados em um único arquivo .json.</p>
                            </div>
                            <button onClick={handleExportFullBackup} className="w-full bg-indigo-700 hover:bg-indigo-800 text-white font-black h-14 rounded-2xl shadow-lg transition-all active:scale-95 uppercase text-[10px] tracking-widest flex items-center justify-center gap-2">Gerar Backup</button>
                        </div>
                        <div className="bg-blue-50 p-6 rounded-3xl border-2 border-blue-100 flex flex-col justify-between">
                            <div>
                                <h3 className="text-lg font-black text-blue-800 uppercase mb-2">Importar Backup</h3>
                                <p className="text-xs text-blue-600/70 mb-6 font-medium leading-relaxed">Substituirá permanentemente todos os registros atuais.</p>
                            </div>
                            <button onClick={() => backupInputRef.current?.click()} disabled={isRestoring} className="w-full bg-blue-700 hover:bg-blue-800 text-white font-black h-14 rounded-2xl shadow-lg transition-all uppercase text-[10px] tracking-widest disabled:bg-gray-400">Restauração Total</button>
                            <input type="file" ref={backupInputRef} onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                const reader = new FileReader();
                                reader.onload = async (ev) => {
                                    setConfirmConfig({
                                        isOpen: true,
                                        title: 'Restaurar Sistema',
                                        message: 'Substituir todos os dados do sistema agora? Esta ação não pode ser desfeita.',
                                        onConfirm: async () => {
                                            setIsRestoring(true);
                                            const success = await onRestoreFullBackup(JSON.parse(ev.target?.result as string));
                                            if (success) toast.success('Sistema Restaurado!');
                                            setIsRestoring(false);
                                            setConfirmConfig(prev => ({ ...prev, isOpen: false }));
                                        },
                                        variant: 'danger'
                                    });
                                };
                                reader.readAsText(file);
                            }} accept=".json" className="hidden" />
                        </div>
                        <div className="bg-rose-50 p-6 rounded-3xl border-2 border-rose-100 flex flex-col justify-between">
                            <div>
                                <h3 className="text-lg font-black text-rose-800 uppercase mb-2">Resetar Sistema</h3>
                                <p className="text-xs text-rose-600/70 mb-6 font-medium leading-relaxed">Apaga permanentemente todos os dados do servidor.</p>
                            </div>
                            <button 
                                onClick={() => {
                                    setConfirmConfig({
                                        isOpen: true,
                                        title: 'RESET TOTAL',
                                        message: 'VOCÊ TEM CERTEZA? Todos os dados serão apagados permanentemente e o sistema será reiniciado.',
                                        onConfirm: async () => {
                                            await onResetData();
                                            setConfirmConfig(prev => ({ ...prev, isOpen: false }));
                                        },
                                        variant: 'danger'
                                    });
                                }} 
                                className="w-full bg-rose-600 hover:bg-rose-700 text-white font-black h-14 rounded-2xl shadow-lg transition-all uppercase text-[10px] tracking-widest"
                            >
                                Limpeza Total
                            </button>
                        </div>
                    </div>

                    <div className="mt-12">
                        <h3 className="text-xl font-black text-indigo-950 uppercase tracking-tighter mb-6 flex items-center gap-2">
                            <svg className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
                            Status do Banco de Dados
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                            {[
                                { label: 'Fornecedores', count: suppliers.length, color: 'indigo' },
                                { label: 'Movimentações', count: warehouseLog.length, color: 'blue' },
                                { label: 'Registros Financeiros', count: financialRecords.length, color: 'emerald' },
                                { label: 'Limpeza/Higiene', count: cleaningLogs.length, color: 'amber' },
                                { label: 'Entradas Terceiros', count: thirdPartyEntries.length, color: 'purple' },
                                { label: 'Ordens de Saída', count: vehicleExitOrders.length, color: 'rose' },
                                { label: 'Veículos', count: vehicleAssets.length, color: 'zinc' },
                                { label: 'Motoristas', count: driverAssets.length, color: 'zinc' },
                            ].map((stat, idx) => (
                                <div key={idx} className={`bg-${stat.color}-50 p-4 rounded-3xl border border-${stat.color}-100`}>
                                    <p className={`text-[10px] font-black text-${stat.color}-400 uppercase tracking-widest mb-1`}>{stat.label}</p>
                                    <p className={`text-2xl font-black text-${stat.color}-900`}>{stat.count}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="mt-12">
                        <h3 className="text-xl font-black text-indigo-950 uppercase tracking-tighter mb-6 flex items-center gap-2">
                            <svg className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                            Gerenciamento de Acessos
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            {systemAccesses.map((access) => (
                                <div key={access.key} className="bg-zinc-50 p-5 rounded-3xl border border-zinc-200 hover:border-indigo-200 transition-all group">
                                    <div className="flex justify-between items-start mb-3">
                                        <div>
                                            <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">{access.name}</h4>
                                            <div className="flex items-center gap-2 mt-1">
                                                {editingPasswordKey === access.key ? (
                                                    <input 
                                                        type="text"
                                                        value={newPasswordValue}
                                                        onChange={(e) => setNewPasswordValue(e.target.value)}
                                                        className="bg-white border border-indigo-200 rounded-lg px-2 py-1 text-xs font-bold text-indigo-900 outline-none focus:ring-2 focus:ring-indigo-100 w-32"
                                                        autoFocus
                                                    />
                                                ) : (
                                                    <p className="text-sm font-black text-zinc-800 font-mono">
                                                        {props.systemPasswords[access.key] || access.default}
                                                    </p>
                                                )}
                                            </div>
                                        </div>
                                        <div className="flex gap-1">
                                            {editingPasswordKey === access.key ? (
                                                <>
                                                    <button 
                                                        onClick={async () => {
                                                            if (newPasswordValue.trim()) {
                                                                await onUpdateSystemPassword(access.key, newPasswordValue.trim());
                                                                setEditingPasswordKey(null);
                                                            }
                                                        }}
                                                        className="p-2 bg-green-100 text-green-600 rounded-xl hover:bg-green-200 transition-colors"
                                                        title="Salvar"
                                                    >
                                                        <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                                                    </button>
                                                    <button 
                                                        onClick={() => setEditingPasswordKey(null)}
                                                        className="p-2 bg-zinc-100 text-zinc-400 rounded-xl hover:bg-zinc-200 transition-colors"
                                                        title="Cancelar"
                                                    >
                                                        <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                                                    </button>
                                                </>
                                            ) : (
                                                <button 
                                                    onClick={() => {
                                                        setEditingPasswordKey(access.key);
                                                        setNewPasswordValue(props.systemPasswords[access.key] || access.default);
                                                    }}
                                                    className="p-2 bg-white text-zinc-400 rounded-xl hover:bg-indigo-50 hover:text-indigo-600 border border-zinc-200 transition-all opacity-0 group-hover:opacity-100"
                                                    title="Alterar Senha"
                                                >
                                                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                    {!editingPasswordKey && !props.systemPasswords[access.key] && (
                                        <span className="text-[8px] font-bold text-zinc-400 uppercase tracking-widest bg-zinc-100 px-2 py-0.5 rounded-full">Padrão</span>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        );
      default: return null;
    }
  };

  const isAbrilVerde = new Date().getMonth() === 3;

  return (
    <div className={`flex h-screen overflow-hidden font-sans ${isAbrilVerde ? 'bg-emerald-50' : 'bg-slate-100'}`}>
      {/* Professional Sidebar Desktop */}
      <aside className="hidden md:flex w-72 flex-col shadow-2xl z-20 transition-all duration-500 bg-zinc-900 border-r border-zinc-800 text-white">
        <div className="p-8 border-b border-white/5">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-white/10 p-1.5 rounded-2xl border border-white/10 shadow-lg flex items-center justify-center shrink-0">
              <PoliciaPenalLogo className="h-9 w-auto object-contain max-w-[36px]" />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tighter italic leading-none">GESTAO 2026</h1>
              <p className="text-[8px] font-bold uppercase tracking-[0.3em] mt-1 text-indigo-400">Administrativo</p>
            </div>
          </div>
          {isAbrilVerde && (
            <div className="mt-4 bg-emerald-900/50 border border-emerald-700/50 rounded-xl p-3 flex items-center gap-3 animate-pulse">
              <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
              <span className="text-[9px] font-black uppercase tracking-widest text-emerald-300">Abril Verde Ativo</span>
            </div>
          )}
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
          {visibleTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 group relative overflow-hidden ${
                activeTab === tab.id 
                  ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-900/40'
                  : 'text-white/60 hover:bg-white/5 hover:text-white'
              }`}
            >
              <span className={`transition-colors relative z-10 ${activeTab === tab.id ? 'text-white' : 'text-white/20 group-hover:text-white/40'}`}>
                {React.cloneElement(tab.icon as React.ReactElement, { className: "h-5 w-5" })}
              </span>
              <span className="text-[10px] font-black uppercase tracking-widest relative z-10">{tab.name}</span>
              {activeTab === tab.id && (
                <motion.div layoutId="activeTabGlow" className="absolute inset-0 opacity-20 blur-xl bg-indigo-400" />
              )}
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-white/5">
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-3 p-4 rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all active:scale-95 bg-zinc-800 text-zinc-400 hover:bg-rose-600 hover:text-white"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            Sair do Sistema
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="md:hidden fixed top-0 left-0 right-0 h-16 text-white flex items-center justify-between px-6 z-[100] border-b border-white/5 bg-zinc-900">
        <div className="flex items-center gap-2.5">
          <PoliciaPenalLogo className="h-8 w-auto object-contain shrink-0" />
          <h1 className="text-sm font-black uppercase italic tracking-tighter">GESTAO 2026</h1>
        </div>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 rounded-lg bg-zinc-800">
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isMobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"} /></svg>
        </button>
      </header>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-[90] p-6 pt-24 overflow-y-auto animate-fade-in bg-zinc-900">
          <div className="grid grid-cols-2 gap-4">
            {visibleTabs.map(tab => (
              <button 
                key={tab.id} 
                onClick={() => { setActiveTab(tab.id); setIsMobileMenuOpen(false); }} 
                className={`flex flex-col items-center justify-center p-6 rounded-3xl text-[9px] font-black uppercase gap-3 border-2 transition-all active:scale-95 ${activeTab === tab.id ? 'bg-indigo-600 border-indigo-400 text-white' : 'bg-zinc-800 border-zinc-700 text-zinc-400'}`}
              >
                {React.cloneElement(tab.icon as React.ReactElement, { className: "h-6 w-6" })}
                {tab.name}
              </button>
            ))}
            <button onClick={onLogout} className="col-span-2 mt-4 p-5 bg-rose-600 text-white rounded-3xl font-black uppercase text-[10px] tracking-widest">Encerrar Sessão</button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className={`flex-1 flex flex-col min-w-0 relative pt-16 md:pt-0 transition-colors duration-500 ${isAbrilVerde ? 'bg-[#f0fdf4]' : 'bg-slate-100'}`}>
        {isAbrilVerde && (
          <div className="absolute inset-0 overflow-hidden pointer-events-none flex flex-col items-center justify-center opacity-[0.015] select-none">
            <h1 className="text-[20vw] font-black text-emerald-900 rotate-[-12deg] whitespace-nowrap">ABRIL VERDE</h1>
            <h1 className="text-[15vw] font-black text-emerald-900 rotate-[-12deg] whitespace-nowrap mt-[-5vw]">SEGURANÇA</h1>
          </div>
        )}
        {/* Top Header Bar Desktop */}
        <header className={`hidden md:flex h-20 border-b items-center justify-between px-10 sticky top-0 z-10 transition-all duration-500 ${isAbrilVerde ? 'bg-emerald-950 text-white border-emerald-900 shadow-sm' : 'bg-slate-200/90 border-slate-300'}`}>
          <div className="flex items-center gap-4">
            <PoliciaPenalLogo className="h-9 w-auto object-contain shrink-0" />
            <h2 className={`text-lg font-black uppercase tracking-tighter italic transition-colors duration-500 ${isAbrilVerde ? 'text-white' : 'text-zinc-800'}`}>
              {visibleTabs.find(t => t.id === activeTab)?.name || 'Painel'}
            </h2>
            {isAbrilVerde && (
              <div className="bg-emerald-600 text-white text-[9px] font-black px-4 py-1.5 rounded-full border border-emerald-500 shadow-lg shadow-emerald-200 animate-pulse flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-white rounded-full animate-ping"></div>
                CAMPANHA ABRIL VERDE 💚
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowServerModal(true)}
              className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-black px-4 py-2 rounded-xl text-xs uppercase tracking-wider shadow-sm transition active:scale-95 cursor-pointer"
              title="Salvar Backup e Configurações no Servidor Próprio / Linux"
            >
              <Server className="w-4 h-4 text-indigo-200" />
              <span>Salvar no Servidor</span>
            </button>

            <div className="flex flex-col items-end">
              <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Usuário Ativo</span>
              <span className="text-xs font-bold text-zinc-800">Administrador Master</span>
            </div>
            <div className="h-10 w-10 bg-zinc-100 rounded-full border-2 border-white shadow-sm flex items-center justify-center">
              <svg className="h-6 w-6 text-zinc-400" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
            </div>
          </div>
        </header>

        {/* Dynamic Content Container */}
        <div className="flex-1 overflow-y-auto p-4 md:p-10 custom-scrollbar-main">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </div>
      </main>

      {editingSupplier && (
        <EditSupplierModal 
          supplier={editingSupplier} 
          suppliers={suppliers} 
          onClose={() => setEditingSupplier(null)} 
          onSave={async (old, name, cpf, weeks) => { 
            const err = await props.onUpdateSupplier(old, name, cpf, weeks); 
            return err; 
          }} 
        />
      )}
      
      <ConfirmModal 
          isOpen={confirmConfig.isOpen}
          title={confirmConfig.title}
          message={confirmConfig.message}
          onConfirm={confirmConfig.onConfirm}
          onCancel={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
          variant={confirmConfig.variant}
      />

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
        .custom-scrollbar-main::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar-main::-webkit-scrollbar-thumb { background: #cbd5e0; border-radius: 10px; }
        @keyframes fade-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade-in { animation: fade-in 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      `}</style>
    </div>
  );
};

export default AdminDashboard;
