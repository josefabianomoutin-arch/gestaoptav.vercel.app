
import React, { useState, useMemo } from 'react';
import type { StandardMenu, DailyMenus, MenuRow, Supplier } from '../types';
import { Calendar, Printer, Clock, Utensils, ChevronRight, ChevronLeft, CheckSquare, Square, Tag } from 'lucide-react';
import { ensureArray } from '../lib/utils';

const normalizeString = (str: string): string => {
  if (!str) return '';
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]/g, ' ')
    .trim()
    .replace(/\s+/g, ' ')
    .toUpperCase();
};

interface MenuDashboardProps {
  standardMenu: StandardMenu;
  dailyMenus: DailyMenus;
  suppliers: Supplier[];
  onLogout?: () => void;
  embedded?: boolean;
  showPdfOnly?: boolean;
}

const WEEK_DAYS_BR = ['DOMINGO', 'SEGUNDA-FEIRA', 'TERÇA-FEIRA', 'QUARTA-FEIRA', 'QUINTA-FEIRA', 'SEXTA-FEIRA', 'SÁBADO'];
const MEAL_PERIODS = ['CAFÉ DA MANHÃ', 'ALMOÇO', 'JANTA', 'LANCHE NOITE'];

const getFirstTwoWords = (text: string | undefined): string => {
  if (!text) return '';
  const words = text
    .replace(/;/g, ' ')
    .replace(/,/g, ' ')
    .replace(/-/g, ' ')
    .replace(/\(/g, ' ')
    .replace(/\)/g, ' ')
    .replace(/\//g, ' ')
    .split(/\s+/)
    .filter(Boolean);
  return words.slice(0, 2).join(' ').toUpperCase();
};

const MenuDashboard: React.FC<MenuDashboardProps> = ({ standardMenu, dailyMenus, suppliers, onLogout, embedded, showPdfOnly }) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());

  const currentMenu = useMemo(() => {
    let rows: MenuRow[];
    if (dailyMenus[selectedDate]) {
      rows = dailyMenus[selectedDate];
    } else {
      const dateObj = new Date(selectedDate + 'T12:00:00');
      const dayName = WEEK_DAYS_BR[dateObj.getDay()];
      rows = standardMenu[dayName] || [];
    }
    return rows.map((r, idx) => ({ ...r, id: r.id || `${selectedDate}-${idx}` }));
  }, [selectedDate, dailyMenus, standardMenu]);

  const groupedMenu = useMemo(() => {
    return currentMenu.reduce((acc, row) => {
      const period = row.period || 'OUTROS';
      if (!acc[period]) acc[period] = [];
      acc[period].push(row);
      return acc;
    }, {} as Record<string, MenuRow[]>);
  }, [currentMenu]);

  const toggleRowSelection = (id: string) => {
    const newSelection = new Set(selectedRows);
    if (newSelection.has(id)) {
      newSelection.delete(id);
    } else {
      newSelection.add(id);
    }
    setSelectedRows(newSelection);
  };

  const toggleAllSelection = () => {
    if (selectedRows.size === currentMenu.filter(r => r.foodItem || r.contractedItem).length) {
      setSelectedRows(new Set());
    } else {
      const allIds = currentMenu
        .filter(r => r.foodItem || r.contractedItem)
        .map(r => r.id);
      setSelectedRows(new Set(allIds));
    }
  };

  const findLotInfo = (contractedItemName: string) => {
    const normContracted = normalizeString(contractedItemName);
    if (!normContracted) return { lot: 'N/A', invoice: 'N/A', expiration: 'N/A' };
    
    // Find the most recent delivery for this item
    let latestDelivery: any = null;
    let latestDate = 0;
    let bestMatchType = 0; // 2 for exact match, 1 for partial match

    suppliers.forEach(s => {
      ensureArray<any>(s.deliveries).forEach(d => {
        if (d && d.item) {
          const normDeliveryItem = normalizeString(d.item);
          const isExact = normDeliveryItem === normContracted;
          const isPartial = normDeliveryItem.includes(normContracted) || normContracted.includes(normDeliveryItem);
          
          if (isExact || isPartial) {
            const currentMatchType = isExact ? 2 : 1;
            const dDate = d.date ? new Date(d.date).getTime() : 0;
            
            // Prefer exact match over partial, or more recent date if match type is same
            if (currentMatchType > bestMatchType || (currentMatchType === bestMatchType && dDate > latestDate)) {
              latestDate = dDate;
              latestDelivery = d;
              bestMatchType = currentMatchType;
            }
          }
        }
      });
    });

    if (latestDelivery) {
      const lotObj = ensureArray<any>((latestDelivery as any).lots)?.[0];
      const lotNum = lotObj?.lotNumber || lotObj?.number || lotObj?.lot || lotObj?.lote || (latestDelivery as any).lotNumber || (latestDelivery as any).lot || (latestDelivery as any).lote || 'N/A';
      
      const rawExp = lotObj?.expirationDate || lotObj?.validade || lotObj?.expiration || (latestDelivery as any).expirationDate || (latestDelivery as any).validade || (latestDelivery as any).expiration;
      
      let expiration = 'N/A';
      if (rawExp) {
        try {
          if (typeof rawExp === 'string' && rawExp.includes('-')) {
            const parts = rawExp.split('-');
            if (parts.length === 3) {
              if (parts[0].length === 4) { // YYYY-MM-DD
                expiration = `${parts[2]}/${parts[1]}/${parts[0]}`;
              } else {
                expiration = rawExp;
              }
            } else {
              expiration = new Date(rawExp).toLocaleDateString('pt-BR');
            }
          } else {
            expiration = new Date(rawExp).toLocaleDateString('pt-BR');
          }
        } catch (_e) {
          expiration = String(rawExp);
        }
      }
      const invoice = (latestDelivery as any).invoiceNumber || (latestDelivery as any).invoice || 'N/A';
      return { lot: lotNum, invoice, expiration };
    }

    return { lot: 'N/A', invoice: 'N/A', expiration: 'N/A' };
  };

  const handlePrintSelected = () => {
    const rowsToPrint = currentMenu.filter(r => selectedRows.has(r.id));
    if (rowsToPrint.length === 0) {
      alert('Selecione ao menos um item para imprimir.');
      return;
    }

    const printWindow = window.open('', '_blank', 'width=800,height=800');
    if (!printWindow) return;

    const dateFormatted = new Date(selectedDate + 'T12:00:00').toLocaleDateString('pt-BR');
    
    const labelsHtml = rowsToPrint.map(row => {
      const { lot, invoice } = findLotInfo(row.contractedItem || row.foodItem || '');
      return `
        <div class="label-card">
          <div class="label-header">AMOSTRA 72 HORAS</div>
          <div class="label-content">
            <div class="label-field"><strong>PREPARAÇÃO:</strong> <span>${getFirstTwoWords(row.contractedItem) || row.foodItem || 'N/A'}</span></div>
            <div class="label-field"><strong>REFEIÇÃO:</strong> <span>${row.period || 'N/A'}</span></div>
            <div class="label-field"><strong>LOTE:</strong> <span>${lot}</span></div>
            <div class="label-field"><strong>NF:</strong> <span>${invoice}</span></div>
            <div class="label-field"><strong>DATA COLETA:</strong> <span>${dateFormatted}</span></div>
            <div class="label-field"><strong>HORA COLETA:</strong> <span>____:____</span></div>
            <div class="label-field"><strong>ARMAZENAMENTO:</strong> <span>REFRIGERADO (0°C a 4°C)</span></div>
          </div>
          <div class="label-signature">ASSINATURA DO RESPONSÁVEL</div>
          <div class="label-footer">VALIDADE: 72 HORAS APÓS A COLETA</div>
        </div>
      `;
    }).join('');

    const htmlContent = `
      <html>
        <head>
          <title>Etiquetas Amostra 72h - Selecionadas</title>
          <style>
            @page { 
              size: A4; 
              margin: 0; 
            }
            body { 
              margin: 0; 
              padding: 0; 
              background: white;
            }
            .sheet {
              width: 210mm;
              height: 297mm;
              padding: 20mm 17mm;
              box-sizing: border-box;
              display: grid;
              grid-template-columns: 85.73mm 85.73mm;
              grid-auto-rows: 59.27mm;
              column-gap: 10mm;
              row-gap: 0;
              justify-content: center;
              page-break-after: always;
            }
            .label-card {
              width: 85.73mm;
              height: 59.27mm;
              border: 1px solid #000;
              padding: 3mm;
              box-sizing: border-box;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              border-radius: 1mm;
              overflow: hidden;
            }
            .label-header {
              text-align: center;
              font-weight: bold;
              font-size: 11pt;
              border-bottom: 1px solid #000;
              padding-bottom: 1mm;
              margin-bottom: 1.5mm;
              text-transform: uppercase;
            }
            .label-content {
              font-size: 8pt;
              line-height: 1.2;
              flex: 1;
            }
            .label-field { 
              margin-bottom: 0.5mm; 
              display: flex;
              gap: 1mm;
            }
            .label-field strong { 
              text-transform: uppercase; 
              font-size: 7pt; 
              color: #333; 
              white-space: nowrap;
            }
            .label-field span {
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            }
            .label-footer {
              font-size: 7pt;
              text-align: center;
              border-top: 1px dashed #000;
              padding-top: 1mm;
              margin-top: 1mm;
              font-weight: bold;
            }
            .label-signature {
              margin-top: 1.5mm;
              border-top: 0.5px solid #000;
              width: 70%;
              margin-left: auto;
              margin-right: auto;
              text-align: center;
              font-size: 6pt;
            }
            @media print {
              .sheet { page-break-after: always; }
            }
          </style>
        </head>
        <body>
          <div class="sheet">
            ${labelsHtml}
          </div>
          <script>
            window.onload = () => {
              window.print();
              setTimeout(() => window.close(), 500);
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  const handlePrintLargeLabel = () => {
    const selectedItems = currentMenu.filter(r => selectedRows.has(r.id));
    
    // Se não houver seleção, tenta pegar todos do almoço e janta, descartando linhas vazias
    const lunchItems = (selectedItems.length > 0 
      ? selectedItems.filter(r => r.period === 'ALMOÇO')
      : currentMenu.filter(r => r.period === 'ALMOÇO'))
      .filter(r => r.foodItem || r.contractedItem);
      
    const dinnerItems = (selectedItems.length > 0
      ? selectedItems.filter(r => r.period === 'JANTA')
      : currentMenu.filter(r => r.period === 'JANTA'))
      .filter(r => r.foodItem || r.contractedItem);
    
    if (lunchItems.length === 0 && dinnerItems.length === 0) {
      alert('Selecione os itens do Almoço ou Janta para gerar a etiqueta.');
      return;
    }

    const printWindow = window.open('', '_blank', 'width=900,height=600');
    if (!printWindow) return;

    const dateFormatted = new Date(selectedDate + 'T12:00:00').toLocaleDateString('pt-BR');
    const dayOfWeek = WEEK_DAYS_BR[new Date(selectedDate + 'T12:00:00').getDay()];

    const mealsToPrint = [];
    if (lunchItems.length > 0) mealsToPrint.push({ title: 'Almoço', items: lunchItems });
    if (dinnerItems.length > 0) mealsToPrint.push({ title: 'Jantar', items: dinnerItems });

    const maxItems = Math.max(...mealsToPrint.map(m => m.items.length), 1);

    // Ajusta o espaçamento dinamicamente para garantir que caiba na etiqueta de 100mm de altura
    let cardPadding = '6mm';
    let headerMargin = '3mm';
    let headerPadding = '3mm';
    let mealTitleMargin = '3mm';
    let mealTitlePadding = '1.5mm';
    let tableFontSize = '10pt';
    let tableCellPadding = '1.5mm 1mm';
    let footerMargin = '3mm';
    let footerPadding = '2mm';
    let footerGap = '2mm';
    let sigMargin = '2mm auto 0';

    if (maxItems === 4) {
      cardPadding = '5mm';
      headerMargin = '2mm';
      headerPadding = '2mm';
      mealTitleMargin = '2mm';
      mealTitlePadding = '1.2mm';
      tableFontSize = '9pt';
      tableCellPadding = '1.2mm 1mm';
      footerMargin = '2mm';
      footerPadding = '1.5mm';
      footerGap = '1.5mm';
      sigMargin = '1.5mm auto 0';
    } else if (maxItems >= 5) {
      cardPadding = '4mm';
      headerMargin = '1.2mm';
      headerPadding = '1.2mm';
      mealTitleMargin = '1.2mm';
      mealTitlePadding = '0.8mm';
      tableFontSize = '8pt';
      tableCellPadding = '0.6mm 1mm';
      footerMargin = '1.2mm';
      footerPadding = '1mm';
      footerGap = '1mm';
      sigMargin = '0.8mm auto 0';
    }

    const labelsHtml = mealsToPrint.map(meal => `
      <div class="label-card">
        <div class="header">
          <h1>Cardápio Institucional</h1>
          <div class="date-info">${dayOfWeek} - ${dateFormatted}</div>
        </div>
        <div class="content">
          <div class="meal-title">${meal.title}</div>
          <table class="item-table">
            <thead>
              <tr>
                <th>Item / Preparação</th>
                <th>Lote</th>
                <th>NF</th>
                <th>Validade</th>
              </tr>
            </thead>
            <tbody>
              ${meal.items.map(item => {
                const { lot, invoice, expiration } = findLotInfo(item.contractedItem || item.foodItem || '');
                return `
                  <tr>
                    <td>${getFirstTwoWords(item.contractedItem) || item.foodItem || '-'}</td>
                    <td class="text-center">${lot}</td>
                    <td class="text-center">${invoice}</td>
                    <td class="text-center">${expiration}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
        <div class="footer">
          <div class="footer-info">
            <span>Data Coleta: ${dateFormatted}</span>
            <span>Hora: ____:____</span>
            <span>Armazenamento: REFRIGERADO (0°C a 4°C)</span>
          </div>
          <div class="signature-line">Assinatura do Responsável</div>
          <div class="footer-branding">
            <span>Penitenciária de Taiúva</span>
            <span>Gestão de Alimentação</span>
          </div>
        </div>
      </div>
    `).join('<div style="page-break-after: always;"></div>');

    const htmlContent = `
      <html>
        <head>
          <title>Etiquetas de Cardápio 18x10</title>
          <style>
            @page { size: landscape; margin: 0; }
            body { 
              margin: 0; 
              padding: 0; 
              background: white;
              display: flex;
              flex-direction: column;
              align-items: center;
            }
            .label-card {
              width: 180mm;
              height: 100mm;
              border: 3px solid #000;
              padding: ${cardPadding};
              box-sizing: border-box;
              display: flex;
              flex-direction: column;
              font-family: 'Arial', sans-serif;
              margin: 10mm 0;
              page-break-after: always;
            }
            .header {
              text-align: center;
              border-bottom: 2px solid #000;
              padding-bottom: ${headerPadding};
              margin-bottom: ${headerMargin};
            }
            .header h1 { margin: 0; font-size: 20pt; text-transform: uppercase; font-weight: 900; }
            .header .date-info { font-size: 14pt; font-weight: bold; margin-top: 1mm; }
            
            .content {
              flex: 1;
              display: flex;
              flex-direction: column;
              overflow: hidden;
            }
            .meal-title {
              font-size: 16pt;
              font-weight: 900;
              text-transform: uppercase;
              background: #000;
              color: #fff;
              padding: ${mealTitlePadding};
              text-align: center;
              margin-bottom: ${mealTitleMargin};
            }
            .item-table {
              width: 100%;
              border-collapse: collapse;
              font-size: ${tableFontSize};
            }
            .item-table th {
              text-align: left;
              border-bottom: 1px solid #000;
              padding: 1mm;
              text-transform: uppercase;
              font-size: 8pt;
            }
            .item-table td {
              padding: ${tableCellPadding};
              border-bottom: 0.5px solid #eee;
              font-weight: bold;
            }
            .text-center { text-align: center; }

            .footer {
              margin-top: ${footerMargin};
              border-top: 2px solid #000;
              padding-top: ${footerPadding};
              display: flex;
              flex-direction: column;
              gap: ${footerGap};
            }
            .footer-info {
              display: flex;
              justify-content: space-between;
              font-size: 9pt;
              font-weight: bold;
            }
            .signature-line {
              border-top: 1px solid #000;
              width: 50%;
              margin: ${sigMargin};
              text-align: center;
              font-size: 7pt;
              text-transform: uppercase;
            }
            .footer-branding {
              display: flex;
              justify-content: space-between;
              font-size: 9pt;
              font-weight: bold;
              text-transform: uppercase;
              opacity: 0.8;
            }
            @media print {
              body { display: block; }
              .label-card { margin: 0; border: 3px solid #000; }
            }
          </style>
        </head>
        <body>
          ${labelsHtml}
          <script>
            window.onload = () => {
              window.print();
              setTimeout(() => window.close(), 500);
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  const handleGenerateDailyPdf = () => {
    const printWindow = window.open('', '_blank', 'width=900,height=1000');
    if (!printWindow) return;

    const dateFormatted = new Date(selectedDate + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    
    const menuHtml = MEAL_PERIODS.map(period => {
      const items = groupedMenu[period] || [];
      return `
        <div class="period-section">
          <div class="period-header">${period}</div>
          <table class="menu-table">
            <thead>
              <tr>
                <th>PREPARAÇÃO / ITEM</th>
                <th>PESO/QUANTIDADE UNITÁRIO</th>
                <th>PESO/QUANTIDADE TOTAL</th>
                <th>LOTE</th>
                <th>NF</th>
              </tr>
            </thead>
            <tbody>
              ${items.length > 0 ? items.map(row => {
                const { lot, invoice } = findLotInfo(row.contractedItem || row.foodItem || '');
                return `
                  <tr>
                    <td><strong>${getFirstTwoWords(row.contractedItem) || row.foodItem || 'N/A'}</strong></td>
                    <td class="text-center">${row.unitWeight || '-'}</td>
                    <td class="text-center">${row.totalWeight || '-'}</td>
                    <td class="text-center">${lot}</td>
                    <td class="text-center">${invoice}</td>
                  </tr>
                `;
              }).join('') : '<tr><td colspan="5" class="text-center italic">Nenhum item cadastrado</td></tr>'}
            </tbody>
          </table>
        </div>
      `;
    }).join('');

    const htmlContent = `
      <html>
        <head>
          <title>Cardápio Institucional - ${dateFormatted}</title>
          <style>
            @page { size: A4; margin: 15mm; }
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #333; line-height: 1.4; margin: 0; padding: 0; }
            .header { text-align: center; border-bottom: 3px solid #1e1b4b; padding-bottom: 10px; margin-bottom: 20px; }
            .header h1 { margin: 0; color: #1e1b4b; text-transform: uppercase; font-size: 22pt; letter-spacing: -1px; }
            .header p { margin: 5px 0 0; font-weight: bold; color: #666; text-transform: uppercase; font-size: 10pt; }
            .date-info { text-align: center; margin-bottom: 30px; background: #f8fafc; padding: 10px; border-radius: 10px; border: 1px solid #e2e8f0; }
            .date-info h2 { margin: 0; color: #4338ca; text-transform: capitalize; font-size: 16pt; }
            .period-section { margin-bottom: 25px; page-break-inside: avoid; }
            .period-header { background: #1e1b4b; color: white; padding: 8px 15px; font-weight: bold; border-radius: 6px 6px 0 0; text-transform: uppercase; font-size: 12pt; }
            .menu-table { width: 100%; border-collapse: collapse; border: 1px solid #e2e8f0; }
            .menu-table th { background: #f1f5f9; text-align: left; padding: 10px; font-size: 9pt; text-transform: uppercase; border: 1px solid #e2e8f0; }
            .menu-table td { padding: 10px; border: 1px solid #e2e8f0; font-size: 10pt; vertical-align: top; }
            .text-center { text-align: center; }
            .italic { font-style: italic; color: #999; }
            .footer { margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 20px; font-size: 8pt; color: #94a3b8; text-align: center; text-transform: uppercase; }
            .signature-area { margin-top: 50px; display: flex; justify-content: space-around; }
            .signature-box { border-top: 1px solid #333; width: 200px; text-align: center; padding-top: 5px; font-size: 9pt; font-weight: bold; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Cardápio Institucional</h1>
            <p>Penitenciária de Taiúva - Gestão de Alimentação</p>
          </div>
          <div class="date-info">
            <h2>${dateFormatted}</h2>
          </div>
          ${menuHtml}
          <div class="signature-area">
            <div class="signature-box">Responsável pela Nutrição</div>
            <div class="signature-box">Diretoria de Centro</div>
          </div>
          <div class="footer">
            Sistema de Gestão Institucional - Gerado em ${new Date().toLocaleString('pt-BR')}
          </div>
          <script>
            window.onload = () => {
              window.print();
              setTimeout(() => window.close(), 500);
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  const changeDate = (days: number) => {
    const date = new Date(selectedDate + 'T12:00:00');
    date.setDate(date.getDate() + days);
    setSelectedDate(date.toISOString().split('T')[0]);
    setSelectedRows(new Set());
  };

  return (
    <div className={`${embedded ? '' : 'min-h-screen'} bg-slate-50 flex flex-col`}>
      {/* Header */}
      {!embedded && (
        <header className="bg-indigo-900 text-white p-6 shadow-xl flex justify-between items-center sticky top-0 z-50">
          <div className="flex items-center gap-4">
            <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-md">
              <Utensils className="h-8 w-8 text-amber-400" />
            </div>
            <div>
              <h1 className="text-2xl font-black uppercase tracking-tighter italic">Painel Cardápio</h1>
              <p className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest">Gestão de Amostras e Alinhamento</p>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white px-6 py-3 rounded-2xl font-black text-xs uppercase transition-all border border-red-500/20"
          >
            Sair
          </button>
        </header>
      )}

      <main className={`flex-1 p-4 md:p-8 ${embedded ? 'max-w-full' : 'max-w-6xl'} mx-auto w-full space-y-8`}>
        {/* Date Selector */}
        <div className="bg-white p-6 rounded-[2.5rem] shadow-2xl border border-indigo-50 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => changeDate(-1)}
              className="p-3 hover:bg-indigo-50 rounded-2xl text-indigo-600 transition-colors"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <div className="text-center md:text-left">
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <Calendar className="h-4 w-4 text-indigo-400" />
                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Data de Referência</span>
              </div>
              <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">
                {new Date(selectedDate + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}
              </h2>
            </div>
            <button 
              onClick={() => changeDate(1)}
              className="p-3 hover:bg-indigo-50 rounded-2xl text-indigo-600 transition-colors"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>

          <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
            <input 
              type="date" 
              value={selectedDate}
              onChange={(e) => {
                setSelectedDate(e.target.value);
                setSelectedRows(new Set());
              }}
              className="px-6 py-4 bg-slate-50 border-2 border-indigo-50 rounded-2xl font-bold text-slate-700 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
            />
            <div className="flex gap-2">
              {!showPdfOnly && (
                <button 
                  onClick={toggleAllSelection}
                  className="flex items-center justify-center gap-2 px-6 py-4 bg-slate-100 hover:bg-slate-200 text-slate-600 font-black rounded-2xl transition-all active:scale-95 uppercase text-[10px] tracking-widest"
                >
                  {selectedRows.size === currentMenu.filter(r => r.foodItem || r.contractedItem).length ? <CheckSquare className="h-4 w-4" /> : <Square className="h-4 w-4" />}
                  {selectedRows.size === currentMenu.filter(r => r.foodItem || r.contractedItem).length ? 'Desmarcar Todos' : 'Marcar Todos'}
                </button>
              )}
              
              {showPdfOnly ? (
                <div className="flex gap-2">
                  <button 
                    onClick={handlePrintLargeLabel}
                    className="flex items-center justify-center gap-3 px-8 py-4 bg-amber-600 hover:bg-amber-700 text-white font-black rounded-2xl shadow-lg shadow-amber-200 transition-all active:scale-95 uppercase text-xs tracking-widest"
                  >
                    <Tag className="h-5 w-5" />
                    Etiqueta 18x10
                  </button>
                  <button 
                    onClick={handleGenerateDailyPdf}
                    className="flex items-center justify-center gap-3 px-10 py-4 bg-slate-800 hover:bg-slate-900 text-white font-black rounded-2xl shadow-lg shadow-slate-200 transition-all active:scale-95 uppercase text-xs tracking-widest"
                  >
                    <Printer className="h-5 w-5" />
                    Gerar PDF do Dia
                  </button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <button 
                    onClick={handlePrintLargeLabel}
                    className="flex items-center justify-center gap-3 px-8 py-4 bg-amber-600 hover:bg-amber-700 text-white font-black rounded-2xl shadow-lg shadow-amber-200 transition-all active:scale-95 uppercase text-xs tracking-widest"
                  >
                    <Tag className="h-5 w-5" />
                    Etiqueta 18x10
                  </button>
                  <button 
                    onClick={handlePrintSelected}
                    disabled={selectedRows.size === 0}
                    className="flex items-center justify-center gap-3 px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-2xl shadow-lg shadow-indigo-200 transition-all active:scale-95 uppercase text-xs tracking-widest disabled:bg-slate-300 disabled:shadow-none"
                  >
                    <Printer className="h-5 w-5" />
                    Imprimir Selecionadas ({selectedRows.size})
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Menu Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {MEAL_PERIODS.map(period => (
            <div key={period} className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden flex flex-col">
              <div className="bg-slate-50 p-6 border-b border-slate-100 flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="bg-indigo-600 p-2 rounded-xl">
                    <Clock className="h-5 w-5 text-white" />
                  </div>
                  <h3 className="font-black text-slate-800 uppercase tracking-tight">{period}</h3>
                </div>
                <span className="text-[10px] font-black text-slate-400 bg-slate-200 px-3 py-1 rounded-full uppercase">
                  {groupedMenu[period]?.length || 0} Itens
                </span>
              </div>
              
              <div className="p-6 flex-1 space-y-4">
                {groupedMenu[period] && groupedMenu[period].length > 0 ? (
                  groupedMenu[period].map((row) => (
                    <div 
                      key={row.id} 
                      onClick={() => toggleRowSelection(row.id)}
                      className={`group cursor-pointer p-4 rounded-2xl border-2 transition-all flex justify-between items-center gap-4 ${selectedRows.has(row.id) ? 'bg-indigo-50 border-indigo-200' : 'bg-slate-50 border-slate-100 hover:bg-indigo-50/50'}`}
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div className={`transition-colors ${selectedRows.has(row.id) ? 'text-indigo-600' : 'text-slate-300'}`}>
                          {selectedRows.has(row.id) ? <CheckSquare className="h-6 w-6" /> : <Square className="h-6 w-6" />}
                        </div>
                        <div className="flex-1">
                          <p className={`font-bold uppercase text-sm leading-tight transition-colors ${selectedRows.has(row.id) ? 'text-indigo-900' : 'text-slate-800'}`}>
                            {getFirstTwoWords(row.contractedItem) || row.foodItem || 'Item não especificado'}
                          </p>
                          {row.preparationDetails && (
                            <p className="text-[10px] text-slate-400 mt-1 font-medium">{row.preparationDetails}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col items-end text-[9px] font-mono text-slate-400">
                        <span>LOT: {findLotInfo(row.contractedItem || row.foodItem || '').lot}</span>
                        <span>NF: {findLotInfo(row.contractedItem || row.foodItem || '').invoice}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="h-32 flex flex-col items-center justify-center text-slate-300 border-2 border-dashed border-slate-100 rounded-3xl">
                    <Utensils className="h-8 w-8 mb-2 opacity-20" />
                    <p className="text-xs font-bold uppercase tracking-widest">Sem itens lançados</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Footer Info */}
        <div className="bg-amber-50 p-8 rounded-[2.5rem] border border-amber-100 text-amber-900 space-y-4">
          <h4 className="font-black uppercase tracking-tight flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Instruções para Coleta de Amostras
          </h4>
          <ul className="text-sm space-y-2 font-medium opacity-80 list-disc list-inside">
            <li>Coletar amostras de todos os itens servidos em cada refeição.</li>
            <li>Utilizar sacos plásticos estéreis ou recipientes higienizados.</li>
            <li>Identificar cada amostra com a etiqueta correspondente.</li>
            <li>Armazenar sob refrigeração (0°C a 4°C) por um período de 72 horas.</li>
            <li>O descarte deve ser realizado após o prazo de segurança.</li>
          </ul>
        </div>
      </main>

      {!embedded && (
        <footer className="p-8 text-center text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em]">
          Sistema de Gestão Institucional &copy; 2026 - Penitenciária de Taiúva
        </footer>
      )}
    </div>
  );
};

export default MenuDashboard;
